package in.advocate.personal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONTokener;

/** Simple browser limited to government sites (*.gov.in / *.nic.in) with a "Fetch" button. */
public class BrowserActivity extends Activity {
    private static final int MAX_CHARS = 300000;
    private WebView web;
    private TextView titleView;

    private static boolean allowed(Uri u) {
        if (u == null || !"https".equalsIgnoreCase(u.getScheme())) {
            return false;
        }
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        return h.equals("gov.in") || h.endsWith(".gov.in") || h.equals("nic.in") || h.endsWith(".nic.in");
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String url = getIntent().getStringExtra("url");
        String title = getIntent().getStringExtra("title");
        if (url == null || !allowed(Uri.parse(url))) {
            Toast.makeText(this, "Only government websites can be opened here.", Toast.LENGTH_LONG).show();
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFFF1EDF7);
        bar.setPadding(dp(8), dp(6), dp(8), dp(6));

        Button close = new Button(this);
        close.setText("Close");
        close.setAllCaps(false);
        close.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        titleView = new TextView(this);
        titleView.setText(title == null ? "Browser" : title);
        titleView.setTextColor(0xFF39353D);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setPadding(dp(10), 0, dp(10), 0);

        Button fetch = new Button(this);
        fetch.setText("Fetch");
        fetch.setAllCaps(false);
        fetch.setOnClickListener(v -> fetchPage());

        bar.addView(close, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(fetch, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (allowed(request.getUrl())) {
                    return false;
                }
                Toast.makeText(BrowserActivity.this, "Only government websites can be opened here.", Toast.LENGTH_SHORT).show();
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String finishedUrl) {
                String t = view.getTitle();
                if (t != null && !t.isEmpty()) {
                    titleView.setText(t);
                }
            }
        });

        // Government sites use JavaScript pop-ups (e.g. "Select state, district...") - show them.
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String u, String message, final JsResult result) {
                new AlertDialog.Builder(BrowserActivity.this)
                    .setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String u, String message, final JsResult result) {
                new AlertDialog.Builder(BrowserActivity.this)
                    .setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
                return true;
            }
        });

        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        web.loadUrl(url);
    }

    private void fetchPage() {
        web.evaluateJavascript("(function(){return document.body ? document.body.innerText : '';})()", value -> {
            String text = "";
            try {
                Object o = new JSONTokener(value == null ? "null" : value).nextValue();
                if (o instanceof String) {
                    text = (String) o;
                }
            } catch (Exception ignored) {
                // leave text empty
            }
            if (text.length() > MAX_CHARS) {
                text = text.substring(0, MAX_CHARS);
            }
            Intent data = new Intent();
            data.putExtra("text", text);
            data.putExtra("url", web.getUrl());
            data.putExtra("title", web.getTitle());
            setResult(RESULT_OK, data);
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            setResult(RESULT_CANCELED);
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}

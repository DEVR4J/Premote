package in.advocate.personal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/** Simple browser limited to government sites (*.gov.in / *.nic.in) with a "Fetch" button. */
public class BrowserActivity extends Activity {
    private static final int MAX_CHARS = 300000;
    private WebView web;
    private TextView titleView;
    private String mode = "case";
    private String parsersJs;

    private static boolean allowed(Uri u) {
        if (u == null || !"https".equalsIgnoreCase(u.getScheme())) {
            return false;
        }
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase();
        return h.equals("gov.in") || h.endsWith(".gov.in") || h.equals("nic.in") || h.endsWith(".nic.in");
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String url = getIntent().getStringExtra("url");
        String title = getIntent().getStringExtra("title");
        String m = getIntent().getStringExtra("mode");
        if (m != null) {
            mode = m;
        }
        if (url == null || !allowed(Uri.parse(url))) {
            Toast.makeText(this, "Only government websites can be opened here.", Toast.LENGTH_LONG).show();
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFFF1EDF7);
        bar.setPadding(dp(8), dp(6), dp(8), dp(6));

        Button close = new Button(this);
        close.setText("Close");
        close.setAllCaps(false);
        close.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        titleView = new TextView(this);
        titleView.setText(title == null ? "Browser" : title);
        titleView.setTextColor(0xFF39353D);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setPadding(dp(10), 0, dp(10), 0);

        Button fetch = new Button(this);
        fetch.setText("Fetch");
        fetch.setAllCaps(false);
        fetch.setOnClickListener(v -> fetchPage());

        bar.addView(close, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(fetch, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (allowed(request.getUrl())) {
                    return false;
                }
                Toast.makeText(BrowserActivity.this, "Only government websites can be opened here.", Toast.LENGTH_SHORT).show();
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String finishedUrl) {
                String t = view.getTitle();
                if (t != null && !t.isEmpty()) {
                    titleView.setText(t);
                }
            }
        });

        // Government sites use JavaScript pop-ups (e.g. "Select state, district...") - show them.
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String u, String message, final JsResult result) {
                new AlertDialog.Builder(BrowserActivity.this)
                    .setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String u, String message, final JsResult result) {
                new AlertDialog.Builder(BrowserActivity.this)
                    .setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
                return true;
            }
        });

        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        web.loadUrl(url);
    }

    private String loadParsers() {
        if (parsersJs != null) {
            return parsersJs;
        }
        try (InputStream in = getAssets().open("parsers.js")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            parsersJs = out.toString("UTF-8");
        } catch (Exception ex) {
            parsersJs = "";
        }
        return parsersJs;
    }

    /** Reads the page being viewed, shows what was found, and lets the advocate Save or Cancel. The browser stays open. */
    private void fetchPage() {
        String js = loadParsers();
        if (js.isEmpty()) {
            Toast.makeText(this, "Reader is missing. Rebuild the app.", Toast.LENGTH_LONG).show();
            return;
        }
        String script = "(function(){try{" + js + "\n;return JSON.stringify(window.AdvocateParsers.preview(document.body?document.body.innerText:''," + JSONObject.quote(mode) + "));}catch(e){return JSON.stringify({ok:false,message:'Could not read this page.',title:'Nothing to save',lines:[],items:[]});}})()";
        web.evaluateJavascript(script, value -> {
            try {
                Object o = new JSONTokener(value == null ? "null" : value).nextValue();
                if (o instanceof String) {
                    showPreview(new JSONObject((String) o));
                    return;
                }
            } catch (Exception ignored) {
                // fall through to the message below
            }
            Toast.makeText(BrowserActivity.this, "Could not read this page.", Toast.LENGTH_SHORT).show();
        });
    }

    private void showPreview(final JSONObject p) {
        boolean ok = p.optBoolean("ok", false);
        JSONArray lines = p.optJSONArray("lines");
        StringBuilder sb = new StringBuilder();
        if (!ok) {
            sb.append(p.optString("message", "Nothing to save from this page."));
        } else if (lines != null) {
            for (int i = 0; i < lines.length(); i++) {
                if (i > 0) {
                    sb.append('\n');
                }
                sb.append(lines.optString(i));
            }
        }
        AlertDialog.Builder dlg = new AlertDialog.Builder(this)
            .setTitle(p.optString("title", "Fetched"))
            .setMessage(sb.toString());
        if (ok) {
            dlg.setPositiveButton("Save", (d, w) -> savePending(p.optJSONArray("items")));
            dlg.setNegativeButton("Cancel", null);
        } else {
            dlg.setPositiveButton("OK", null);
        }
        dlg.show();
    }

    /** Queues the items; the app imports them when the browser is closed (or next time it opens). */
    private void savePending(JSONArray items) {
        if (items == null || items.length() == 0) {
            return;
        }
        try {
            SharedPreferences prefs = getSharedPreferences("advocate_pending", MODE_PRIVATE);
            JSONArray all = new JSONArray(prefs.getString("items", "[]"));
            for (int i = 0; i < items.length(); i++) {
                all.put(items.get(i));
            }
            prefs.edit().putString("items", all.toString()).apply();
            Toast.makeText(this, "Saved. Open another and tap Fetch again, or Close when done.", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            Toast.makeText(this, "Could not save.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            setResult(RESULT_CANCELED);
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}

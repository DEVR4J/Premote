package in.advocate.personal;

import android.app.Activity;
import android.content.Intent;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Opens a government website in a full-screen in-app browser. The advocate uses the site normally
 * (types the captcha / OTP, searches). When they tap "Fetch", the text of the page they are looking
 * at is returned to the app. Nothing is sent to the site automatically.
 */
@CapacitorPlugin(name = "PageFetch")
public class PageFetchPlugin extends Plugin {

    @PluginMethod
    public void open(PluginCall call) {
        String url = call.getString("url");
        if (url == null || !url.startsWith("https://")) {
            call.reject("A secure (https) address is required.");
            return;
        }
        Intent intent = new Intent(getContext(), BrowserActivity.class);
        intent.putExtra("url", url);
        intent.putExtra("title", call.getString("title", "Browser"));
        startActivityForResult(call, intent, "onBrowserResult");
    }

    @ActivityCallback
    private void onBrowserResult(PluginCall call, ActivityResult result) {
        if (call == null) {
            return;
        }
        JSObject out = new JSObject();
        Intent data = result.getData();
        if (result.getResultCode() == Activity.RESULT_OK && data != null) {
            out.put("fetched", true);
            out.put("text", data.getStringExtra("text"));
            out.put("url", data.getStringExtra("url"));
            out.put("title", data.getStringExtra("title"));
        } else {
            out.put("fetched", false);
        }
        call.resolve(out);
    }
}

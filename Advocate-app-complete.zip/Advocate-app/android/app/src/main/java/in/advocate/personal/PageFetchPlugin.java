package in.advocate.personal;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONException;

/**
 * Opens a government website in a full-screen in-app browser. The advocate uses the site normally
 * (types the captcha / OTP, searches). When they tap "Fetch", the text of the page they are looking
 * at is returned to the app. Nothing is sent to the site automatically.
 */
@CapacitorPlugin(name = "PageFetch")
public class PageFetchPlugin extends Plugin {

    @PluginMethod
    public void open(PluginCall call) {
        String url = call.getString("url");
        if (url == null || !url.startsWith("https://")) {
            call.reject("A secure (https) address is required.");
            return;
        }
        Intent intent = new Intent(getContext(), BrowserActivity.class);
        intent.putExtra("url", url);
        intent.putExtra("title", call.getString("title", "Browser"));
        intent.putExtra("mode", call.getString("mode", "case"));
        startActivityForResult(call, intent, "onBrowserResult");
    }

    /** Items the advocate saved in the browser. Returned once, then cleared. */
    @PluginMethod
    public void takePending(PluginCall call) {
        SharedPreferences prefs = getContext().getSharedPreferences("advocate_pending", Context.MODE_PRIVATE);
        String raw = prefs.getString("items", "[]");
        prefs.edit().remove("items").apply();
        JSObject out = new JSObject();
        try {
            out.put("items", new JSArray(raw));
        } catch (JSONException e) {
            out.put("items", new JSArray());
        }
        call.resolve(out);
    }

    @ActivityCallback
    private void onBrowserResult(PluginCall call, ActivityResult result) {
        if (call == null) {
            return;
        }
        JSObject out = new JSObject();
        out.put("closed", true);
        call.resolve(out);
    }
}

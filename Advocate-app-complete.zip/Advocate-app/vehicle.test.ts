import { describe, expect, it } from 'vitest';
import { parseChallans, parseVehicle } from './vehicle';

// Samples are hand-written approximations, not captures of the live Parivahan / e-Challan pages.
describe('vehicle and challan readers', () => {
  it('reads a vehicle page', () => {
    const v = parseVehicle('Registration No:\nUP79AB1234\nOwner Name:\nRam Kumar\nInsurance Upto:\n11-Mar-2026\nFuel Type:\nPETROL');
    expect(v?.vehicleNo).toBe('UP79AB1234');
    expect(v?.fields.find(f => f.label === 'Insurance upto')?.iso).toBe('2026-03-11');
  });
  it('reads challans', () => {
    const r = parseChallans('Challan No\nUP12345678901234\nOffence\nOver speeding\nAmount\n1000\nStatus\nPending\nChallan No\nUP99999999999999\nOffence\nNo helmet');
    expect(r?.items).toHaveLength(2);
    expect(r?.items[0]).toMatchObject({ offence: 'Over speeding', amount: '1000', status: 'Pending' });
  });
  it('handles no-challan and unrelated text', () => {
    expect(parseChallans('No challans found')).toEqual({ items: [], none: true });
    expect(parseChallans('hello')).toBeNull(); expect(parseVehicle('hello')).toBeNull();
  });
});

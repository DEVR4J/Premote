// Readers for text fetched from the Parivahan vehicle-details page and the e-Challan status page.
// The layouts are not documented, so these look for labelled values ("Label: value", "Label<tab>value" or
// the value on the next line) instead of fixed positions. Unrecognised text returns null.
import { parseCourtDate } from './ecourts';

const clean = (s: string) => s.replace(/\s+/g, ' ').trim();
const toLines = (text: string) => text.replace(/\r/g, '').split('\n').flatMap(l => l.split(/\t+/)).map(clean).filter(Boolean);
const PLATE = /\b[A-Z]{2}\s?\d{1,2}\s?[A-Z]{0,3}\s?\d{4}\b/;

/** Value of the first line starting with `label`: rest of that line after ':' / '-', else the next line. */
function valueAfter(lines: string[], label: RegExp, stop: RegExp): string {
  const i = lines.findIndex(l => label.test(l));
  if (i < 0) return '';
  const rest = clean((lines[i] ?? '').replace(label, '').replace(/^[\s:\-–]+/, ''));
  if (rest) return rest;
  const next = lines[i + 1] ?? '';
  return next && !stop.test(next) ? next.replace(/^[:\-–\s]+/, '') : '';
}

const VEHICLE_FIELDS: { label: string; re: RegExp; date?: boolean }[] = [
  { label: 'Registration no.', re: /^(registration|regn\.?)\s*(no\.?|number)\b/i },
  { label: 'Owner', re: /^owner('?s)?(\s*name)?\b/i },
  { label: 'Registration date', re: /^(registration|regn\.?)\s*date\b/i, date: true },
  { label: 'Vehicle class', re: /^vehicle\s*class\b/i },
  { label: 'Maker / model', re: /^(maker\s*\/?\s*model|maker|manufacturer|model)\b/i },
  { label: 'Fuel', re: /^fuel(\s*type)?\b/i },
  { label: 'Chassis no.', re: /^chassis\s*(no\.?|number)\b/i },
  { label: 'Engine no.', re: /^engine\s*(no\.?|number)\b/i },
  { label: 'RC status', re: /^(rc\s*)?status\b/i },
  { label: 'Fitness upto', re: /^fitness\s*(upto|valid\s*upto|validity)\b/i, date: true },
  { label: 'Insurance upto', re: /^insurance\s*(upto|valid\s*upto|validity)\b/i, date: true },
  { label: 'Tax upto', re: /^(road\s*)?tax\s*(upto|valid\s*upto|validity)\b/i, date: true },
  { label: 'PUC upto', re: /^puc\s*(upto|valid\s*upto|validity)\b/i, date: true },
];
const ANY_LABEL = new RegExp(VEHICLE_FIELDS.map(f => f.re.source.replace(/^\^/, '^')).join('|'), 'i');

export type Field = { label: string; value: string; iso?: string };
export type VehicleInfo = { vehicleNo: string; fields: Field[] };

export function parseVehicle(text: string): VehicleInfo | null {
  const lines = toLines(text);
  const fields: Field[] = [];
  for (const f of VEHICLE_FIELDS) {
    const value = valueAfter(lines, f.re, ANY_LABEL);
    if (value) fields.push({ label: f.label, value, iso: f.date ? parseCourtDate(value) : undefined });
  }
  const vehicleNo = (fields.find(f => f.label === 'Registration no.')?.value.match(PLATE)?.[0] || text.match(PLATE)?.[0] || '').replace(/\s/g, '');
  return fields.length >= 2 ? { vehicleNo, fields } : null;
}

export type Challan = { challanNo: string; date: string; offence: string; place: string; amount: string; status: string };
export type ChallanResult = { items: Challan[]; none: boolean };

const CH_FIELDS: { key: keyof Challan; re: RegExp }[] = [
  { key: 'date', re: /^(challan|offence|violation)?\s*(date|date\s*&\s*time)\b/i },
  { key: 'offence', re: /^(offence|offense|violation)(\s*(details|name|description))?\b/i },
  { key: 'place', re: /^(place|location|offence\s*place)\b/i },
  { key: 'amount', re: /^(amount|fine|penalty)(\s*\(.*?\))?\b/i },
  { key: 'status', re: /^(challan\s*)?(status|payment\s*status)\b/i },
];
const CH_START = /^challan\s*(no\.?|number)\b/i;

export function parseChallans(text: string): ChallanResult | null {
  const lines = toLines(text);
  const starts = lines.map((l, i) => (CH_START.test(l) ? i : -1)).filter(i => i >= 0);
  if (!starts.length) {
    return /\bno\s+(pending\s+)?challans?\b|challan\s+not\s+found|no\s+records?\s+found/i.test(text) ? { items: [], none: true } : null;
  }
  const stop = new RegExp(`${CH_START.source}|${CH_FIELDS.map(f => f.re.source).join('|')}`, 'i');
  const items = starts.map((s, n): Challan => {
    const block = lines.slice(s, starts[n + 1] ?? lines.length);
    const c: Challan = { challanNo: valueAfter(block, CH_START, stop), date: '', offence: '', place: '', amount: '', status: '' };
    for (const f of CH_FIELDS) c[f.key] = valueAfter(block, f.re, stop);
    return c;
  });
  return { items: items.filter(c => c.challanNo || c.offence), none: false };
}

/** True when an ISO date (YYYY-MM-DD) is before today. */
export const isPast = (iso?: string) => !!iso && iso < new Date().toISOString().slice(0, 10);

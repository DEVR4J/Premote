import React, { useEffect, useState } from 'react';

// First-launch intro (animated mascot + "LAW·YAR" + "Let's get started") that leads into a short app tutorial.
// Also used on its own (tutorialOnly) when the advocate replays the tutorial from More.

export const ONBOARDED_KEY = 'advocate-onboarded-v1';

/** Original cartoon: a friendly advocate in a black gown with white neck bands, holding a law book. */
function Mascot() {
  return <svg className="ob-mascot" viewBox="0 0 240 270" aria-hidden="true" focusable="false">
    <defs>
      <linearGradient id="obCircle" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#c37fe9" /><stop offset="1" stopColor="#8449cf" /></linearGradient>
    </defs>
    <g className="ob-bg-shape">
      <circle cx="120" cy="112" r="92" fill="url(#obCircle)" />
      <rect x="24" y="44" width="78" height="11" rx="5.5" fill="#a362dc" />
      <rect x="150" y="56" width="64" height="11" rx="5.5" fill="#b37be3" />
      <rect x="194" y="100" width="34" height="9" rx="4.5" fill="#a362dc" />
      <rect x="18" y="150" width="40" height="9" rx="4.5" fill="#a362dc" />
      {[[58, 86, 7], [186, 74, 6], [204, 152, 5], [46, 130, 5], [152, 34, 5]].map(([x, y, s], i) => <path key={i} className="ob-star" style={{ animationDelay: `${i * 0.35}s` }} d={`M${x} ${(y as number) - (s as number)}L${(x as number) + (s as number) * 0.28} ${(y as number) - (s as number) * 0.28}L${(x as number) + (s as number)} ${y}L${(x as number) + (s as number) * 0.28} ${(y as number) + (s as number) * 0.28}L${x} ${(y as number) + (s as number)}L${(x as number) - (s as number) * 0.28} ${(y as number) + (s as number) * 0.28}L${(x as number) - (s as number)} ${y}L${(x as number) - (s as number) * 0.28} ${(y as number) - (s as number) * 0.28}Z`} fill="#fff" />)}
    </g>
    <ellipse className="ob-shadow" cx="120" cy="256" rx="46" ry="6" fill="#c9a6ec" />
    <g className="ob-float">
      {/* gown */}
      <path d="M68 152C68 130 92 119 120 119s52 11 52 33l7 72c1 10-12 16-59 16s-60-6-59-16z" fill="#2a2342" />
      <path d="M96 128 82 226M144 128l14 98M120 150v84" stroke="#3b3360" strokeWidth="3" strokeLinecap="round" fill="none" />
      {/* white shirt collar and the two neck bands */}
      <path d="M102 121 120 152l18-31z" fill="#fff" />
      <g stroke="#d6cde8" strokeWidth="1.2"><rect x="107" y="140" width="10" height="27" rx="2.5" fill="#fff" transform="rotate(5 112 150)" /><rect x="123" y="140" width="10" height="27" rx="2.5" fill="#fff" transform="rotate(-5 128 150)" /></g>
      {/* sleeves */}
      <ellipse cx="80" cy="176" rx="15" ry="26" fill="#2a2342" transform="rotate(14 80 176)" />
      <ellipse cx="160" cy="176" rx="15" ry="26" fill="#2a2342" transform="rotate(-14 160 176)" />
      {/* law book */}
      <rect x="92" y="190" width="56" height="38" rx="5" fill="#6a3fb5" />
      <rect x="92" y="190" width="9" height="38" rx="4" fill="#53309a" />
      <path d="M110 200h30M110 208h22" stroke="#f3c86b" strokeWidth="2.6" strokeLinecap="round" />
      {/* hands */}
      <circle cx="92" cy="206" r="9" fill="#c98f66" /><circle cx="148" cy="206" r="9" fill="#c98f66" />
      {/* head */}
      <circle cx="78" cy="94" r="8" fill="#c98f66" /><circle cx="162" cy="94" r="8" fill="#c98f66" />
      <circle cx="120" cy="90" r="43" fill="#d49b72" />
      <path d="M77 88C74 52 98 40 122 40c25 0 44 14 42 48-12-17-27-24-44-24-17 0-33 7-43 24z" fill="#2b2036" />
      <ellipse cx="97" cy="106" rx="7" ry="4.2" fill="#f08aa0" opacity=".55" /><ellipse cx="143" cy="106" rx="7" ry="4.2" fill="#f08aa0" opacity=".55" />
      <g className="ob-eyes" stroke="#3a2a2a" strokeWidth="3" strokeLinecap="round" fill="none"><path d="M100 93q8 8 16 0" /><path d="M124 93q8 8 16 0" /></g>
      <g stroke="#3b2a55" strokeWidth="2.2" fill="none"><circle cx="107" cy="93" r="12" /><circle cx="133" cy="93" r="12" /><path d="M119 91q1-2 2 0" /></g>
      <path d="M113 108q7 7 14 0" stroke="#3a2a2a" strokeWidth="3" strokeLinecap="round" fill="none" />
    </g>
  </svg>;
}

const STEPS: { icon: string; title: string; text: string }[] = [
  { icon: '🪪', title: 'Your visiting card', text: 'Home shows your card. Tap it to flip it, and tap the avatar or Edit profile to add your name, Bar Council number and court.' },
  { icon: '➕', title: 'Add your cases', text: 'Tap New Case on Home to save a case by typing, voice or a photo. Case History lists all of them with search, filters and favourites.' },
  { icon: '🔄', title: 'Bring cases from eCourts', text: 'Open More, then "Sync my cases from eCourts". The court site opens inside the app: search as usual, tap Fetch, then Save. The browser stays open, so you can save one case after another.' },
  { icon: '📅', title: 'Never miss a date', text: 'The Diary shows each day\'s hearings. Set the next date on a case, or move it to a new date, in a tap. You can also call the client from there.' },
  { icon: '📝', title: 'Summarize, Draft, Guide', text: 'Pick a case in More to summarize its facts, start a Hindi draft template or see practical next steps. These are starting points: always check them before use.' },
  { icon: '🚗', title: 'Vehicle & Challan', text: 'In More, open "Vehicle & Challan". Look up a vehicle or a challan on the official site inside the app, tap Fetch and Save to keep the result.' },
  { icon: '☁️', title: 'Keep a backup', text: 'Your cases live on this phone. Use More, then Backup, to save a file you can store anywhere, and do it regularly.' },
];

export default function Onboarding({ onFinish, tutorialOnly = false }: { onFinish: () => void; tutorialOnly?: boolean }) {
  const [phase, setPhase] = useState<'intro' | 'tutorial'>(tutorialOnly ? 'tutorial' : 'intro');
  const [step, setStep] = useState(0);
  const [leaving, setLeaving] = useState(false);
  useEffect(() => { document.documentElement.classList.add('ob-open'); return () => document.documentElement.classList.remove('ob-open'); }, []);
  const finish = () => { setLeaving(true); window.setTimeout(onFinish, 320); };
  const last = step === STEPS.length - 1;
  const s = STEPS[step] as { icon: string; title: string; text: string };

  return <div className={`ob${leaving ? ' ob-leave' : ''}`} role="dialog" aria-label={phase === 'intro' ? 'Welcome to LAW·YAR' : 'App tutorial'}>
    <div className="ob-sky" aria-hidden="true" />
    {phase === 'intro' ? <div className="ob-intro">
      <div className="ob-hero"><Mascot /></div>
      <div className="ob-loader" aria-hidden="true"><i /><i /></div>
      <div className="ob-text">
        <h1 className="ob-title">LAW<span>·</span>YAR</h1>
        <p className="ob-sub">assistant at your service</p>
      </div>
      <button className="ob-btn" onClick={() => setPhase('tutorial')}>LET'S GET STARTED</button>
      <button className="ob-skip" onClick={finish}>Skip for now</button>
    </div> : <div className="ob-tut">
      <div className="ob-tut-top"><span className="ob-count">{step + 1} / {STEPS.length}</span><button className="ob-skip ob-skip-top" onClick={finish}>{tutorialOnly ? 'Close' : 'Skip'}</button></div>
      <div className="ob-card" key={step}>
        <div className="ob-ico" aria-hidden="true">{s.icon}</div>
        <h2>{s.title}</h2>
        <p>{s.text}</p>
      </div>
      <div className="ob-dots" aria-hidden="true">{STEPS.map((_, i) => <i key={i} className={i === step ? 'on' : ''} />)}</div>
      <div className="ob-nav">
        <button className="ob-btn ob-btn-ghost" onClick={() => setStep(v => Math.max(0, v - 1))} disabled={step === 0}>Back</button>
        <button className="ob-btn" onClick={() => (last ? finish() : setStep(v => v + 1))}>{last ? (tutorialOnly ? 'DONE' : 'OPEN MY APP') : 'NEXT'}</button>
      </div>
    </div>}
  </div>;
}

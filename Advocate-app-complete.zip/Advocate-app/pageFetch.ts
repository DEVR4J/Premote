// Bridge to the native in-app browser (PageFetchPlugin / BrowserActivity).
// The advocate uses the government site normally (captcha, OTP, search); when they tap "Fetch" the text of
// the page they are viewing comes back here. Only *.gov.in / *.nic.in sites open (enforced natively).
import { Capacitor, registerPlugin } from '@capacitor/core';

type OpenResult = { fetched: boolean; text?: string; url?: string; title?: string };
const PageFetch = registerPlugin<{ open(o: { url: string; title?: string }): Promise<OpenResult> }>('PageFetch');

export const canOpenBrowser = () => Capacitor.isNativePlatform();

/** Opens the site in the in-app browser. Resolves with the page text, or null if closed without fetching. */
export async function fetchFromSite(url: string, title: string): Promise<{ text: string; url: string } | null> {
  if (!canOpenBrowser()) return null;
  const r = await PageFetch.open({ url, title });
  return r.fetched && r.text ? { text: r.text, url: r.url || url } : null;
}

export const SITES = {
  vehicle: 'https://parivahan.gov.in/rcdlstatus/?pur_cd=102',
  challan: 'https://echallan.parivahan.gov.in/index/accused-challan',
  ecourts: 'https://services.ecourts.gov.in/ecourtindia_v6/?p=casestatus/index',
  ecourtsCnr: 'https://services.ecourts.gov.in/ecourtindia_v6/?p=cnr_status/index',
};

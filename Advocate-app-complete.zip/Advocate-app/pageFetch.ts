// Bridge to the native in-app browser (PageFetchPlugin / BrowserActivity).
// The advocate uses the government site normally (captcha, OTP, search). Each time they tap "Fetch" the page
// they are viewing is read, a Save / Cancel box shows what was found, and Save queues it WITHOUT closing the
// browser, so they can open the next case and fetch again. The queue is imported into the app when the
// browser is closed (or the next time the app opens). Only *.gov.in / *.nic.in sites open (enforced natively).
import { Capacitor, registerPlugin } from '@capacitor/core';

export type FetchMode = 'case' | 'list' | 'vehicle' | 'challan';
export type PendingItem =
  | { kind: 'case'; data: { cnr: string; caseNumber: string; title: string; court: string; status: string; initialDate: string; nextHearing: string } }
  | { kind: 'lookup'; data: { id: string; kind: 'vehicle' | 'challan'; title: string; at: number; lines: string[] } };

const PageFetch = registerPlugin<{
  open(o: { url: string; title?: string; mode: FetchMode }): Promise<{ closed: boolean }>;
  takePending(): Promise<{ items: PendingItem[] }>;
}>('PageFetch');

export const canOpenBrowser = () => Capacitor.isNativePlatform();

/** Moves anything saved in the browser into the app (listeners on window 'advocate-pending'). */
export async function collectPending(): Promise<void> {
  if (!canOpenBrowser()) return;
  try {
    const r = await PageFetch.takePending();
    if (r.items && r.items.length) window.dispatchEvent(new CustomEvent('advocate-pending', { detail: r.items }));
  } catch { /* plugin unavailable (older build) */ }
}

/** Opens the site in the in-app browser; resolves when the advocate closes it, after importing what they saved. */
export async function browseSite(url: string, title: string, mode: FetchMode): Promise<void> {
  if (!canOpenBrowser()) return;
  await PageFetch.open({ url, title, mode });
  await collectPending();
}

export const SITES = {
  vehicle: 'https://parivahan.gov.in/rcdlstatus/?pur_cd=102',
  challan: 'https://echallan.parivahan.gov.in/index/accused-challan',
  ecourts: 'https://services.ecourts.gov.in/ecourtindia_v6/?p=casestatus/index',
  ecourtsCnr: 'https://services.ecourts.gov.in/ecourtindia_v6/?p=cnr_status/index',
};

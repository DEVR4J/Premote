
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'in.advocate.personal',
  appName: 'Advocate',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: true,
    backgroundColor: '#fff9ff'
  },
  plugins: {
    StatusBar: {
      style: 'LIGHT',
      backgroundColor: '#fff9ff'
    }
  }
};

export default config;

import React, { useState } from 'react';
import { canOpenBrowser, fetchFromSite, SITES } from './pageFetch';
import { ChallanResult, VehicleInfo, isPast, parseChallans, parseVehicle } from './vehicle';

type Saved = { id: string; kind: 'vehicle' | 'challan'; title: string; at: number; lines: string[] };
const KEY = 'advocate-lookups-v1';
const load = (): Saved[] => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } };
const persist = (x: Saved[]) => { try { localStorage.setItem(KEY, JSON.stringify(x)); } catch { /* storage unavailable */ } };

export default function VehicleChallan() {
  const native = canOpenBrowser();
  const [saved, setSaved] = useState<Saved[]>(load);
  const [veh, setVeh] = useState<VehicleInfo | null>(null); const [cha, setCha] = useState<ChallanResult | null>(null);
  const [msg, setMsg] = useState(''); const [vText, setVText] = useState(''); const [cText, setCText] = useState('');
  const store = (s: Saved) => setSaved(prev => { const next = [s, ...prev].slice(0, 100); persist(next); return next; });
  const remove = (id: string) => setSaved(prev => { const next = prev.filter(x => x.id !== id); persist(next); return next; });

  const readVehicle = (t: string) => { setVText(t); if (!t.trim()) { setVeh(null); setMsg(''); return; } const r = parseVehicle(t); setVeh(r); setMsg(r ? '' : 'This does not look like a vehicle details page. Open the result page and try again.'); };
  const readChallan = (t: string) => { setCText(t); if (!t.trim()) { setCha(null); setMsg(''); return; } const r = parseChallans(t); setCha(r); setMsg(r ? '' : 'This does not look like a challan result page. Open the result page and try again.'); };
  const open = async (url: string, title: string, apply: (t: string) => void) => { setMsg(''); try { const r = await fetchFromSite(url, title); if (r) apply(r.text); else setMsg('Nothing was fetched. Open the result page, then tap Fetch.'); } catch { setMsg('Could not open the browser. Update the app and try again.'); } };

  const saveVehicle = () => { if (!veh) return; store({ id: `v-${Date.now()}`, kind: 'vehicle', title: veh.vehicleNo || 'Vehicle', at: Date.now(), lines: veh.fields.map(f => `${f.label}: ${f.value}`) }); setVeh(null); setVText(''); };
  const saveChallan = () => { if (!cha) return; store({ id: `c-${Date.now()}`, kind: 'challan', title: cha.none ? 'No challans' : `${cha.items.length} challan${cha.items.length > 1 ? 's' : ''}`, at: Date.now(), lines: cha.items.length ? cha.items.map(c => [c.challanNo, c.date, c.offence, c.amount && `₹${c.amount.replace(/[^\d.]/g, '')}`, c.status].filter(Boolean).join(' · ')) : ['No challans found'] }); setCha(null); setCText(''); };

  return <div className="ecourts-sync">
    <div className="notice-card">You use the official government site inside the app: type the vehicle number and captcha there, then tap <b>Fetch</b>. The app reads the page you are looking at. Check important details on the official site.</div>
    <h2>Vehicle details</h2>
    {native ? <button className="wide-button" onClick={() => open(SITES.vehicle, 'Vehicle details', readVehicle)}>Open Parivahan &amp; fetch</button> : <p className="body-copy">The in-app browser works in the installed Android app. Here you can paste the copied page instead.</p>}
    <textarea className="notes-area" style={{ height: 90 }} aria-label="Pasted vehicle page" placeholder="Or paste the copied vehicle page here" value={vText} onChange={e => readVehicle(e.target.value)} />
    {veh && <div className="notice-card" style={{ background: '#e6f4ea', color: '#1d5b34' }}><b>{veh.vehicleNo || 'Vehicle'}</b>{veh.fields.map(f => <div key={f.label}>{f.label}: <b>{f.value}</b>{f.iso && isPast(f.iso) ? <span style={{ color: '#b3261e' }}> · expired</span> : null}</div>)}<button className="wide-button" onClick={saveVehicle}>Save this lookup</button></div>}
    <h2>Challans</h2>
    {native && <button className="wide-button" onClick={() => open(SITES.challan, 'e-Challan', readChallan)}>Open e-Challan &amp; fetch</button>}
    <textarea className="notes-area" style={{ height: 90 }} aria-label="Pasted challan page" placeholder="Or paste the copied challan page here" value={cText} onChange={e => readChallan(e.target.value)} />
    {cha && <div className="notice-card" style={{ background: '#e6f4ea', color: '#1d5b34' }}>{cha.none ? <b>No challans found.</b> : cha.items.map((c, i) => <div key={c.challanNo || i} style={{ marginBottom: 8 }}><b>{c.challanNo || 'Challan'}</b><br />{[c.date, c.offence, c.place].filter(Boolean).join(' · ')}<br />{c.amount ? `Amount: ${c.amount}` : ''}{c.status ? ` · ${c.status}` : ''}</div>)}<button className="wide-button" onClick={saveChallan}>Save this lookup</button></div>}
    {msg && <div className="notice-card" role="alert">{msg}</div>}
    {saved.length > 0 && <><h2>Saved lookups</h2>{saved.map(s => <div key={s.id} className="settings-row" style={{ alignItems: 'flex-start' }}><span style={{ flex: 1 }}><b>{s.title}</b> <small>({s.kind}, {new Date(s.at).toLocaleDateString('en-GB')})</small>{s.lines.map((l, i) => <small key={i} style={{ display: 'block', opacity: .8 }}>{l}</small>)}</span><button type="button" aria-label={`Delete ${s.title}`} onClick={() => remove(s.id)}>✕</button></div>)}</>}
  </div>;
}

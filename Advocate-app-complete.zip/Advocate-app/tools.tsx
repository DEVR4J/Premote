import React, { useEffect, useState } from 'react';

/* =====================================================================
   Tool Box: Area Calc, Unit Converter, Compass (+ bearings, chauhaddi)
   and the animated tiles shown on the Tool Box screen.
   ===================================================================== */

const svgBase = { viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true, focusable: false };
const TrashSmall = () => <svg {...svgBase}><path d="M4 7h16M9 7V4h6v3M6.5 7l1 13h9l1-13M10 11v5M14 11v5" /></svg>;

/* ---------- shared numbers ---------- */
const LEN_M: Record<string, number> = { m: 1, cm: 0.01, ft: 0.3048, in: 0.0254, yd: 0.9144, km: 1000 };
const LEN_UNITS: [string, string][] = [['ft', 'ft'], ['m', 'm'], ['yd', 'yd'], ['in', 'in'], ['cm', 'cm'], ['km', 'km']];
const SQFT = 0.09290304;
const AREA_UNITS: { k: string; l: string; f: number }[] = [
  { k: 'sqmm', l: 'Sq mm', f: 1e-6 }, { k: 'sqcm', l: 'Sq cm', f: 1e-4 }, { k: 'sqm', l: 'Sq m', f: 1 }, { k: 'sqkm', l: 'Sq km', f: 1e6 },
  { k: 'sqin', l: 'Sq in', f: 0.00064516 }, { k: 'sqft', l: 'Sq ft', f: SQFT }, { k: 'sqyd', l: 'Sq yd (Gaj)', f: 0.83612736 },
  { k: 'acre', l: 'Acre', f: 4046.8564224 }, { k: 'hectare', l: 'Hectare', f: 10000 }, { k: 'are', l: 'Are', f: 100 },
  { k: 'cent', l: 'Cent (435.6 sq ft)', f: 435.6 * SQFT }, { k: 'gunta', l: 'Gunta (1089 sq ft)', f: 1089 * SQFT },
  { k: 'marla', l: 'Marla (272.25 sq ft)', f: 272.25 * SQFT }, { k: 'kanal', l: 'Kanal (20 Marla)', f: 5445 * SQFT }];
const CONV_LEN: { k: string; l: string; f: number }[] = [{ k: 'mm', l: 'Millimetre', f: 0.001 }, { k: 'cm', l: 'Centimetre', f: 0.01 }, { k: 'm', l: 'Metre', f: 1 }, { k: 'km', l: 'Kilometre', f: 1000 }, { k: 'in', l: 'Inch', f: 0.0254 }, { k: 'ft', l: 'Foot', f: 0.3048 }, { k: 'yd', l: 'Yard', f: 0.9144 }, { k: 'mile', l: 'Mile', f: 1609.344 }];
const CALC_TABS: [string, string][] = [['rect', 'Rectangle'], ['tri', 'Triangle'], ['quad', 'Quadrilateral'], ['trap', 'Trapezium'], ['circle', 'Circle']];
const fmtNum = (n: number, d = 4) => !Number.isFinite(n) ? '—' : (n !== 0 && (Math.abs(n) < 1e-4 || Math.abs(n) >= 1e12)) ? n.toExponential(4) : n.toLocaleString('en-IN', { maximumFractionDigits: d });
const posNum = (s?: string) => { const n = parseFloat(s ?? ''); return Number.isFinite(n) && n > 0 ? n : NaN; };
const heron = (a: number, b: number, c: number) => { if (!(a + b > c && a + c > b && b + c > a)) return NaN; const p = (a + b + c) / 2; return Math.sqrt(p * (p - a) * (p - b) * (p - c)); };

/* =====================================================================
   Area calculator
   ===================================================================== */
export function AreaCalculator() {
  const [tab, setTab] = useState('rect');
  const [unit, setUnit] = useState('ft');
  const [v, setV] = useState<Record<string, string>>({});
  const [triMode, setTriMode] = useState('bh');
  const set = (k: string, val: string) => setV(p => ({ ...p, [k]: val }));
  const field = (k: string, label: string, ph = '0') => <div className="nc-f wide" key={k}><span className="nc-l">{label}</span><input type="number" inputMode="decimal" min="0" placeholder={ph} value={v[k] ?? ''} onChange={e => set(k, e.target.value)} /></div>;
  const n = (k: string) => posNum(v[k]);
  let area = NaN; let perim = NaN; let err = ''; let hint = ''; let rows: React.ReactElement[] = [];
  if (tab === 'rect') { rows = [field('l', 'Length'), field('w', 'Width')]; area = n('l') * n('w'); perim = 2 * (n('l') + n('w')); }
  if (tab === 'tri') {
    if (triMode === 'bh') { rows = [field('b', 'Base'), field('h', 'Height')]; area = 0.5 * n('b') * n('h'); }
    else { rows = [field('a', 'Side a'), field('b', 'Side b'), field('c', 'Side c')]; const [a, b, c] = [n('a'), n('b'), n('c')]; area = heron(a, b, c); perim = a + b + c; if ([a, b, c].every(x => !Number.isNaN(x)) && Number.isNaN(area)) err = 'These three sides cannot form a triangle.'; }
  }
  if (tab === 'quad') {
    rows = [field('a', 'Side AB'), field('b', 'Side BC'), field('c', 'Side CD'), field('d', 'Side DA'), field('p', 'Diagonal AC')];
    const [a, b, c, d, p] = [n('a'), n('b'), n('c'), n('d'), n('p')];
    area = heron(a, b, p) + heron(c, d, p); perim = a + b + c + d;
    if ([a, b, c, d, p].every(x => !Number.isNaN(x)) && Number.isNaN(area)) err = 'That diagonal does not fit these sides. Check the measurements.';
    hint = 'Measure the sides in order around the plot (AB, BC, CD, DA) and the diagonal AC. The plot is split into two triangles ABC and ACD.';
  }
  if (tab === 'trap') { rows = [field('a', 'Parallel 1'), field('b', 'Parallel 2'), field('h', 'Height')]; area = ((n('a') + n('b')) / 2) * n('h'); hint = 'Height is the perpendicular distance between the two parallel sides.'; }
  if (tab === 'circle') { rows = [field('r', 'Radius')]; area = Math.PI * n('r') * n('r'); perim = 2 * Math.PI * n('r'); }
  const lm = LEN_M[unit] ?? 1;
  const m2 = area * lm * lm;
  const equiv: [string, number][] = [['sq m', m2], ['sq ft', m2 / SQFT], ['sq yd (gaj)', m2 / 0.83612736], ['acre', m2 / 4046.8564224]];
  return <div className="calc-wrap">
    <div className="cx-tabs" role="tablist">{CALC_TABS.map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
    <div className="cx-unit"><span>Measured in</span><div className="seg" role="radiogroup" aria-label="Length unit">{LEN_UNITS.map(([k, l]) => <button key={k} role="radio" aria-checked={unit === k} className={unit === k ? 'on' : ''} onClick={() => setUnit(k)}>{l}</button>)}</div></div>
    {tab === 'tri' && <div className="seg cx-mode" role="radiogroup" aria-label="Triangle input"><button role="radio" aria-checked={triMode === 'bh'} className={triMode === 'bh' ? 'on' : ''} onClick={() => setTriMode('bh')}>Base &amp; height</button><button role="radio" aria-checked={triMode === 'sss'} className={triMode === 'sss' ? 'on' : ''} onClick={() => setTriMode('sss')}>Three sides</button></div>}
    <div className="cx-fields">{rows}</div>
    {hint && <p className="cx-hint">{hint}</p>}
    {err && <p className="cx-error" role="alert">{err}</p>}
    <div className="cx-result"><small>Area</small><strong>{Number.isNaN(area) ? '0' : fmtNum(area)}</strong><span>square {unit}</span>
      {!Number.isNaN(perim) && <em>{tab === 'circle' ? 'Circumference' : 'Perimeter'}: {fmtNum(perim)} {unit}</em>}
      {!Number.isNaN(area) && <div className="cx-equiv">{equiv.filter(([l]) => l !== `sq ${unit}`).map(([l, val]) => <span key={l}><b>{fmtNum(val, 3)}</b> {l}</span>)}</div>}</div>
  </div>;
}

/* =====================================================================
   Unit converter (area + length, custom units)
   ===================================================================== */
export function UnitConverter() {
  const [convMode, setConvMode] = useState('area');
  const [val, setVal] = useState('');
  const [from, setFrom] = useState('sqft');
  const [to, setTo] = useState('sqm');
  const [lfrom, setLfrom] = useState('ft');
  const [lto, setLto] = useState('m');
  const [custom, setCustom] = useState<{ id: string; name: string; sqft: number }[]>(() => { try { const raw = JSON.parse(localStorage.getItem('advocate-custom-units') || '[]'); return Array.isArray(raw) ? raw : []; } catch { return []; } });
  const [cName, setCName] = useState('');
  const [cSqft, setCSqft] = useState('');
  useEffect(() => { localStorage.setItem('advocate-custom-units', JSON.stringify(custom)); }, [custom]);
  const areaUnits = [...AREA_UNITS, ...custom.map(c => ({ k: `cu:${c.id}`, l: `${c.name} (custom)`, f: c.sqft * SQFT }))];
  const af = (k: string) => areaUnits.find(u => u.k === k)?.f ?? 1;
  const lf = (k: string) => CONV_LEN.find(u => u.k === k)?.f ?? 1;
  const cv = posNum(val);
  const out = convMode === 'area' ? cv * af(from) / af(to) : cv * lf(lfrom) / lf(lto);
  const list = convMode === 'area' ? areaUnits : CONV_LEN;
  const addCustom = () => { const sq = parseFloat(cSqft); if (!cName.trim() || !Number.isFinite(sq) || sq <= 0) return; setCustom(prev => [...prev, { id: `${Date.now()}`, name: cName.trim(), sqft: sq }]); setCName(''); setCSqft(''); };
  return <div className="calc-wrap">
    <div className="seg cx-mode" role="radiogroup" aria-label="Converter type"><button role="radio" aria-checked={convMode === 'area'} className={convMode === 'area' ? 'on' : ''} onClick={() => setConvMode('area')}>Area</button><button role="radio" aria-checked={convMode === 'len'} className={convMode === 'len' ? 'on' : ''} onClick={() => setConvMode('len')}>Length</button></div>
    <div className="cx-fields">
      <div className="nc-f wide"><span className="nc-l">Value</span><input type="number" inputMode="decimal" min="0" placeholder="0" value={val} onChange={e => setVal(e.target.value)} /></div>
      <div className="nc-f wide"><span className="nc-l">From</span><select value={convMode === 'area' ? from : lfrom} onChange={e => convMode === 'area' ? setFrom(e.target.value) : setLfrom(e.target.value)} aria-label="From unit">{list.map(u => <option key={u.k} value={u.k}>{u.l}</option>)}</select></div>
      <button className="cx-swap" onClick={() => { if (convMode === 'area') { setFrom(to); setTo(from); } else { setLfrom(lto); setLto(lfrom); } }}>⇅ Swap units</button>
      <div className="nc-f wide"><span className="nc-l">To</span><select value={convMode === 'area' ? to : lto} onChange={e => convMode === 'area' ? setTo(e.target.value) : setLto(e.target.value)} aria-label="To unit">{list.map(u => <option key={u.k} value={u.k}>{u.l}</option>)}</select></div></div>
    <div className="cx-result"><small>Result</small><strong>{Number.isNaN(out) ? '0' : fmtNum(out, 6)}</strong><span>{list.find(u => u.k === (convMode === 'area' ? to : lto))?.l}</span></div>
    {convMode === 'area' && <><div className="cx-all">{areaUnits.map(u => <div key={u.k}><span>{u.l}</span><b>{Number.isNaN(cv) ? '—' : fmtNum(cv * af(from) / u.f, 6)}</b></div>)}</div>
      <div className="cx-custom"><strong>Add your own unit</strong><p>Bigha, biswa and other regional land units differ from state to state, so enter the value used where you practise.</p><div className="nc-f wide"><span className="nc-l">Name</span><input placeholder="e.g. Bigha" value={cName} onChange={e => setCName(e.target.value)} /></div><div className="nc-f wide"><span className="nc-l">Sq ft</span><input type="number" inputMode="decimal" placeholder="Sq ft in 1 unit" value={cSqft} onChange={e => setCSqft(e.target.value)} /></div><button className="sx-pill" onClick={addCustom}>Add unit</button>
        {custom.map(c => <div className="cx-cu" key={c.id}><span>{c.name} = {fmtNum(c.sqft, 4)} sq ft</span><button aria-label={`Delete ${c.name}`} onClick={() => setCustom(prev => prev.filter(x => x.id !== c.id))}><TrashSmall /></button></div>)}</div></>}
  </div>;
}

/* =====================================================================
   Compass + bearings + chauhaddi
   ===================================================================== */
const DIRS: [string, string][] = [['N', 'उत्तर'], ['NE', 'उत्तर-पूर्व'], ['E', 'पूर्व'], ['SE', 'दक्षिण-पूर्व'], ['S', 'दक्षिण'], ['SW', 'दक्षिण-पश्चिम'], ['W', 'पश्चिम'], ['NW', 'उत्तर-पश्चिम']];
const dirOf = (deg: number): [string, string] => DIRS[Math.round((((deg % 360) + 360) % 360) / 45) % 8] ?? ['N', 'उत्तर'];
export function quadrantBearing(deg: number): string {
  const d = ((deg % 360) + 360) % 360;
  if (d === 0) return 'N'; if (d === 90) return 'E'; if (d === 180) return 'S'; if (d === 270) return 'W';
  if (d < 90) return `N ${d.toFixed(0)}° E`;
  if (d < 180) return `S ${(180 - d).toFixed(0)}° E`;
  if (d < 270) return `S ${(d - 180).toFixed(0)}° W`;
  return `N ${(360 - d).toFixed(0)}° W`;
}
/** Heading (0-360, clockwise from north) from absolute device-orientation angles. */
export function headingFrom(alpha: number, beta: number, gamma: number): number {
  const r = Math.PI / 180; const a = alpha * r; const b = beta * r; const g = gamma * r;
  let h: number;
  if (Math.abs(beta) < 50 && Math.abs(gamma) < 60) {
    h = Math.atan2(-Math.sin(a) * Math.cos(b), Math.cos(a) * Math.cos(b)); // phone lying roughly flat: where the top edge points
  } else {
    const vx = -Math.cos(a) * Math.sin(g) - Math.sin(a) * Math.sin(b) * Math.cos(g); // phone held upright: where the back camera points
    const vy = -Math.sin(a) * Math.sin(g) + Math.cos(a) * Math.sin(b) * Math.cos(g);
    h = Math.atan2(vx, vy);
  }
  return ((h * 180) / Math.PI + 360) % 360;
}
type Bearing = { id: string; label: string; deg: number };
const readJson = <T,>(key: string, fallback: T): T => { try { const raw = localStorage.getItem(key); return raw ? (JSON.parse(raw) as T) : fallback; } catch { return fallback; } };

export function CompassTools({ onSaveNote, onToast }: { onSaveNote: (text: string) => void; onToast: (m: string) => void }) {
  const [tab, setTab] = useState('compass');
  const [raw, setRaw] = useState<number | null>(null);
  const [sensor, setSensor] = useState('wait');
  const [manual, setManual] = useState(0);
  const [decl, setDecl] = useState<string>(() => localStorage.getItem('advocate-declination') || '0');
  const [bearings, setBearings] = useState<Bearing[]>(() => readJson<Bearing[]>('advocate-bearings', []));
  const [blabel, setBlabel] = useState('');
  const [ch, setCh] = useState<Record<string, string>>(() => readJson<Record<string, string>>('advocate-chauhaddi', {}));
  useEffect(() => { localStorage.setItem('advocate-declination', decl); }, [decl]);
  useEffect(() => { localStorage.setItem('advocate-bearings', JSON.stringify(bearings)); }, [bearings]);
  useEffect(() => { localStorage.setItem('advocate-chauhaddi', JSON.stringify(ch)); }, [ch]);
  useEffect(() => {
    let got = false; let has = false; let sin = 0; let cos = 0; let last = 0;
    const apply = (deg: number) => {
      const rad = (deg * Math.PI) / 180;
      sin = has ? sin * 0.75 + Math.sin(rad) * 0.25 : Math.sin(rad); cos = has ? cos * 0.75 + Math.cos(rad) * 0.25 : Math.cos(rad); has = true;
      const now = Date.now(); if (now - last < 40) return; last = now;
      setRaw(((Math.atan2(sin, cos) * 180) / Math.PI + 360) % 360); setSensor('ready');
    };
    const onAbs = (e: Event) => { const o = e as DeviceOrientationEvent; if (o.alpha == null) return; got = true; apply(headingFrom(o.alpha, o.beta ?? 0, o.gamma ?? 0)); };
    const onRel = (e: Event) => { const o = e as DeviceOrientationEvent & { webkitCompassHeading?: number }; if (typeof o.webkitCompassHeading === 'number') { got = true; apply(o.webkitCompassHeading); } };
    window.addEventListener('deviceorientationabsolute', onAbs, true);
    window.addEventListener('deviceorientation', onRel, true);
    const timer = setTimeout(() => { if (!got) setSensor('none'); }, 2500);
    return () => { clearTimeout(timer); window.removeEventListener('deviceorientationabsolute', onAbs, true); window.removeEventListener('deviceorientation', onRel, true); };
  }, []);
  const d = parseFloat(decl); const dec = Number.isFinite(d) ? d : 0;
  const base = raw ?? manual;
  const h = (((base + dec) % 360) + 360) % 360;
  const [dn, dh] = dirOf(h);
  const ticks = Array.from({ length: 72 }, (_, i) => i * 5);
  const lock = () => { setBearings(prev => [{ id: `${Date.now()}`, label: blabel.trim() || `Bearing ${prev.length + 1}`, deg: Math.round(h * 10) / 10 }, ...prev]); setBlabel(''); onToast(`Bearing ${h.toFixed(0)}° saved.`); };
  const bearingText = () => bearings.map(b => `${b.label}: ${b.deg}° (${quadrantBearing(b.deg)}) · back bearing ${((b.deg + 180) % 360).toFixed(1)}° (${quadrantBearing(b.deg + 180)})`).join('\n');
  const chRows: [string, string, string][] = [['e', 'पूर्व', 'East'], ['w', 'पश्चिम', 'West'], ['n', 'उत्तर', 'North'], ['s', 'दक्षिण', 'South']];
  const chText = () => { const lines = chRows.filter(([k]) => (ch[k] ?? '').trim()).map(([k, hi]) => `${hi} में: ${(ch[k] ?? '').trim()}`); if (lines.length === 0) return ''; return `चौहद्दी${(ch['plot'] ?? '').trim() ? ` (${(ch['plot'] ?? '').trim()})` : ''}:\n${lines.join('\n')}`; };
  const copy = (t: string) => { if (!t) { onToast('Nothing to copy yet.'); return; } navigator.clipboard?.writeText(t); onToast('Copied.'); };
  return <div className="calc-wrap">
    <div className="cx-tabs" role="tablist">{([['compass', 'Compass'], ['bearing', 'Bearings'], ['chauhaddi', 'Chauhaddi']] as [string, string][]).map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
    {tab === 'compass' && <>
      <div className="cp-wrap"><svg viewBox="0 0 200 200" className="cp-dial" role="img" aria-label={`Heading ${h.toFixed(0)} degrees, ${dn}`}>
        <circle cx="100" cy="100" r="97" className="cp-ring" />
        <g transform={`rotate(${-h} 100 100)`}>
          {ticks.map(t => <line key={t} x1="100" y1="6" x2="100" y2={t % 30 === 0 ? 19 : 13} transform={`rotate(${t} 100 100)`} className={t % 90 === 0 ? 'cp-t major' : 'cp-t'} />)}
          {([['N', 0], ['E', 90], ['S', 180], ['W', 270]] as [string, number][]).map(([l, a]) => <text key={l} x="100" y="44" textAnchor="middle" transform={`rotate(${a} 100 100)`} className={l === 'N' ? 'cp-n' : 'cp-l'}>{l}</text>)}
          {([['NE', 45], ['SE', 135], ['SW', 225], ['NW', 315]] as [string, number][]).map(([l, a]) => <text key={l} x="100" y="36" textAnchor="middle" transform={`rotate(${a} 100 100)`} className="cp-s">{l}</text>)}
        </g>
        <path d="M100 3 L92 19 L108 19 Z" className="cp-ptr" />
        <circle cx="100" cy="100" r="3.5" className="cp-dot" />
      </svg>
        <div className="cp-read"><strong>{h.toFixed(0)}°</strong><span>{dn} · {dh}</span></div></div>
      {sensor === 'wait' && <p className="cx-hint">Looking for the compass sensor…</p>}
      {sensor === 'none' && <div className="cp-manual"><p className="cx-error">Compass sensor not available on this device. You can set the direction by hand.</p><input type="range" min="0" max="359" value={manual} onChange={e => setManual(Number(e.target.value))} aria-label="Set direction manually" /></div>}
      <div className="cx-fields"><div className="nc-f wide"><span className="nc-l">Declination °</span><input type="number" step="0.1" inputMode="decimal" placeholder="0" value={decl} onChange={e => setDecl(e.target.value)} /></div></div>
      <p className="cx-hint">Hold the phone flat, away from metal and magnets. If the reading drifts, wave the phone in a figure "8" to calibrate. Declination is the local difference between magnetic and true north; leave 0 for magnetic north.</p>
    </>}
    {tab === 'bearing' && <>
      <div className="cp-live"><b>{h.toFixed(0)}°</b><span>{dn} · {dh}</span><em>{quadrantBearing(h)}</em></div>
      <div className="cx-fields"><div className="nc-f wide"><span className="nc-l">Label</span><input placeholder="e.g. Corner A to B" value={blabel} onChange={e => setBlabel(e.target.value)} /></div></div>
      <button className="sx-pill cp-lock" onClick={lock}>Lock bearing {h.toFixed(0)}°</button>
      {bearings.length === 0 && <p className="cx-hint">Point the top of the phone along a boundary line or towards a landmark and tap Lock. Each saved bearing also shows its back bearing.</p>}
      {bearings.map(b => <div className="cp-row" key={b.id}><div><b>{b.label}</b><span>{b.deg}° · {quadrantBearing(b.deg)}</span><small>Back bearing {((b.deg + 180) % 360).toFixed(1)}° · {quadrantBearing(b.deg + 180)}</small></div><button aria-label={`Delete ${b.label}`} onClick={() => setBearings(prev => prev.filter(x => x.id !== b.id))}><TrashSmall /></button></div>)}
      {bearings.length > 0 && <div className="doc-actions"><button className="sx-pill ghost" onClick={() => copy(bearingText())}>Copy all</button><button className="sx-pill ghost" onClick={() => setBearings([])}>Clear</button></div>}
    </>}
    {tab === 'chauhaddi' && <>
      <div className="cp-live"><b>{h.toFixed(0)}°</b><span>You are facing {dn} · {dh}</span></div>
      <div className="cx-fields"><div className="nc-f wide"><span className="nc-l">Plot / Khasra</span><input placeholder="Optional" value={ch['plot'] ?? ''} onChange={e => setCh(p => ({ ...p, plot: e.target.value }))} /></div>
        {chRows.map(([k, hi, en]) => <div className="nc-f wide" key={k}><span className="nc-l">{hi}</span><input placeholder={`${en} boundary`} value={ch[k] ?? ''} onChange={e => setCh(p => ({ ...p, [k]: e.target.value }))} /></div>)}</div>
      {chText() && <pre className="cp-pre">{chText()}</pre>}
      <div className="doc-actions"><button className="sx-pill" onClick={() => copy(chText())}>Copy text</button><button className="sx-pill ghost" onClick={() => { const t = chText(); if (!t) { onToast('Fill at least one boundary.'); return; } onSaveNote(t); }}>Add to Notes</button><button className="sx-pill ghost" onClick={() => setCh({})}>Clear</button></div>
    </>}
  </div>;
}

/* =====================================================================
   Animated tiles for the Tool Box screen
   ===================================================================== */
type Pt = [number, number];
function morphPoints(verts: Pt[], n: number): string {
  // start at the vertex nearest the top-left, go clockwise, and keep every real corner
  let start = 0; let best = Infinity;
  verts.forEach((p, i) => { const s = p[0] + p[1]; if (s < best) { best = s; start = i; } });
  const vs = [...verts.slice(start), ...verts.slice(0, start)];
  const lens = vs.map((p, i) => { const q = vs[(i + 1) % vs.length] ?? p; return Math.hypot(q[0] - p[0], q[1] - p[1]); });
  const perim = lens.reduce((a, b) => a + b, 0);
  const counts = lens.map(l => Math.max(1, Math.round((n * l) / perim)));
  let diff = n - counts.reduce((a, b) => a + b, 0);
  let guard = 0;
  while (diff !== 0 && guard++ < 100) { const idx = counts.indexOf(Math.max(...counts)); counts[idx] = (counts[idx] ?? 1) + (diff > 0 ? 1 : -1); diff += diff > 0 ? -1 : 1; }
  const out: string[] = [];
  vs.forEach((p, i) => { const q = vs[(i + 1) % vs.length] ?? p; const k = counts[i] ?? 1; for (let j = 0; j < k; j++) { const t = j / k; out.push(`${(p[0] + (q[0] - p[0]) * t).toFixed(1)},${(p[1] + (q[1] - p[1]) * t).toFixed(1)}`); } });
  return out.join(' ');
}
const circleVerts = (n: number): Pt[] => Array.from({ length: n }, (_, i) => { const a = (-135 + (i * 360) / n) * (Math.PI / 180); return [50 + 29 * Math.cos(a), 40 + 29 * Math.sin(a)] as Pt; });
const N_MORPH = 40;
const SHAPES: { pts: string; fill: string; label: string; formula: string }[] = [
  { pts: morphPoints([[14, 16], [86, 16], [86, 64], [14, 64]], N_MORPH), fill: '#1f9a3a', label: 'Rectangle', formula: 'l × w' },
  { pts: morphPoints([[50, 10], [90, 68], [10, 68]], N_MORPH), fill: '#13917e', label: 'Triangle', formula: '½ × b × h' },
  { pts: morphPoints([[18, 18], [86, 10], [78, 66], [10, 58]], N_MORPH), fill: '#1f75ab', label: 'Quadrilateral', formula: '2 triangles' },
  { pts: morphPoints([[32, 16], [70, 16], [92, 64], [8, 64]], N_MORPH), fill: '#c98a2b', label: 'Trapezium', formula: '½ (a+b) × h' },
  { pts: morphPoints(circleVerts(N_MORPH), N_MORPH), fill: '#8e57c7', label: 'Circle', formula: 'π × r²' },
];
function morphAnim(dur: number) {
  const n = SHAPES.length; const seg = 1 / n; const hold = 0.6;
  const kt: number[] = [0]; const pts: string[] = [SHAPES[0]?.pts ?? '']; const fills: string[] = [SHAPES[0]?.fill ?? ''];
  for (let i = 0; i < n; i++) {
    const cur = SHAPES[i]; const next = SHAPES[(i + 1) % n]; if (!cur || !next) continue;
    kt.push(i * seg + seg * hold); pts.push(cur.pts); fills.push(cur.fill);
    kt.push((i + 1) * seg); pts.push(next.pts); fills.push(next.fill);
  }
  const splines = kt.slice(1).map(() => '0.45 0 0.2 1').join(';');
  return { dur: `${dur}s`, keyTimes: kt.map(k => k.toFixed(4)).join(';'), pts: pts.join(';'), fills: fills.join(';'), splines };
}
/** SVG animations run on the page clock; restart this one when the tile appears so it stays in step with the labels. */
function syncSmil(el: SVGSVGElement | null) { if (el && typeof el.setCurrentTime === 'function') el.setCurrentTime(0); }
function AreaArt({ animated, speed }: { animated: boolean; speed: number }) {
  const m = morphAnim(10 * speed);
  const first = SHAPES[0];
  return <div className="ar-art"><svg ref={syncSmil} viewBox="0 0 100 80" aria-hidden="true" focusable="false">
    <polygon points={first?.pts ?? ''} fill={first?.fill ?? '#1f9a3a'}>
      {animated && <><animate attributeName="points" dur={m.dur} repeatCount="indefinite" calcMode="spline" keyTimes={m.keyTimes} keySplines={m.splines} values={m.pts} />
        <animate attributeName="fill" dur={m.dur} repeatCount="indefinite" calcMode="spline" keyTimes={m.keyTimes} keySplines={m.splines} values={m.fills} /></>}
    </polygon></svg>
    <div className="ar-labels">{SHAPES.map((s, i) => <span key={s.label} className="ar-label" style={animated ? { animationDelay: `${(i * 10 * speed) / SHAPES.length}s` } : i === 0 ? { opacity: 1, animation: 'none' } : { display: 'none' }}>{s.label}<em>{s.formula}</em></span>)}</div></div>;
}
const UNIT_PAIRS: [string, string][] = [['1 acre', '43,560 sq ft'], ['1 ft', '0.3048 m'], ['1 gaj', '9 sq ft'], ['1 hectare', '2.471 acre']];
function UnitArt({ animated }: { animated: boolean }) {
  return <div className="ut-art" aria-hidden="true">{UNIT_PAIRS.map(([a, b], i) => <div key={a} className="ut-pair" style={animated ? { animationDelay: `${i * 3}s` } : i === 0 ? { opacity: 1, animation: 'none' } : { display: 'none' }}><span className="ut-a">{a}</span><span className="ut-arrow" style={animated ? { animationDelay: `${i * 3}s` } : { animation: 'none' }}>⇄</span><span className="ut-b">{b}</span></div>)}</div>;
}
function CompassArt({ animated }: { animated: boolean }) {
  return <svg viewBox="0 0 100 100" className="cp-art" aria-hidden="true" focusable="false">
    <circle cx="50" cy="50" r="46" className="cp-art-ring" />
    {Array.from({ length: 36 }, (_, i) => i * 10).map(t => <line key={t} x1="50" y1="6" x2="50" y2={t % 90 === 0 ? 15 : 11} transform={`rotate(${t} 50 50)`} className="cp-art-tick" />)}
    <text x="50" y="27" textAnchor="middle" className="cp-art-n">N</text><text x="76" y="54" textAnchor="middle" className="cp-art-l">E</text><text x="50" y="82" textAnchor="middle" className="cp-art-l">S</text><text x="24" y="54" textAnchor="middle" className="cp-art-l">W</text>
    <g className={animated ? 'cp-needle' : ''}><path d="M50 18 L56 50 L44 50 Z" className="cp-art-red" /><path d="M50 82 L56 50 L44 50 Z" className="cp-art-white" /></g>
    <circle cx="50" cy="50" r="4" className="cp-art-pin" /></svg>;
}
export function ToolTiles({ go, animated, speed }: { go: (s: string) => void; animated: boolean; speed: number }) {
  return <div className="tb-list">
    <button className="tb-tile area" onClick={() => go('calculator')}><span className="tb-art"><AreaArt animated={animated} speed={speed} /></span><span className="tb-text"><b>Area Calc</b><small>Rectangle, triangle, quadrilateral, trapezium and circle</small></span></button>
    <button className="tb-tile unit" onClick={() => go('converter')}><span className="tb-art"><UnitArt animated={animated} /></span><span className="tb-text"><b>Unit Converter</b><small>Acre, gaj, marla, kanal, feet, metres and your own units</small></span></button>
    <button className="tb-tile compass" onClick={() => go('compass')}><span className="tb-art"><CompassArt animated={animated} /></span><span className="tb-text"><b>Compass</b><small>Direction, bearings and chauhaddi (boundaries)</small></span></button>
  </div>;
}

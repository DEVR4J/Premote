import { Capacitor, CapacitorHttp } from '@capacitor/core';

/* =====================================================================
   AI service for Advocate.
   - Works with the API keys the user adds in Interface > AI API keys.
   - Tries the ACTIVE keys in the order listed; if one fails (bad key,
     quota, outage) it moves on to the next one.
   - On the phone it uses Capacitor's native HTTP so provider CORS rules
     do not apply; in a browser it falls back to fetch().
   ===================================================================== */

export type AiKey = {
  id: string;
  provider: string;
  label: string;
  key: string;
  active: boolean;
  model?: string;
  baseUrl?: string;
  status?: 'ok' | 'error';
  note?: string;
  lastUsed?: number;
};

export const AI_PROVIDERS: [string, string][] = [
  ['anthropic', 'Anthropic (Claude)'],
  ['openai', 'OpenAI'],
  ['gemini', 'Google Gemini'],
  ['mistral', 'Mistral'],
  ['groq', 'Groq'],
  ['other', 'Other (OpenAI-compatible)'],
];

export const AI_KEYS_STORE = 'advocate-ai-keys';

/** Default model per provider. Model names change over time, so every key can override it. */
const DEFAULT_MODELS: Record<string, { text: string; vision: string }> = {
  anthropic: { text: 'claude-sonnet-5-5', vision: 'claude-sonnet-5-5' },
  openai: { text: 'gpt-4o-mini', vision: 'gpt-4o-mini' },
  gemini: { text: 'gemini-flash-latest', vision: 'gemini-flash-latest' },
  mistral: { text: 'mistral-small-latest', vision: 'mistral-small-latest' },
  groq: { text: 'llama-3.3-70b-versatile', vision: 'meta-llama/llama-4-scout-17b-16e-instruct' },
};

const OPENAI_BASES: Record<string, string> = {
  openai: 'https://api.openai.com/v1',
  mistral: 'https://api.mistral.ai/v1',
  groq: 'https://api.groq.com/openai/v1',
};

export function loadAiKeys(): AiKey[] {
  try {
    const raw = JSON.parse(localStorage.getItem(AI_KEYS_STORE) || '[]');
    return Array.isArray(raw) ? (raw as AiKey[]).filter(k => k && typeof k.key === 'string') : [];
  } catch {
    return [];
  }
}

export function saveAiKeys(keys: AiKey[]) {
  localStorage.setItem(AI_KEYS_STORE, JSON.stringify(keys));
}

/** Active keys, in the order the user listed them. */
export function getActiveAiKeys(): AiKey[] {
  return loadAiKeys().filter(k => k.active && k.key);
}

export class AiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export type AiImage = { mime: string; data: string };
export type AskOptions = { system?: string; prompt: string; image?: AiImage; maxTokens?: number; json?: boolean };

type HttpResult = { status: number; data: any };

async function postJson(url: string, headers: Record<string, string>, body: unknown, timeoutMs = 90000): Promise<HttpResult> {
  const allHeaders = { 'Content-Type': 'application/json', ...headers };
  try {
    if (Capacitor.isNativePlatform()) {
      const res = await CapacitorHttp.request({ url, method: 'POST', headers: allHeaders, data: body, connectTimeout: 20000, readTimeout: timeoutMs });
      let data: any = res.data;
      if (typeof data === 'string') { try { data = JSON.parse(data); } catch { /* keep text */ } }
      return { status: res.status, data };
    }
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(url, { method: 'POST', headers: allHeaders, body: JSON.stringify(body), signal: ctrl.signal });
      let data: any = null;
      try { data = await res.json(); } catch { /* empty body */ }
      return { status: res.status, data };
    } finally {
      clearTimeout(timer);
    }
  } catch (e) {
    throw new AiError(0, e instanceof Error ? e.message : 'Network error');
  }
}

function errMessage(data: any): string {
  if (!data) return '';
  if (typeof data === 'string') return data.slice(0, 200);
  const m = data.error?.message ?? data.message ?? data.error;
  return typeof m === 'string' ? m : '';
}

function describeFailure(e: unknown): string {
  if (!(e instanceof AiError)) return e instanceof Error ? e.message.slice(0, 120) : 'Unknown error';
  if (e.status === 401 || e.status === 403) return 'Invalid key or no access';
  if (e.status === 429) return 'Rate limit or quota reached';
  if (e.status >= 500) return 'Provider unavailable';
  if (e.status === 0) return 'No connection';
  return e.message.slice(0, 120) || `Error ${e.status}`;
}

/** One request to one key. Throws AiError on failure. */
export async function callProvider(k: AiKey, o: AskOptions): Promise<string> {
  const vision = !!o.image;
  const defaults = DEFAULT_MODELS[k.provider];
  const model = (k.model || '').trim() || (defaults ? (vision ? defaults.vision : defaults.text) : '');
  const maxTokens = o.maxTokens ?? 1500;

  if (k.provider === 'anthropic') {
    const content: unknown[] = [];
    if (o.image) content.push({ type: 'image', source: { type: 'base64', media_type: o.image.mime, data: o.image.data } });
    content.push({ type: 'text', text: o.prompt });
    const res = await postJson('https://api.anthropic.com/v1/messages', { 'x-api-key': k.key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, { model, max_tokens: maxTokens, ...(o.system ? { system: o.system } : {}), messages: [{ role: 'user', content }] });
    if (res.status < 200 || res.status >= 300) throw new AiError(res.status, errMessage(res.data));
    const parts: any[] = Array.isArray(res.data?.content) ? res.data.content : [];
    const text = parts.filter(p => p && p.type === 'text').map(p => String(p.text ?? '')).join('').trim();
    if (!text) throw new AiError(502, 'Empty response');
    return text;
  }

  if (k.provider === 'gemini') {
    if (!model) throw new AiError(400, 'No model set');
    const parts: unknown[] = [{ text: o.prompt }];
    if (o.image) parts.push({ inline_data: { mime_type: o.image.mime, data: o.image.data } });
    const res = await postJson(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, { 'x-goog-api-key': k.key }, {
      ...(o.system ? { systemInstruction: { parts: [{ text: o.system }] } } : {}),
      contents: [{ role: 'user', parts }],
      generationConfig: { maxOutputTokens: maxTokens, ...(o.json ? { responseMimeType: 'application/json' } : {}) },
    });
    if (res.status < 200 || res.status >= 300) throw new AiError(res.status, errMessage(res.data));
    const cparts: any[] = res.data?.candidates?.[0]?.content?.parts ?? [];
    const text = cparts.map(p => String(p?.text ?? '')).join('').trim();
    if (!text) throw new AiError(502, 'Empty response');
    return text;
  }

  // OpenAI, Mistral, Groq and "other" all speak the OpenAI chat-completions format.
  const base = k.provider === 'other' ? (k.baseUrl || '').trim().replace(/\/+$/, '') : OPENAI_BASES[k.provider];
  if (!base) throw new AiError(400, 'No base URL set');
  if (!model) throw new AiError(400, 'No model set');
  const userContent = o.image
    ? [{ type: 'text', text: o.prompt }, { type: 'image_url', image_url: { url: `data:${o.image.mime};base64,${o.image.data}` } }]
    : o.prompt;
  const body: Record<string, unknown> = { model, messages: [...(o.system ? [{ role: 'system', content: o.system }] : []), { role: 'user', content: userContent }] };
  body[k.provider === 'openai' ? 'max_completion_tokens' : 'max_tokens'] = maxTokens;
  if (o.json && (k.provider === 'openai' || k.provider === 'mistral')) body.response_format = { type: 'json_object' };
  const res = await postJson(`${base}/chat/completions`, { Authorization: `Bearer ${k.key}` }, body);
  if (res.status < 200 || res.status >= 300) throw new AiError(res.status, errMessage(res.data));
  const msg = res.data?.choices?.[0]?.message?.content;
  const text = (typeof msg === 'string' ? msg : Array.isArray(msg) ? msg.map((p: any) => String(p?.text ?? '')).join('') : '').trim();
  if (!text) throw new AiError(502, 'Empty response');
  return text;
}

function patchKey(id: string, patch: Partial<AiKey>) {
  const keys = loadAiKeys();
  saveAiKeys(keys.map(k => (k.id === id ? { ...k, ...patch } : k)));
}

/** Ask the AI. Tries every active key in order and returns the first success. */
export async function askAI(o: AskOptions): Promise<{ text: string; via: string }> {
  const keys = getActiveAiKeys();
  if (keys.length === 0) throw new Error('Add an AI API key in Interface to use AI.');
  const failures: string[] = [];
  for (const k of keys) {
    try {
      const text = await callProvider(k, o);
      patchKey(k.id, { status: 'ok', note: '', lastUsed: Date.now() });
      return { text, via: k.label };
    } catch (e) {
      const why = describeFailure(e);
      patchKey(k.id, { status: 'error', note: why });
      failures.push(`${k.label}: ${why}`);
    }
  }
  throw new Error(`AI request failed. ${failures.join(' · ')}`);
}

/** Quick check that one specific key works. */
export async function testAiKey(k: AiKey): Promise<string> {
  try {
    await callProvider(k, { prompt: 'Reply with the single word OK.', maxTokens: 16 });
    patchKey(k.id, { status: 'ok', note: '', lastUsed: Date.now() });
    return 'ok';
  } catch (e) {
    const why = describeFailure(e);
    patchKey(k.id, { status: 'error', note: why });
    return why;
  }
}

export function parseJsonLoose(text: string): any {
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) return null;
  try { return JSON.parse(m[0]); } catch { return null; }
}

/* ---------------------------- prompts ---------------------------- */

export const SYSTEM_BASE =
  'You are a careful assistant for an Indian advocate. You only work with the facts the advocate provides. ' +
  'Never invent case names, citations, section numbers, dates or facts. If something is uncertain, say so and mark it "verify". ' +
  'Reply in the same language as the advocate\'s material (Hindi in Devanagari, or English). ' +
  'Write plain text only: no markdown symbols such as **, # or backticks. Use simple numbering (1., 2.) where a list helps.';

export const DRAFT_SYSTEM =
  SYSTEM_BASE +
  ' You draft formal legal documents. Unless the advocate asks otherwise, write in formal Hindi (Devanagari) legal language. ' +
  'Use [square-bracket placeholders] for any information that was not provided; do not make up names, dates or facts. ' +
  'Use the usual structure: addressee, subject, body, prayer, date and place, signature block. ' +
  'End with one short line reminding the advocate to verify facts, forum and applicable law before filing.';

export type CaseContext = { title?: string; court?: string; initialDate?: string; nextHearing?: string; status?: string; narrative?: string };

function caseBlock(c?: CaseContext): string {
  if (!c) return '';
  const lines = [
    c.title ? `Case: ${c.title}` : '',
    c.court ? `Court: ${c.court}` : '',
    c.initialDate ? `Filed / first date: ${c.initialDate}` : '',
    c.nextHearing ? `Next hearing: ${c.nextHearing}` : '',
    c.status ? `Status: ${c.status}` : '',
    c.narrative ? `Facts: ${c.narrative.slice(0, 6000)}` : '',
  ].filter(Boolean);
  return lines.length ? `\n\nCase details provided by the advocate:\n${lines.join('\n')}` : '';
}

export const prompts = {
  summarize: (text: string, c?: CaseContext) =>
    'Summarise the following for the advocate in about 200 words. Use these headings: 1. Parties and forum  2. Key facts in order  3. Present stage and next date  4. Issues to examine  5. Information that is missing. ' +
    `Do not add facts that are not in the material.\n\nMaterial:\n${text.slice(0, 12000)}${caseBlock(c)}`,
  draft: (instruction: string, c?: CaseContext) => `Prepare this document:\n${instruction}${c ? '\n\nUse the case details below only where they are relevant to this request.' : ''}${caseBlock(c)}`,
  guide: (c?: CaseContext) =>
    'Give practical next steps for the advocate on this matter: 1. Immediate steps  2. Documents and evidence to collect  3. Points to prepare for the next hearing  4. Time limits and procedural checks to verify. ' +
    'Mark every legal reference as "verify". This is a working checklist, not legal advice.' + caseBlock(c),
  similar: (c?: CaseContext) =>
    'Help the advocate research similar matters WITHOUT inventing any case citation. Do not name a case unless you are certain it exists, and even then mark it "verify". ' +
    'Provide: 1. Legal issues in this matter  2. Statutes or provisions that may be relevant (mark each "verify")  3. Kinds of precedents and the points of law to look for  4. Six to eight search queries to try on Indian Kanoon, SCC Online, Manupatra or court websites.' + caseBlock(c),
  transcribe:
    'Transcribe all the text in this image exactly as written. Keep Hindi in Devanagari and English as it is. It may be handwritten or a printed legal document. ' +
    'Keep the line breaks. Mark unreadable words as [illegible]. Output only the transcription, with no commentary.',
  extract: (text: string, today: string) =>
    `From the case notes below, extract details. Today's date is ${today}. Reply with ONLY a JSON object with these keys: ` +
    '"title" (the parties, like "Ram vs Shyam"), "court", "initialDate" (YYYY-MM-DD), "nextHearing" (YYYY-MM-DD), "phone" (digits only). ' +
    `Use an empty string for anything that is not stated. Do not guess.\n\nNotes:\n${text.slice(0, 8000)}`,
  search: (query: string, cases: { id: string; title: string; court: string; status: string; initialDate: string; nextHearing: string; note: string }[]) =>
    'The advocate is asking a question. Their saved cases are listed as JSON. If the question is about their cases, answer from that list and return the matching case ids. ' +
    'If it is a general legal question, answer briefly and add "verify before relying on this". Reply with ONLY a JSON object: {"answer": "<short plain text>", "caseIds": ["<id>", ...]}.\n\n' +
    `Question: ${query}\n\nCases:\n${JSON.stringify(cases)}`,
};

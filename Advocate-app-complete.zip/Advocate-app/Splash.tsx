import React, { useEffect, useMemo, useState } from 'react';

// Opening animation: the app's pastel scalloped shapes pop in around a purple badge, the ADVOCATE wordmark
// rises letter by letter, then the whole screen fades into Home. Tap to skip. Honours "Reduce motion".
function scallopPath(lobes: number, amp: number) { const pts: string[] = []; const n = 160; for (let i = 0; i < n; i++) { const t = (i / n) * Math.PI * 2; const r = 48 * (1 + amp * Math.cos(lobes * t)) / (1 + amp); pts.push(`${(r * Math.cos(t)).toFixed(2)},${(r * Math.sin(t)).toFixed(2)}`); } return `M${pts.join('L')}Z`; }
function Blob({ lobes, amp = 0.08, color, className, style }: { lobes: number; amp?: number; color: string; className: string; style?: React.CSSProperties }) {
  const d = useMemo(() => scallopPath(lobes, amp), [lobes, amp]);
  return <span className={`spl-blob ${className}`} style={{ color, ...style }}><svg viewBox="-50 -50 100 100" aria-hidden="true" focusable="false"><path d={d} fill="currentColor" /></svg></span>;
}
const ScalesIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><path d="M12 5.5v13M8.5 19.5h7M5 7.5h14M5 7.5l-2.3 5.7M5 7.5l2.3 5.7M19 7.5l-2.3 5.7M19 7.5l2.3 5.7" /><path d="M2.7 13.2a2.3 2.3 0 0 0 4.6 0zM16.7 13.2a2.3 2.3 0 0 0 4.6 0z" /></svg>;

export default function Splash({ onDone }: { onDone: () => void }) {
  const [leaving, setLeaving] = useState(false);
  const reduced = useMemo(() => { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches || document.body.classList.contains('reduce-motion'); } catch { return false; } }, []);
  useEffect(() => {
    const hold = window.setTimeout(() => setLeaving(true), reduced ? 700 : 2300);
    const end = window.setTimeout(onDone, reduced ? 950 : 2800);
    return () => { window.clearTimeout(hold); window.clearTimeout(end); };
  }, [onDone, reduced]);
  const skip = () => { setLeaving(true); window.setTimeout(onDone, 250); };
  return <div className={`spl${leaving ? ' spl-leave' : ''}${reduced ? ' spl-still' : ''}`} onClick={skip} role="img" aria-label="Advocate">
    <Blob lobes={7} color="#f1cddd" className="spl-b1" />
    <Blob lobes={6} color="#cef2e7" className="spl-b2" />
    <Blob lobes={8} color="#f5e6c9" className="spl-b3" />
    <Blob lobes={9} color="#e3cff3" className="spl-b4" />
    <div className="spl-center">
      <span className="spl-badge"><Blob lobes={8} color="#5550cb" className="spl-badge-shape" /><i><ScalesIcon /></i></span>
      <div className="spl-word" aria-hidden="true">{'ADVOCATE'.split('').map((c, i) => <span key={i} style={{ '--i': i } as React.CSSProperties}>{c}</span>)}</div>
      <p className="spl-tag">Your personal legal companion</p>
    </div>
  </div>;
}

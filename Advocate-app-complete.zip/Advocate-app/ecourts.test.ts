import { describe, expect, it } from 'vitest';
import { parseCaseDetails, parseCourtDate, parsePasted, splitNewAndKnown } from './ecourts';

// NOTE: these samples are hand-written approximations of text copied from the eCourts result page,
// not captures of the live site. Re-check with real pasted text on a device.
const phone = `Civil Judge (Junior Division), Kannauj
Sr No
Case Number
Party Name
1
CC/123/2021
Ram Kumar
Vs
State of UP
View
2
Regular Civil Suit/45/2019
Sunita Devi Vs Ranjan Kumar Katiyar
View
Additional District Judge Court No 2, Kannauj
1
Cri. Misc. Bail Application/ 7 /2024
Mohan Lal Vs State of UP
View`;
const desktop = `Civil Judge (Junior Division), Kannauj
1\tCC/123/2021\tRam Kumar Vs State of UP\tView
2\tRCS/45/2019\tSunita Devi Vs Ranjan Kumar Katiyar\tView`;

describe('parsePasted', () => {
  it('reads phone-style copied text with court headings', () => {
    const r = parsePasted(phone);
    expect(r.map(c => c.caseNumber)).toEqual(['CC/123/2021', 'Regular Civil Suit/45/2019', 'Cri. Misc. Bail Application/7/2024']);
    expect(r[0]).toMatchObject({ title: 'Ram Kumar vs State of UP', court: 'Civil Judge (Junior Division), Kannauj' });
    expect(r[1]?.title).toBe('Sunita Devi vs Ranjan Kumar Katiyar');
    expect(r[2]?.court).toBe('Additional District Judge Court No 2, Kannauj');
  });
  it('reads tab-separated (desktop) text', () => {
    const r = parsePasted(desktop);
    expect(r).toHaveLength(2);
    expect(r[1]).toMatchObject({ caseNumber: 'RCS/45/2019', title: 'Sunita Devi vs Ranjan Kumar Katiyar' });
  });
  it('returns nothing for unrelated text', () => { expect(parsePasted('hello world')).toEqual([]); });
  it('does not duplicate known cases', () => {
    const r = parsePasted(desktop);
    const { fresh, known } = splitNewAndKnown(r, [{ caseNumber: 'CC/123/2021', court: 'Civil Judge (Junior Division), Kannauj' }]);
    expect(fresh).toHaveLength(1); expect(known).toHaveLength(1);
  });
});

describe('parseCaseDetails', () => {
  const page = `Case Type\nRegular Civil Suit\nRegistration Number\n45/2021\nRegistration Date\n10-03-2021\nCNR Number\nUPKN010012342021 (Note the CNR number)\nNext Hearing Date\n26th November 2026\nCourt Number and Judge\n5 - Civil Judge, Kannauj\nPetitioner and Advocate\n1) Sunita Devi\nAdvocate- Ramesh Sharma\nRespondent and Advocate\n1) Ranjan Kumar Katiyar\nActs`;
  it('reads one case page', () => {
    expect(parseCaseDetails(page)).toMatchObject({ cnr: 'UPKN010012342021', caseNumber: 'Regular Civil Suit/45/2021', title: 'Sunita Devi vs Ranjan Kumar Katiyar', nextHearing: '2026-11-26', initialDate: '2021-03-10', status: 'Pending' });
  });
  it('rejects unrelated text', () => { expect(parseCaseDetails('hello')).toBeNull(); });
  it('reads dates', () => { expect(parseCourtDate('1st Dec 2026')).toBe('2026-12-01'); expect(parseCourtDate('7/1/2027')).toBe('2027-01-07'); });
});

describe('parsePasted with CNR', () => {
  it('keeps the CNR out of the case title', () => {
    const r = parsePasted('Civil Judge (Junior Division), Kannauj\n1\nCC/123/2021\nRam Kumar Vs State of UP\nUPKN010012342021\nView');
    expect(r[0]).toMatchObject({ cnr: 'UPKN010012342021', title: 'Ram Kumar vs State of UP' });
  });
});

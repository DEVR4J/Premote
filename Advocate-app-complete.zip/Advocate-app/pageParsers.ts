// Runs INSIDE the in-app browser page (injected by BrowserActivity when "Fetch" is tapped).
// Reads the page text the advocate is looking at and returns a preview plus the items to save.
// Built into android/app/src/main/assets/parsers.js by `npm run build` (see "prebuild" in package.json).
import { parseCaseDetails, parsePasted } from './ecourts';
import { isPast, parseChallans, parseVehicle } from './vehicle';

type CaseData = { cnr: string; caseNumber: string; title: string; court: string; status: string; initialDate: string; nextHearing: string };
type Item = { kind: 'case'; data: CaseData } | { kind: 'lookup'; data: { id: string; kind: 'vehicle' | 'challan'; title: string; at: number; lines: string[] } };
type Preview = { ok: boolean; message?: string; title: string; lines: string[]; items: Item[] };

const fail = (message: string): Preview => ({ ok: false, message, title: 'Nothing to save', lines: [], items: [] });
const show = (iso: string) => (iso ? iso.split('-').reverse().join('-') : 'not found');

function preview(text: string, mode: string): Preview {
  const now = Date.now();
  if (mode === 'vehicle') {
    const v = parseVehicle(text);
    if (!v) return fail('This does not look like a vehicle details page. Show the result page and tap Fetch again.');
    const lines = v.fields.map(f => `${f.label}: ${f.value}${f.iso && isPast(f.iso) ? '  (expired)' : ''}`);
    return { ok: true, title: v.vehicleNo || 'Vehicle', lines, items: [{ kind: 'lookup', data: { id: `v-${now}`, kind: 'vehicle', title: v.vehicleNo || 'Vehicle', at: now, lines: v.fields.map(f => `${f.label}: ${f.value}`) } }] };
  }
  if (mode === 'challan') {
    const r = parseChallans(text);
    if (!r) return fail('This does not look like a challan result page. Show the result and tap Fetch again.');
    const lines = r.none || !r.items.length ? ['No challans found'] : r.items.map(c => [c.challanNo, c.date, c.offence, c.amount && `Rs ${c.amount.replace(/[^\d.]/g, '')}`, c.status].filter(Boolean).join(' - '));
    const title = r.none ? 'No challans' : `${r.items.length} challan${r.items.length > 1 ? 's' : ''}`;
    return { ok: true, title, lines, items: [{ kind: 'lookup', data: { id: `c-${now}`, kind: 'challan', title, at: now, lines } }] };
  }
  if (mode === 'list') {
    const found = parsePasted(text, 'Pending');
    if (!found.length) return fail('No cases were recognised. Show your search results list and tap Fetch again.');
    const lines = found.slice(0, 8).map(c => `${c.caseNumber} - ${c.title}`);
    if (found.length > 8) lines.push(`...and ${found.length - 8} more`);
    return { ok: true, title: `${found.length} case${found.length > 1 ? 's' : ''} found`, lines, items: found.map(c => ({ kind: 'case' as const, data: { cnr: c.cnr, caseNumber: c.caseNumber, title: c.title, court: c.court, status: c.status, initialDate: '', nextHearing: '' } })) };
  }
  const d = parseCaseDetails(text);
  if (!d) return fail('This does not look like an eCourts case page. Open one case (tap View) and tap Fetch again.');
  const lines = [d.title, `${d.caseNumber}${d.court ? ` - ${d.court}` : ''}`.trim(), `Next hearing: ${show(d.nextHearing)}`, `Status: ${d.status}${d.stage ? ` - ${d.stage}` : ''}`, d.cnr ? `CNR ${d.cnr}` : ''].filter(Boolean);
  return { ok: true, title: 'Save this case?', lines, items: [{ kind: 'case', data: { cnr: d.cnr, caseNumber: d.caseNumber, title: d.title, court: d.court, status: d.status, initialDate: d.initialDate, nextHearing: d.nextHearing } }] };
}

(window as unknown as { AdvocateParsers: { preview: typeof preview } }).AdvocateParsers = { preview };

# Advocate — personal-use prototype

This is a separate Advocate project based on the supplied Orion Store source tree. The original uploaded ZIP and APK were not modified.

## Screens in this first implementation
- Home with a two-sided profile-card concept, legal-search placeholder, shortcuts, and More navigation
- More with case selection and Summarize / Draft / Guide / Similar Cases / Backup / Interface actions
- New Case form with keyboard, browser speech-recognition attempt, and image picker
- Case History with search, filters, sorting, initial-date cards, favorites, and case actions
- Summarize screen with a local preliminary text summary
- Draft screen with an editable starter template
- Basic local Notes / Diary / Area Calculator / Backup / Interface screens

## Data and feature limitations
- Cases, drafts, profile, and notes are stored in browser local storage on this device. Export a backup regularly; clearing app data can remove local records.
- Summary generation is a simple local text-shortening prototype, **not an AI legal analysis service**.
- Draft generation creates an editable starter template, **not a verified legal document**. Complete and verify all placeholders and applicable law before use.
- OCR is not implemented yet. The camera/image picker currently confirms that an image was selected.
- Similar-case search and legal AI search are not connected to a search provider yet. No real citations are generated.
- Voice input depends on browser/WebView speech-recognition support and permissions.
- The visiting card currently uses editable text fields and a simple front/back swap; photograph upload and signature drawing are not implemented yet.

## Build steps
Use Node.js and install dependencies in this directory, then run:

```sh
npm ci
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

The Android web assets must be refreshed by `npm run build` and `npx cap sync android` before building an APK. This environment could not complete dependency installation, so the current source has **not yet been compiled or tested**.

## UI refresh (Home + More)
- Home and More now follow the reference screenshots (visiting card with 13dp gradient frame at 1.6:1, 90dp search box, four pastel tiles, blob utility buttons, pentagon More button; More with case banner and offset-shaded feature cards).
- Both screens are laid out on a 360 x 800 dp design canvas that scales uniformly (`--u` in `index.css`), so they fit any phone height with no clipping or scrolling.
- Real SVG icons replace the earlier text glyphs. Blob / hexagon shapes are SVG clip-paths defined once in `ShapeDefs` in `App.tsx`.
- The Home search-box height setting (More > Interface) now defaults to 90 and is stored under a new key, so older saved values (e.g. 128) do not override the new default.
- Fonts (Lexend, Space Grotesk) load from Google Fonts like the existing fonts; offline they fall back to system fonts. For fully offline builds add `@fontsource/lexend` and `@fontsource/space-grotesk`.

## Backup / Notes / Diary redesign, animation, haptics
- Backup, Notes and Diary follow the supplied screenshots (360 dp design canvas scaled by screen width).
- Scalloped shapes (header badges, corner blobs, Backup footer badge, Diary date badge) rotate continuously, as in the reference video: top badges ~25 deg/s, lower badges ~15 deg/s clockwise (icons stay still); blob speed is an estimate. Tune with `--spin` on `.rot-a`, `.rot-b`, `.rot-blob` in `index.css`. Disabled by Interface > Reduce motion and by the OS reduced-motion setting.
- Diary is now a day view of court dates: cases whose next hearing is the chosen day, a "Next Date" field per case (moves the case to that date), a call button (uses the case phone number) and previous/next/pick-date controls. The old shared diary text box is gone (Notes still holds free text).
- Backup writes `advocate-backup-YYYYMMDD.osf` (JSON content, no signature) and restores `.osf` or `.json`. "Connect a cloud" opens the system share sheet so any storage app can receive the file; it falls back to a download.
- Interface > Haptic touch (on by default) uses `@capacitor/haptics` with a `navigator.vibrate` fallback; it fires on taps of buttons, selects and switches.

## Home / More / Summarize / Case History / New Case redesign
- Home tile icons, utility buttons and the More button, plus the More screen's back button, case badge and card icons, are now scalloped shapes that rotate like the Backup screen (shared `Scallop` / `Badge` components in `App.tsx`; speeds via `--spin` on `.rot-a`, `.rot-b`, `.rot-blob`).
- Summarize, Case History and New Case use the shared themed layout (`sx-purple`, `sx-amber`, `sx-green`) from the supplied screenshots. Summarize keeps Generate Summary / Save / Copy in a bar docked at the bottom of the text panel; New Case keeps keyboard, voice and camera input.
- Draft, Guide and Similar Cases screens were not part of this design pass and keep their previous layout.

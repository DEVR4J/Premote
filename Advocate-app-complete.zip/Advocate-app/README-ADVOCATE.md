# Advocate — personal-use prototype

This is a separate Advocate project based on the supplied Orion Store source tree. The original uploaded ZIP and APK were not modified.

## Screens in this first implementation
- Home with a two-sided profile-card concept, legal-search placeholder, shortcuts, and More navigation
- More with case selection and Summarize / Draft / Guide / Similar Cases / Backup / Interface actions
- New Case form with keyboard, browser speech-recognition attempt, and image picker
- Case History with search, filters, sorting, initial-date cards, favorites, and case actions
- Summarize screen with a local preliminary text summary
- Draft screen with an editable starter template
- Basic local Notes / Diary / Area Calculator / Backup / Interface screens

## Data and feature limitations
- Cases, drafts, profile, and notes are stored in browser local storage on this device. Export a backup regularly; clearing app data can remove local records.
- Summary generation is a simple local text-shortening prototype, **not an AI legal analysis service**.
- Draft generation creates an editable starter template, **not a verified legal document**. Complete and verify all placeholders and applicable law before use.
- OCR is not implemented yet. The camera/image picker currently confirms that an image was selected.
- Similar-case search and legal AI search are not connected to a search provider yet. No real citations are generated.
- Voice input depends on browser/WebView speech-recognition support and permissions.
- The visiting card currently uses editable text fields and a simple front/back swap; photograph upload and signature drawing are not implemented yet.

## Build steps
Use Node.js and install dependencies in this directory, then run:

```sh
npm ci
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

The Android web assets must be refreshed by `npm run build` and `npx cap sync android` before building an APK. This environment could not complete dependency installation, so the current source has **not yet been compiled or tested**.

## UI refresh (Home + More)
- Home and More now follow the reference screenshots (visiting card with 13dp gradient frame at 1.6:1, 90dp search box, four pastel tiles, blob utility buttons, pentagon More button; More with case banner and offset-shaded feature cards).
- Both screens are laid out on a 360 x 800 dp design canvas that scales uniformly (`--u` in `index.css`), so they fit any phone height with no clipping or scrolling.
- Real SVG icons replace the earlier text glyphs. Blob / hexagon shapes are SVG clip-paths defined once in `ShapeDefs` in `App.tsx`.
- The Home search-box height setting (More > Interface) now defaults to 90 and is stored under a new key, so older saved values (e.g. 128) do not override the new default.
- Fonts (Lexend, Space Grotesk) load from Google Fonts like the existing fonts; offline they fall back to system fonts. For fully offline builds add `@fontsource/lexend` and `@fontsource/space-grotesk`.

## Backup / Notes / Diary redesign, animation, haptics
- Backup, Notes and Diary follow the supplied screenshots (360 dp design canvas scaled by screen width).
- Scalloped shapes (header badges, corner blobs, Backup footer badge, Diary date badge) rotate continuously, as in the reference video: top badges ~25 deg/s, lower badges ~15 deg/s clockwise (icons stay still); blob speed is an estimate. Tune with `--spin` on `.rot-a`, `.rot-b`, `.rot-blob` in `index.css`. Disabled by Interface > Reduce motion and by the OS reduced-motion setting.
- Diary is now a day view of court dates: cases whose next hearing is the chosen day, a "Next Date" field per case (moves the case to that date), a call button (uses the case phone number) and previous/next/pick-date controls. The old shared diary text box is gone (Notes still holds free text).
- Backup writes `advocate-backup-YYYYMMDD.osf` (JSON content, no signature) and restores `.osf` or `.json`. "Connect a cloud" opens the system share sheet so any storage app can receive the file; it falls back to a download.
- Interface > Haptic touch (on by default) uses `@capacitor/haptics` with a `navigator.vibrate` fallback; it fires on taps of buttons, selects and switches.

## Home / More / Summarize / Case History / New Case redesign
- Home tile icons, utility buttons and the More button, plus the More screen's back button, case badge and card icons, are now scalloped shapes that rotate like the Backup screen (shared `Scallop` / `Badge` components in `App.tsx`; speeds via `--spin` on `.rot-a`, `.rot-b`, `.rot-blob`).
- Summarize, Case History and New Case use the shared themed layout (`sx-purple`, `sx-amber`, `sx-green`) from the supplied screenshots. Summarize keeps Generate Summary / Save / Copy in a bar docked at the bottom of the text panel; New Case keeps keyboard, voice and camera input.
- Draft, Guide and Similar Cases screens were not part of this design pass and keep their previous layout.

## v4: remaining screens, AMOLED + interface options, back gesture
- Draft, Guide and Similar follow the supplied designs; Favorites, Area Calculator, Interface, and new Call and Fun screens use the same themed layout, all with the rotating scalloped shapes.
- Interface > Theme: Auto (follows the phone) / Light / Dark / AMOLED (pure black). Interface > Animation: Off / Slow / Normal / Fast. The Android status bar and `theme-color` follow the theme (`@capacitor/status-bar`, already a dependency).
- Back gesture / Android back button: navigation now uses the browser History API (`go()` in `App.tsx`), which Capacitor's Android bridge follows by default. Back returns to the previous screen, the Home button clears the stack, and back at Home exits the app. No new dependency was needed.
- Theme colours for every screen are CSS variables (`--sx-*`). Dark and AMOLED sets are generated per theme at the end of `index.css`.

## v5: card back, case edit, AI keys, calculator tools
- Home card: tap anywhere on it to flip (3D flip) to the back; tap again to return. The back shows the image uploaded in Interface > "Visiting card — back side" (PNG/JPG, auto-resized to fit device storage), or the contact/signature side if none is uploaded. The avatar no longer intercepts taps; edit the profile from the back of the generated card.
- Case History: the three-dot button opens a dropdown (Add to favorites, Edit, Details, Delete). Edit opens a popup with every field from New Case (name, case details, date, next date, phone, court) plus status. The back gesture closes an open menu/popup before navigating.
- Interface > AI API keys: add several keys (provider, label, key), show/hide, switch each on/off, delete. Stored only on this device (localStorage, not encrypted) and excluded from backups. `getActiveAiKeys()` in `App.tsx` returns the active keys in order; the Summarize/Draft generators still use their built-in templates until a provider call is connected.
- Area Calc: Rectangle, Triangle (base & height or three sides), Quadrilateral (four sides + diagonal), Trapezium, Circle, and a Converter (area and length). Results show perimeter and sq m / sq ft / gaj / acre equivalents. Regional units (Cent, Gunta, Marla, Kanal included; Bigha, Biswa etc. vary by state) can be added as custom units.

## v6: AI features, image transcription, WhatsApp
- `ai.ts` is the AI service. It uses the keys added in Interface > AI API keys (Anthropic, OpenAI, Google Gemini, Mistral, Groq, or any OpenAI-compatible "Other" endpoint with its own base URL and model). Active keys are tried in the order listed; if one fails (invalid key, quota, outage) the next one is used. Each key shows its last status and has a Test button. On the phone requests go through Capacitor's native HTTP (no CORS issues); in a browser they use fetch.
- Default models are set in `DEFAULT_MODELS` in `ai.ts`; each key can override the model name because provider model names change over time.
- AI is used for: Summarize (with Undo), Draft (formal Hindi, placeholders for missing facts), Guide and Similar (saved on the case; Similar never invents citations and marks references "verify"), New Case "Fill details with AI" and image transcription (camera or gallery, printed or handwritten, on New Case and Draft), and Home search (plain-language questions about saved cases; falls back to plain keyword search when no key is set).
- First AI use shows a one-time consent prompt, because the text or image you choose is sent to the provider whose key you added. Phone numbers are not sent.
- Call screen: each client has a WhatsApp button (wa.me). Numbers without a country code use Interface > Default country code (91 by default).

## v7: Tool Box, Compass, Hindi tutorial
- Home "AREA Calc" is now **Tool Box**. Tool Box (`tools.tsx`) shows three animated tiles: Area Calc (a shape that morphs rectangle → triangle → quadrilateral → trapezium → circle), Unit Converter (values flipping between units) and Compass (swinging needle). Animations follow Interface > Animation (Off / Slow / Normal / Fast) and the phone's reduce-motion setting.
- Area Calc keeps the shape calculators. Unit Converter (area + length, custom units) is now its own screen. Compass has three tabs: Compass (live dial, direction in English and Hindi, declination), Bearings (lock and save bearings with back bearing) and Chauhaddi (four boundaries as Hindi text, copy or add to Notes).
- The compass uses the phone's absolute-orientation sensor (`deviceorientationabsolute`, with `webkitCompassHeading` on iOS). If no sensor is available a slider sets the direction by hand. Accuracy depends on the phone's sensor and calibration.
- Interface > "How to use this app" opens a Hindi tutorial (`howto.ts`, 16 lessons). Each lesson has numbered steps, an optional tip and a "try it now" button. The lesson text lives in `howto.ts` and is easy to edit.

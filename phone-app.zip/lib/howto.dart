import 'package:flutter/material.dart';
import 'widgets.dart';

class HowToScreen extends StatelessWidget {
  const HowToScreen({super.key});

  Widget _appIcon(String asset, String name, String sub) => Column(children: [
        Image.asset(asset, width: 84, height: 84),
        const SizedBox(height: 6),
        Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(sub, style: const TextStyle(fontSize: 12, color: Colors.black54)),
      ]);

  Widget _h(String t) => Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 8),
      child: Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)));

  Widget _sub(String asset, String t) => Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 8),
      child: Row(children: [
        Image.asset(asset, width: 34, height: 34),
        const SizedBox(width: 10),
        Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ]));

  Widget _need(String t) => Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.check_circle, size: 18, color: kPurple),
        const SizedBox(width: 8),
        Expanded(child: Text(t)),
      ]));

  Widget _step(int n, String title, String body) => Card(
      child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(radius: 14, backgroundColor: kPurple, child: Text('$n', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 3),
              Text(body),
            ])),
          ])));

  Widget _tip(String t) => Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.lightbulb_outline, size: 18, color: Colors.orange),
        const SizedBox(width: 8),
        Expanded(child: Text(t)),
      ]));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('How to use'), backgroundColor: kDark, foregroundColor: Colors.white),
      body: Column(children: [
        Expanded(
          child: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 24), children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _appIcon('assets/icon_tv.png', 'ATC TV', 'on your TV'),
              const SizedBox(width: 24),
              const Icon(Icons.swap_horiz, size: 32, color: Colors.black45),
              const SizedBox(width: 24),
              _appIcon('assets/icon_phone.png', 'ATC Phone', 'on your phone'),
            ]),
            const SizedBox(height: 6),
            const Center(child: Text("Control your TV from your phone: see its screen, press buttons, type, and send files.", textAlign: TextAlign.center, style: TextStyle(color: Colors.black54))),

            _h('What you need'),
            _need("An Android TV, Android box or Android tablet (Android 9 or newer) with the ATC TV app installed."),
            _need("An Android phone with the ATC Phone app installed."),
            _need("Home mode: phone and TV on the same Wi-Fi. Some routers block this (look for \"AP isolation\" or \"guest network\" and turn it off)."),
            _need("Internet mode (optional): a server address from your own server setup, and internet on both devices."),
            _need("To control the TV: either turn on USB debugging in the TV's Developer options, or switch on the \"Remote Agent\" Accessibility service."),
            _need("Say Yes when Android asks: screen capture (so you can see the TV), storage (to receive files on Android 9), and install from this app (for updates)."),

            _sub('assets/icon_tv.png', 'On the TV'),
            _step(1, 'Install and open ATC TV', "Download ATC-TV.apk from the Releases page of the app's GitHub page, install it on the TV (allow unknown apps) and open it."),
            _step(2, 'Allow screen capture', "Choose Start now when Android asks. This lets your phone see the TV screen. If your TV has no such window, the app still works with controls only."),
            _step(3, 'Set a 6-digit code', "Type any 6 digits and tap Save code. You will type the same code on your phone."),
            _step(4, 'Turn on control', "Option A: Settings > Developer options > USB debugging ON, then tap Allow if asked. Option B: tap Open Accessibility settings and switch on Remote Agent. The screen shows \"Control: OK\" when it works."),
            _step(5, 'Note the address', "Under HOME Wi-Fi the TV shows an address such as 192.168.1.5. For internet mode, tap Set up internet access, type your server address, and note the TV ID it shows."),
            _tip("The Start / Stop service button turns everything on or off. Keep the service running while you use the phone."),

            _sub('assets/icon_phone.png', 'On the phone'),
            _step(6, 'Install and open ATC Phone', "Download ATC-Phone.apk the same way, install it and open it."),
            _step(7, 'Fill in the setup screen', "Optional device name. TV address: the home Wi-Fi address from step 5, or your server address for internet mode. TV ID: internet mode only. Then the 6-digit code."),
            _step(8, 'Press Start', "Keep \"Remember this device\" on to save it. The controller opens full screen in landscape."),
            _step(9, 'Use the controller', "Left side: Back, volume + and -, send a file to the TV, and the triangle menu (Home, Recent, Stop, media keys, TV Settings, TV Wi-Fi, apps, Video quality, Exit). Right side: OK, the joystick (drag or tap, hold to repeat), the mouse button (the screen becomes a trackpad: one finger moves, tap clicks, two fingers scroll) and the keyboard button. You can also tap or swipe directly on the TV picture."),
            _step(10, 'Saved devices', "Saved devices appear under the Start button. Tap one to connect. The three dots let you rename, load into the form, or delete it."),
            _step(11, 'Video quality and updates', "Triangle menu > Video: pick resolution, frame rate, bitrate and format. Updates: at the bottom of the setup screen, tap Check for updates (or leave Auto-update on)."),
            _tip("Files you send land in the TV's Downloads folder, inside \"ATC TV\". The phone's back gesture disconnects and brings you back to this setup screen."),

            _h('If something does not work'),
            _tip("Cannot connect: check both devices are on the same Wi-Fi, the TV service is running, and the code matches."),
            _tip("No picture: allow screen capture on the TV and make sure Screen mirroring is ON. Try a lower video quality."),
            _tip("Red banner \"TV control is OFF\": turn on USB debugging or the Remote Agent on the TV."),
            _tip("Sent file not found: open Downloads > ATC TV on the TV, and allow storage if asked."),
          ]),
        ),
        Container(
          width: double.infinity,
          color: kDark,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: const SafeArea(
            top: false,
            child: Text(
              'This app is created by Divyanshu Singh Yadav aka Shaktiman.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ),
        ),
      ]),
    );
  }
}

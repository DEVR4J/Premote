import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'net.dart';
import 'update.dart';
import 'howto.dart';
import 'widgets.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: Colors.white),
      home: const Home()));
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _H();
}

class _H extends State<Home> with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  final net = Net();
  final updater = Updater();
  bool mouse = false;
  Offset? _a, _b;
  final _kf = FocusNode();
  final _kc = TextEditingController(text: '\u200B');

  bool _land = false;
  @override
  void initState() { super.initState(); net.addListener(() { _syncMode(); _syncClock(); if (mounted) setState(() {}); }); net.init(); updater.addListener(() { if (mounted) setState(() {}); }); updater.init(); WidgetsBinding.instance.addObserver(this); }

  // Device list = portrait. Controller = full-screen landscape.
  void _syncMode() {
    final want = net.inController;
    if (want == _land) return;
    _land = want;
    if (want) {
      SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      _kf.unfocus();
      mouse = false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) { if (s == AppLifecycleState.resumed) net.onResumed(); }

  @override
  void dispose() { WidgetsBinding.instance.removeObserver(this); _clock.dispose(); super.dispose(); }

  void _tap(String k) { HapticFeedback.lightImpact(); net.key(k); }

  // ---- controller theme ----
  late final AnimationController _clock = AnimationController(vsync: this, duration: const Duration(seconds: 5));
  CTheme get _ct => CTheme.byName(net.theme);
  void _syncClock() {
    if (_ct.rgb) { if (!_clock.isAnimating) _clock.repeat(); } else { _clock.stop(); }
  }

  void _themeDialog() {
    const options = [['normal', 'Normal'], ['glass', 'Dark glass'], ['light', 'Light'], ['rgb', 'RGB (animated lights)']];
    showDialog(
        context: context,
        builder: (dc) => Dialog(
              backgroundColor: const Color(0xFF0E1250),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: kEdge, width: 1.5)),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Controller theme', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  for (final o in options)
                    ListTile(
                      dense: true,
                      leading: Icon(net.theme == o[0] ? Icons.radio_button_checked : Icons.radio_button_off, color: Colors.white70),
                      title: Text(o[1], style: const TextStyle(color: Colors.white)),
                      onTap: () { Navigator.pop(dc); net.setTheme(o[0]); },
                    ),
                ]),
              ),
            ));
  }

  void _toggleKeyboard() {
    if (_kf.hasFocus) { _kf.unfocus(); } else { _kf.requestFocus(); SystemChannels.textInput.invokeMethod('TextInput.show'); }
  }

  void _typed(String v) {
    if (v.isEmpty) { net.key('DEL'); } else if (v.length > 1) { net.text(v.substring(1)); }
    _kc.value = const TextEditingValue(text: '\u200B', selection: TextSelection.collapsed(offset: 1));
  }

  @override
  Widget build(BuildContext context) {
    if (!net.loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (!net.inController) return ConnectScreen(net: net, updater: updater);
    final pad = MediaQuery.of(context).padding;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) { if (!didPop) net.disconnect(); },
      child: Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        decoration: _ct.kind == ThemeKind.normal
            ? const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF070B33), Color(0xFF1B0C55)]))
            : null,
        child: ThemeScope(
          theme: _ct,
          clock: _clock,
          child: Stack(children: [
        if (_ct.kind != ThemeKind.normal) Positioned.fill(child: themedBackground(_ct)),
        Padding(
          padding: EdgeInsets.fromLTRB(math.max(pad.left, 10), math.max(pad.top, 8), math.max(pad.right, 10), math.max(pad.bottom, 8)),
          child: LayoutBuilder(builder: (_, box) {
            final u = box.maxHeight / 800;
            return Row(children: [
              _left(u),
              SizedBox(width: 12 * u),
              Expanded(child: _tv(u)),
              SizedBox(width: 12 * u),
              _right(u),
            ]);
          }),
        ),
          ]),
        ),
      ),
    ));
  }

  Widget _left(double u) => SizedBox(
        width: 200 * u,
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          NeonBtn(w: 180 * u, h: 180 * u, circle: true, onTap: () => _tap('BACK'), child: Icon(Icons.undo, color: _ct.icon, size: 86 * u)),
          VolumePill(w: 88 * u, h: 290 * u, onUp: () => _tap('VOLUME_UP'), onDown: () => _tap('VOLUME_DOWN')),
          Column(mainAxisSize: MainAxisSize.min, children: [
            NeonBtn(w: 190 * u, h: 112 * u, onTap: net.sendFile, child: Icon(Icons.upload_file, color: _ct.icon, size: 68 * u)),
            SizedBox(height: 14 * u),
            NeonBtn(w: 190 * u, h: 112 * u, onTap: _menu, child: Icon(Icons.navigation, color: _ct.icon, size: 76 * u)),
          ]),
        ]),
      );

  Widget _right(double u) => SizedBox(
        width: 210 * u,
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          NeonBtn(w: 200 * u, h: 116 * u, onTap: () => _tap('DPAD_CENTER'),
              child: Text('OK', style: TextStyle(color: _ct.icon, fontSize: 66 * u, fontWeight: FontWeight.w900, letterSpacing: 2))),
          Joystick(size: 208 * u, onDir: (d) => _tap('DPAD_$d')),
          Column(mainAxisSize: MainAxisSize.min, children: [
            NeonBtn(w: 200 * u, h: 112 * u, active: mouse, onTap: () => setState(() => mouse = !mouse),
                child: Icon(Icons.mouse, color: _ct.icon, size: 66 * u)),
            SizedBox(height: 14 * u),
            NeonBtn(w: 184 * u, h: 100 * u, active: _kf.hasFocus, onTap: _toggleKeyboard,
                child: Icon(Icons.keyboard, color: _ct.icon, size: 66 * u)),
          ]),
        ]),
      );

  Widget _tv(double u) => Stack(clipBehavior: Clip.none, children: [
        Positioned.fill(
          child: _frame(
            u,
            ClipRRect(
              borderRadius: BorderRadius.circular(17 * u),
              child: Container(
                color: Colors.black,
                child: Stack(fit: StackFit.expand, children: [
                  Center(child: net.hasVideo ? _screen() : const Text('Connected (no video)', style: TextStyle(color: Colors.white38))),
                  if (!net.hasVideo && mouse) Trackpad(net: net),
                  if (net.controlWarning != null) Positioned(top: 0, left: 0, right: 0, child: _banner(net.controlWarning!, Colors.red.shade700)),
                  if (net.banner != null) Positioned(bottom: 0, left: 0, right: 0, child: _banner(net.banner!, kPurple)),
                  // hidden field that opens the phone keyboard
                  Positioned(
                    left: 0, top: 0, width: 2, height: 2,
                    child: Opacity(
                      opacity: 0.01,
                      child: TextField(
                        focusNode: _kf, controller: _kc,
                        keyboardType: TextInputType.visiblePassword,
                        enableSuggestions: false, autocorrect: false,
                        textInputAction: TextInputAction.send,
                        decoration: const InputDecoration(border: InputBorder.none, isCollapsed: true),
                        onChanged: _typed,
                        onSubmitted: (_) { net.key('ENTER'); _kf.requestFocus(); },
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -9 * u, left: 0, right: 0,
          child: Center(child: Container(color: _ct.labelBg, padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text('TELEVISION', style: TextStyle(color: _ct.label, fontSize: 10, letterSpacing: 3)))),
        ),
      ]);

  Widget _frame(double u, Widget inner) {
    final r = BorderRadius.circular(20 * u);
    switch (_ct.kind) {
      case ThemeKind.rgb:
        return AnimatedBuilder(
            animation: _clock,
            builder: (_, __) => Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                    borderRadius: r,
                    gradient: rainbowSweep(_clock.value),
                    boxShadow: [BoxShadow(color: hue(_clock.value).withOpacity(0.55), blurRadius: 20)]),
                child: inner));
      case ThemeKind.glass:
        return Container(
            padding: const EdgeInsets.all(2.5),
            decoration: BoxDecoration(
                borderRadius: r,
                gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0x99FFFFFF), Color(0x1AFFFFFF), Color(0x66B7A8FF)]),
                boxShadow: const [BoxShadow(color: Color(0x66000000), blurRadius: 14)]),
            child: inner);
      case ThemeKind.light:
        return Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
                borderRadius: r,
                color: const Color(0xFFEDEFF8),
                border: Border.all(color: const Color(0xFFC9CEE6), width: 1.5),
                boxShadow: const [
                  BoxShadow(color: Colors.white, offset: Offset(-4, -4), blurRadius: 8),
                  BoxShadow(color: Color(0x44606C9B), offset: Offset(4, 5), blurRadius: 10),
                ]),
            child: inner);
      case ThemeKind.normal:
        return Container(
            padding: const EdgeInsets.all(3.5),
            decoration: BoxDecoration(borderRadius: r, gradient: const LinearGradient(colors: [kBlue, kPurple])),
            child: inner);
    }
  }

  Widget _banner(String t, Color c) => Container(color: c, padding: const EdgeInsets.all(6), child: Text(t, style: const TextStyle(color: Colors.white, fontSize: 12)));

  // Normal mode: tap/drag on the picture = tap/swipe on the TV. Mouse mode: screen becomes a trackpad.
  Widget _screen() => AspectRatio(
      aspectRatio: net.videoAspect,
      child: LayoutBuilder(builder: (_, c) {
        Offset n(Offset o) => Offset((o.dx / c.maxWidth).clamp(0.0, 1.0).toDouble(), (o.dy / c.maxHeight).clamp(0.0, 1.0).toDouble());
        final video = RTCVideoView(net.video, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain);
        if (mouse) return Stack(fit: StackFit.expand, children: [video, Trackpad(net: net)]);
        return GestureDetector(
          onTapUp: (d) { final p = n(d.localPosition); net.tap(p.dx, p.dy); },
          onPanStart: (d) { _a = n(d.localPosition); _b = _a; },
          onPanUpdate: (d) => _b = n(d.localPosition),
          onPanEnd: (_) { if (_a != null && _b != null) net.swipe(_a!.dx, _a!.dy, _b!.dx, _b!.dy); },
          child: video,
        );
      }));

  /// List of every app on the TV: search, then tap to open it.
  void _apps() {
    net.requestApps();
    final q = TextEditingController();
    showDialog(
        context: context,
        builder: (dc) => Dialog(
              backgroundColor: const Color(0xFF0E1250),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: kEdge, width: 1.5)),
              child: AnimatedBuilder(
                animation: net,
                builder: (_, __) => StatefulBuilder(builder: (c, set) {
                  final all = net.apps;
                  final f = q.text.trim().toLowerCase();
                  final shown = f.isEmpty ? all : all.where((a) => a['n']!.toLowerCase().contains(f) || a['p']!.toLowerCase().contains(f)).toList();
                  return SizedBox(
                    width: 460,
                    height: MediaQuery.of(context).size.height * 0.8,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(children: [
                        Row(children: [
                          const Text('Apps on the TV', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                          const Spacer(),
                          IconButton(icon: const Icon(Icons.refresh, color: Colors.white70), onPressed: net.requestApps),
                          IconButton(icon: const Icon(Icons.close, color: Colors.white70), onPressed: () => Navigator.pop(dc)),
                        ]),
                        TextField(
                          controller: q,
                          style: const TextStyle(color: Colors.white),
                          decoration: const InputDecoration(
                              hintText: 'Search apps', hintStyle: TextStyle(color: Colors.white38),
                              prefixIcon: Icon(Icons.search, color: Colors.white54), isDense: true),
                          onChanged: (_) => set(() {}),
                        ),
                        Expanded(
                          child: net.appsLoading && all.isEmpty
                              ? const Center(child: CircularProgressIndicator())
                              : shown.isEmpty
                                  ? const Center(child: Text('No apps found', style: TextStyle(color: Colors.white70)))
                                  : ListView.builder(
                                      itemCount: shown.length,
                                      itemBuilder: (_, i) => ListTile(
                                        dense: true,
                                        leading: const Icon(Icons.apps, color: Colors.white70),
                                        title: Text(shown[i]['n']!, style: const TextStyle(color: Colors.white)),
                                        subtitle: Text(shown[i]['p']!, style: const TextStyle(color: Colors.white38, fontSize: 11)),
                                        onTap: () { Navigator.pop(dc); net.launch(shown[i]['p']!); net.flash('Opening ${shown[i]['n']}...'); },
                                      ),
                                    ),
                        ),
                      ]),
                    ),
                  );
                }),
              ),
            ));
  }

  void _quality() {
    var h = net.q.height, fps = net.q.fps, kb = net.q.kbps, codec = net.q.codec;
    showDialog(
        context: context,
        builder: (dc) => StatefulBuilder(builder: (c, set) {
              Widget row(String title, List<dynamic> vals, List<String> labels, dynamic cur, void Function(dynamic) pick) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      Wrap(spacing: 6, children: [
                        for (var i = 0; i < vals.length; i++)
                          ChoiceChip(
                            label: Text(labels[i], style: TextStyle(fontSize: 12, color: cur == vals[i] ? Colors.white : Colors.black87)),
                            selected: cur == vals[i],
                            selectedColor: kPurple,
                            onSelected: (_) => set(() => pick(vals[i])),
                          ),
                      ]),
                    ]),
                  );
              return Dialog(
                backgroundColor: const Color(0xFF0E1250),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: kEdge, width: 1.5)),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Video quality', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 6, children: [
                        ActionChip(label: const Text('Data saver'), onPressed: () => set(() { h = 480; fps = 15; kb = 1000; })),
                        ActionChip(label: const Text('Balanced'), onPressed: () => set(() { h = 720; fps = 30; kb = 3000; })),
                        ActionChip(label: const Text('Max'), onPressed: () => set(() { h = 1080; fps = 60; kb = 8000; })),
                      ]),
                      const SizedBox(height: 8),
                      row('Resolution', [360, 480, 720, 1080], ['360p', '480p', '720p', '1080p'], h, (v) => h = v),
                      row('Frame rate', [15, 24, 30, 60], ['15', '24', '30', '60 fps'], fps, (v) => fps = v),
                      row('Bitrate', [1000, 2000, 3000, 5000, 8000], ['1 Mbps', '2', '3', '5', '8'], kb, (v) => kb = v),
                      row('Format (changing it reconnects)', ['auto', 'h264', 'vp8', 'vp9'], ['Auto', 'H.264', 'VP8', 'VP9'], codec, (v) => codec = v),
                      Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                        TextButton(onPressed: () => Navigator.pop(dc), child: const Text('Cancel')),
                        FilledButton(
                            onPressed: () { Navigator.pop(dc); net.setQuality(Quality(height: h, fps: fps, kbps: kb, codec: codec)); },
                            child: const Text('Apply')),
                      ]),
                    ]),
                  ),
                ),
              );
            }));
  }

  void _menu() {
    final items = <List<dynamic>>[
      ['Apps', Icons.apps, _apps],
      ['Theme', Icons.palette, _themeDialog],
      ['Home', Icons.home, () => net.key('HOME')],
      ['Back', Icons.arrow_back, () => net.key('BACK')],
      ['Recent', Icons.filter_none, () => net.key('RECENTS')],
      ['Menu', Icons.menu, () => net.key('MENU')],
      ['Stop', Icons.stop, () => net.key('STOP')],
      ['Play/Pause', Icons.play_arrow, () => net.key('MEDIA_PLAY_PAUSE')],
      ['Prev', Icons.skip_previous, () => net.key('MEDIA_PREV')],
      ['Next', Icons.skip_next, () => net.key('MEDIA_NEXT')],
      ['Mute', Icons.volume_off, () => net.key('MUTE')],
      ['Power', Icons.power_settings_new, () => net.key('POWER')],
      ['TV Settings', Icons.settings, () => net.open('settings')],
      ['TV Wi-Fi', Icons.wifi, () => net.open('wifi')],
      ['Bluetooth', Icons.bluetooth, () => net.open('bluetooth')],
      ['YouTube', Icons.smart_display, () => net.launch('com.google.android.youtube.tv')],
      ['Netflix', Icons.movie, () => net.launch('com.netflix.ninja')],
      ['Prime', Icons.tv, () => net.launch('com.amazon.amazonvideo.livingroom')],
      ['Video', Icons.high_quality, _quality],
      ['Exit', Icons.logout, () => net.disconnect()],
    ];
    showDialog(
        context: context,
        builder: (dc) => Dialog(
              backgroundColor: const Color(0xFF0E1250),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: kEdge, width: 1.5)),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: SingleChildScrollView(
                  child: Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [
                    for (final it in items)
                      NeonBtn(
                        w: 92, h: 64,
                        onTap: () { Navigator.pop(dc); (it[2] as VoidCallback)(); },
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(it[1] as IconData, color: Colors.white, size: 22),
                          const SizedBox(height: 3),
                          Text(it[0] as String, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
                        ]),
                      ),
                  ]),
                ),
              ),
            ));
  }
}

/// Transparent trackpad: one finger moves the cursor, a quick tap clicks, two fingers scroll.
class Trackpad extends StatefulWidget {
  final Net net;
  const Trackpad({super.key, required this.net});
  @override
  State<Trackpad> createState() => _TP();
}

class _TP extends State<Trackpad> {
  Offset cur = const Offset(0.5, 0.5);
  final Map<int, Offset> ptr = {};
  int t0 = 0;
  double moved = 0, scrollAcc = 0;
  bool multi = false;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (_, c) {
        return Listener(
          behavior: HitTestBehavior.opaque,
          onPointerDown: (e) {
            ptr[e.pointer] = e.localPosition;
            if (ptr.length == 1) { t0 = e.timeStamp.inMilliseconds; moved = 0; multi = false; scrollAcc = 0; } else { multi = true; }
          },
          onPointerMove: (e) {
            final prev = ptr[e.pointer];
            ptr[e.pointer] = e.localPosition;
            if (prev == null) return;
            final d = e.localPosition - prev;
            moved += d.distance;
            if (ptr.length >= 2) {
              scrollAcc += d.dy;
              if (scrollAcc.abs() > 60) {
                final dir = scrollAcc > 0 ? 1.0 : -1.0;
                widget.net.swipe(cur.dx, cur.dy, cur.dx, (cur.dy + dir * 0.3).clamp(0.02, 0.98).toDouble());
                scrollAcc = 0;
              }
            } else {
              setState(() => cur = Offset(
                  (cur.dx + d.dx / c.maxWidth * 1.6).clamp(0.0, 1.0).toDouble(),
                  (cur.dy + d.dy / c.maxHeight * 1.6).clamp(0.0, 1.0).toDouble()));
            }
          },
          onPointerUp: (e) {
            ptr.remove(e.pointer);
            if (ptr.isEmpty && !multi && moved < 12 && e.timeStamp.inMilliseconds - t0 < 300) {
              HapticFeedback.lightImpact();
              widget.net.tap(cur.dx, cur.dy);
            }
          },
          onPointerCancel: (e) => ptr.remove(e.pointer),
          child: CustomPaint(size: Size.infinite, painter: _CurP(cur)),
        );
      });
}

class _CurP extends CustomPainter {
  final Offset cur;
  _CurP(this.cur);
  @override
  void paint(Canvas c, Size s) {
    final p = Offset(cur.dx * s.width, cur.dy * s.height);
    final path = Path()
      ..moveTo(p.dx, p.dy)..lineTo(p.dx, p.dy + 20)..lineTo(p.dx + 5, p.dy + 15)..lineTo(p.dx + 9, p.dy + 24)
      ..lineTo(p.dx + 13, p.dy + 22)..lineTo(p.dx + 9, p.dy + 14)..lineTo(p.dx + 16, p.dy + 14)..close();
    c.drawPath(path, Paint()..color = Colors.white);
    c.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = Colors.black);
  }

  @override
  bool shouldRepaint(_CurP o) => o.cur != cur;
}

class ConnectScreen extends StatefulWidget {
  final Net net;
  final Updater updater;
  const ConnectScreen({super.key, required this.net, required this.updater});
  @override
  State<ConnectScreen> createState() => _CS();
}

class _CS extends State<ConnectScreen> {
  late final TextEditingController name = TextEditingController(),
      id = TextEditingController(text: widget.net.savedId),
      pin = TextEditingController(text: widget.net.savedPin),
      srv = TextEditingController(text: serverUrl.replaceFirst('wss://', '').replaceFirst('ws://', ''));
  bool remember = true;

  void _start() => widget.net.connect(id.text.replaceAll(RegExp(r"\s"), ""), pin.text.trim(), srv.text, name.text.trim(), remember);

  Future<void> _rename(Device d) async {
    final t = TextEditingController(text: d.name);
    final ok = await showDialog<bool>(
        context: context,
        builder: (dc) => AlertDialog(
              title: const Text('Device name'),
              content: TextField(controller: t, autofocus: true),
              actions: [
                TextButton(onPressed: () => Navigator.pop(dc, false), child: const Text('Cancel')),
                FilledButton(onPressed: () => Navigator.pop(dc, true), child: const Text('Save')),
              ],
            ));
    if (ok == true) widget.net.renameDevice(d, t.text);
  }

  @override
  Widget build(BuildContext c) {
    final net = widget.net;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [
              const Text('ATC Phone', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const Spacer(),
              InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const HowToScreen())),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Row(children: [
                    const Text('How to use', style: TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(width: 6),
                    Container(
                      width: 24, height: 24, alignment: Alignment.center,
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.deepPurple, width: 2)),
                      child: const Text('?', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                    ),
                  ]),
                ),
              ),
            ]),
            const SizedBox(height: 8),
            if (widget.updater.info != null)
              Card(
                color: const Color(0xFFFFF3CD),
                child: ListTile(
                  leading: const Icon(Icons.system_update),
                  title: Text('Update available: ${widget.updater.info!.tag}'),
                  subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(widget.updater.status),
                    TextButton(onPressed: widget.updater.openInBrowser, child: const Text('Download in browser instead')),
                  ]),
                  trailing: FilledButton(onPressed: widget.updater.busy ? null : widget.updater.install, child: const Text('Update')),
                ),
              ),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Device name (optional)')),
            TextField(controller: srv, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'TV address (home Wi-Fi) or server (internet)', hintText: '192.168.1.5  or  myserver.workers.dev')),
            TextField(controller: id, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'TV ID (internet only, skip on home Wi-Fi)')),
            TextField(controller: pin, maxLength: 6, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '6-digit code')),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Remember this device'), value: remember, onChanged: (v) => setState(() => remember = v)),
            StatefulBuilder(builder: (c2, set) => SwitchListTile(
                contentPadding: EdgeInsets.zero, title: const Text('Show TV video'), value: net.useVideo,
                onChanged: (v) { net.setVideo(v); set(() {}); })),
            const Padding(padding: EdgeInsets.only(top: 6, bottom: 4), child: Text('Controller theme', style: TextStyle(color: Colors.black54))),
            Wrap(spacing: 8, children: [
              for (final t in const [['normal', 'Normal'], ['glass', 'Dark glass'], ['light', 'Light'], ['rgb', 'RGB']])
                ChoiceChip(label: Text(t[1]), selected: net.theme == t[0], onSelected: (_) => net.setTheme(t[0])),
            ]),
            const SizedBox(height: 6),
            if (net.error != null) Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(net.error!, style: const TextStyle(color: Colors.red))),
            if (net.lastTrace != null) Padding(padding: const EdgeInsets.only(bottom: 6), child: Text('Steps before it closed:\n${net.lastTrace}', style: const TextStyle(fontSize: 12))),
            FilledButton(onPressed: _start, child: const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Text('Start', style: TextStyle(fontSize: 18)))),
            const SizedBox(height: 22),
            const Text('Saved devices', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            if (net.devices.isEmpty)
              const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('No saved devices yet. Turn on "Remember this device" and press Start.', style: TextStyle(color: Colors.black54))),
            for (final d in net.devices)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.tv),
                  title: Text(d.name),
                  subtitle: Text(d.shown + (d.id.isNotEmpty ? '   ID ${d.id}' : '   home Wi-Fi')),
                  onTap: () => net.connect(d.id, d.pin, d.address, d.name, true),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) {
                      if (v == 'rename') _rename(d);
                      if (v == 'edit') setState(() { name.text = d.name; srv.text = d.shown; id.text = d.id; pin.text = d.pin; });
                      if (v == 'delete') net.deleteDevice(d);
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'rename', child: Text('Rename')),
                      PopupMenuItem(value: 'edit', child: Text('Load into form')),
                      PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ),
              ),
            const Divider(height: 32),
            Text('Version: build $kBuild', style: const TextStyle(color: Colors.black54)),
            if (widget.updater.status.isNotEmpty) Text(widget.updater.status, style: const TextStyle(color: Colors.black54, fontSize: 12)),
            Row(children: [
              TextButton(onPressed: widget.updater.busy ? null : widget.updater.check, child: const Text('Check for updates')),
              const Spacer(),
              const Text('Auto-update'),
              Switch(value: widget.updater.auto, onChanged: (v) => widget.updater.setAuto(v)),
            ]),
          ]),
        ),
      ),
    );
  }
}

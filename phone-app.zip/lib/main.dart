import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'net.dart';
import 'widgets.dart';

void main() => runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: Colors.white),
    home: const Home()));

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _H();
}

class _H extends State<Home> {
  final net = Net();
  Offset? _a, _b;
  @override
  void initState() { super.initState(); net.addListener(() => setState(() {})); net.init(); }
  void tap(String k) { HapticFeedback.lightImpact(); net.key(k); }

  @override
  Widget build(BuildContext context) {
    if (!net.loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (!net.session) return ConnectScreen(net: net);
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Pill(icon: Icons.settings, onTap: _menu),
              const SizedBox(width: 10),
              Pill(icon: Icons.logout, onTap: net.forget),
              const Spacer(),
              Pill(icon: Icons.undo, circle: true, onTap: () => tap('BACK')),
            ]),
          ),
          Expanded(
            child: Container(
              width: double.infinity, color: const Color(0xFF525252), padding: const EdgeInsets.all(8),
              child: Container(color: Colors.black, alignment: Alignment.center, child: net.hasVideo ? _screen() : const Text('Connected (no video)\nControls only', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38))),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Tri('DOWN', () => tap('DPAD_DOWN')), Tri('LEFT', () => tap('DPAD_LEFT')),
              Tri('RIGHT', () => tap('DPAD_RIGHT')), Tri('UP', () => tap('DPAD_UP')),
              Pill(label: 'OK', tall: true, onTap: () => tap('DPAD_CENTER')),
            ]),
          ),
        ]),
      ),
    );
  }

  // Touch the mirrored screen: tap = click, drag = swipe (coords normalised 0..1)
  Widget _screen() => AspectRatio(
      aspectRatio: 16 / 9,
      child: LayoutBuilder(builder: (_, c) {
        Offset n(Offset o) => Offset((o.dx / c.maxWidth).clamp(0, 1), (o.dy / c.maxHeight).clamp(0.0, 1.0).toDouble());
        return GestureDetector(
          onTapUp: (d) { final p = n(d.localPosition); net.tap(p.dx, p.dy); },
          onPanStart: (d) { _a = n(d.localPosition); _b = _a; },
          onPanUpdate: (d) => _b = n(d.localPosition),
          onPanEnd: (_) { if (_a != null && _b != null) net.swipe(_a!.dx, _a!.dy, _b!.dx, _b!.dy); },
          child: RTCVideoView(net.video, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain),
        );
      }));

  void _menu() {
    final items = <Widget>[
      for (final e in {'Vol −': 'VOLUME_DOWN', 'Vol +': 'VOLUME_UP', 'Mute': 'MUTE', 'Play/Pause': 'MEDIA_PLAY_PAUSE', 'Home': 'HOME', 'Power': 'POWER'}.entries)
        ActionChip(label: Text(e.key), onPressed: () => net.key(e.value)),
      ActionChip(label: const Text('YouTube'), onPressed: () => net.launch('com.google.android.youtube.tv')),
      ActionChip(label: const Text('Netflix'), onPressed: () => net.launch('com.netflix.ninja')),
    ];
    showModalBottomSheet(context: context, builder: (_) => Padding(padding: const EdgeInsets.all(20), child: Wrap(spacing: 10, runSpacing: 10, children: items)));
  }
}

class ConnectScreen extends StatelessWidget {
  final Net net;
  ConnectScreen({super.key, required this.net});
  late final id = TextEditingController(text: net.savedId), pin = TextEditingController(text: net.savedPin),
      srv = TextEditingController(text: serverUrl.replaceFirst('wss://', ''));
  @override
  Widget build(BuildContext c) => Scaffold(
      body: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('Connect to your TV', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            TextField(controller: srv, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'TV address (home Wi-Fi) or server (internet)', hintText: '192.168.1.5  or  myserver.onrender.com')),
            TextField(controller: id, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'TV ID (internet only, skip on home Wi-Fi)')),
            TextField(controller: pin, maxLength: 6, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '6-digit code')),
            if (net.error != null) Text(net.error!, style: const TextStyle(color: Colors.red)),
            if (net.lastTrace != null) Text('Steps before it closed:\n${net.lastTrace}', style: const TextStyle(fontSize: 12)),
            StatefulBuilder(builder: (c, set) => SwitchListTile(
                title: const Text('Show TV video'), value: net.useVideo,
                onChanged: (v) { net.setVideo(v); set(() {}); })),
            const SizedBox(height: 12),
            FilledButton(onPressed: () => net.connect(id.text.replaceAll(RegExp(r"\s"), ""), pin.text.trim(), srv.text), child: const Text('Connect')),
          ])));
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'net.dart';
import 'widgets.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: Colors.white),
      home: const Home()));
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _H();
}

class _H extends State<Home> {
  final net = Net();
  Offset? _a, _b;
  @override
  void initState() { super.initState(); net.addListener(() => setState(() {})); net.init(); }
  void tap(String k) { HapticFeedback.lightImpact(); net.key(k); }

  @override
  Widget build(BuildContext context) {
    if (!net.loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (!net.session) return ConnectScreen(net: net);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: LayoutBuilder(builder: (_, box) {
            final s = ((box.maxHeight - 40) / 5.3).clamp(34.0, 64.0).toDouble();
            return Row(children: [
              // left column: back (top), exit + settings (bottom)
              Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Pill(icon: Icons.undo, circle: true, size: s, onTap: () => tap('BACK')),
                Column(children: [
                  Pill(icon: Icons.logout, size: s, onTap: net.forget),
                  const SizedBox(height: 10),
                  Pill(icon: Icons.settings, size: s, onTap: _menu),
                ]),
              ]),
              const SizedBox(width: 8),
              Expanded(child: _tvFrame()),
              const SizedBox(width: 8),
              // right column: OK, UP, RIGHT, LEFT, DOWN
              Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Pill(label: 'OK', tall: true, size: s, onTap: () => tap('DPAD_CENTER')),
                Tri('UP', () => tap('DPAD_UP'), size: s),
                Tri('RIGHT', () => tap('DPAD_RIGHT'), size: s),
                Tri('LEFT', () => tap('DPAD_LEFT'), size: s),
                Tri('DOWN', () => tap('DPAD_DOWN'), size: s),
              ]),
            ]);
          }),
        ),
      ),
    );
  }

  Widget _tvFrame() => Container(
        color: const Color(0xFF525252),
        padding: const EdgeInsets.all(8),
        child: Column(children: [
          Expanded(
            child: Stack(children: [
              Positioned.fill(
                child: Container(
                  color: Colors.black,
                  alignment: Alignment.center,
                  child: net.hasVideo
                      ? _screen()
                      : const Text('Connected (no video)', style: TextStyle(color: Colors.white38)),
                ),
              ),
              if (net.controlWarning != null)
                Positioned(
                  left: 0, right: 0, top: 0,
                  child: Container(
                    color: Colors.red.shade700,
                    padding: const EdgeInsets.all(6),
                    child: Text(net.controlWarning!, style: const TextStyle(color: Colors.white, fontSize: 12)),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 14, child: Center(child: Text('TELEVISION', style: TextStyle(color: Colors.white70, fontSize: 9, letterSpacing: 3)))),
        ]),
      );

  // Touch the mirrored screen: tap = click, drag = swipe (coords normalised 0..1)
  Widget _screen() => AspectRatio(
      aspectRatio: 16 / 9,
      child: LayoutBuilder(builder: (_, c) {
        Offset n(Offset o) => Offset((o.dx / c.maxWidth).clamp(0.0, 1.0).toDouble(), (o.dy / c.maxHeight).clamp(0.0, 1.0).toDouble());
        return GestureDetector(
          onTapUp: (d) { final p = n(d.localPosition); net.tap(p.dx, p.dy); },
          onPanStart: (d) { _a = n(d.localPosition); _b = _a; },
          onPanUpdate: (d) => _b = n(d.localPosition),
          onPanEnd: (_) { if (_a != null && _b != null) net.swipe(_a!.dx, _a!.dy, _b!.dx, _b!.dy); },
          child: RTCVideoView(net.video, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain),
        );
      }));

  void _menu() {
    final items = <Widget>[
      for (final e in {'Vol -': 'VOLUME_DOWN', 'Vol +': 'VOLUME_UP', 'Mute': 'MUTE', 'Play/Pause': 'MEDIA_PLAY_PAUSE', 'Home': 'HOME', 'Power': 'POWER'}.entries)
        ActionChip(label: Text(e.key), onPressed: () => net.key(e.value)),
      ActionChip(label: const Text('YouTube'), onPressed: () => net.launch('com.google.android.youtube.tv')),
      ActionChip(label: const Text('Netflix'), onPressed: () => net.launch('com.netflix.ninja')),
    ];
    showModalBottomSheet(context: context, builder: (_) => Padding(padding: const EdgeInsets.all(20), child: Wrap(spacing: 10, runSpacing: 10, children: items)));
  }
}

class ConnectScreen extends StatelessWidget {
  final Net net;
  ConnectScreen({super.key, required this.net});
  late final id = TextEditingController(text: net.savedId), pin = TextEditingController(text: net.savedPin),
      srv = TextEditingController(text: serverUrl.replaceFirst('wss://', ''));
  @override
  Widget build(BuildContext c) => Scaffold(
      body: SafeArea(
          child: Center(
              child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                  child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 520),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Text('Connect to your TV', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                        TextField(controller: srv, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'TV address (home Wi-Fi) or server (internet)', hintText: '192.168.1.5  or  myserver.onrender.com')),
                        TextField(controller: id, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'TV ID (internet only, skip on home Wi-Fi)')),
                        TextField(controller: pin, maxLength: 6, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '6-digit code')),
                        if (net.error != null) Text(net.error!, style: const TextStyle(color: Colors.red)),
                        if (net.lastTrace != null) Text('Steps before it closed:\n${net.lastTrace}', style: const TextStyle(fontSize: 12)),
                        StatefulBuilder(builder: (c2, set) => SwitchListTile(
                            title: const Text('Show TV video'), value: net.useVideo,
                            onChanged: (v) { net.setVideo(v); set(() {}); })),
                        FilledButton(onPressed: () => net.connect(id.text.replaceAll(RegExp(r"\s"), ""), pin.text.trim(), srv.text), child: const Text('Connect')),
                      ]))))));
}

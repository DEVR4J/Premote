import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'net.dart';
import 'widgets.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: Colors.white),
      home: const Home()));
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _H();
}

class _H extends State<Home> {
  final net = Net();
  bool mouse = false;
  Offset? _a, _b;
  final _kf = FocusNode();
  final _kc = TextEditingController(text: '\u200B');

  @override
  void initState() { super.initState(); net.addListener(() => setState(() {})); net.init(); }

  void _tap(String k) { HapticFeedback.lightImpact(); net.key(k); }

  void _toggleKeyboard() {
    if (_kf.hasFocus) { _kf.unfocus(); } else { _kf.requestFocus(); SystemChannels.textInput.invokeMethod('TextInput.show'); }
  }

  void _typed(String v) {
    if (v.isEmpty) { net.key('DEL'); } else if (v.length > 1) { net.text(v.substring(1)); }
    _kc.value = const TextEditingValue(text: '\u200B', selection: TextSelection.collapsed(offset: 1));
  }

  @override
  Widget build(BuildContext context) {
    if (!net.loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (!net.session) return ConnectScreen(net: net);
    final pad = MediaQuery.of(context).padding;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF070B33), Color(0xFF1B0C55)])),
        child: Padding(
          padding: EdgeInsets.fromLTRB(math.max(pad.left, 10), math.max(pad.top, 8), math.max(pad.right, 10), math.max(pad.bottom, 8)),
          child: LayoutBuilder(builder: (_, box) {
            final u = box.maxHeight / 800;
            return Row(children: [
              _left(u),
              SizedBox(width: 12 * u),
              Expanded(child: _tv(u)),
              SizedBox(width: 12 * u),
              _right(u),
            ]);
          }),
        ),
      ),
    );
  }

  Widget _left(double u) => SizedBox(
        width: 200 * u,
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          NeonBtn(w: 180 * u, h: 180 * u, circle: true, onTap: () => _tap('BACK'), child: Icon(Icons.undo, color: Colors.white, size: 86 * u)),
          VolumePill(w: 88 * u, h: 290 * u, onUp: () => _tap('VOLUME_UP'), onDown: () => _tap('VOLUME_DOWN')),
          Column(mainAxisSize: MainAxisSize.min, children: [
            NeonBtn(w: 190 * u, h: 112 * u, onTap: net.sendFile, child: Icon(Icons.upload_file, color: Colors.white, size: 68 * u)),
            SizedBox(height: 14 * u),
            NeonBtn(w: 190 * u, h: 112 * u, onTap: _menu, child: Icon(Icons.navigation, color: Colors.white, size: 76 * u)),
          ]),
        ]),
      );

  Widget _right(double u) => SizedBox(
        width: 210 * u,
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          NeonBtn(w: 200 * u, h: 116 * u, onTap: () => _tap('DPAD_CENTER'),
              child: Text('OK', style: TextStyle(color: Colors.white, fontSize: 66 * u, fontWeight: FontWeight.w900, letterSpacing: 2))),
          Joystick(size: 208 * u, onDir: (d) => _tap('DPAD_$d')),
          Column(mainAxisSize: MainAxisSize.min, children: [
            NeonBtn(w: 200 * u, h: 112 * u, active: mouse, onTap: () => setState(() => mouse = !mouse),
                child: Icon(Icons.mouse, color: Colors.white, size: 66 * u)),
            SizedBox(height: 14 * u),
            NeonBtn(w: 184 * u, h: 100 * u, active: _kf.hasFocus, onTap: _toggleKeyboard,
                child: Icon(Icons.keyboard, color: Colors.white, size: 66 * u)),
          ]),
        ]),
      );

  Widget _tv(double u) => Stack(clipBehavior: Clip.none, children: [
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(20 * u), gradient: const LinearGradient(colors: [kBlue, kPurple])),
            padding: const EdgeInsets.all(3.5),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(17 * u),
              child: Container(
                color: Colors.black,
                child: Stack(fit: StackFit.expand, children: [
                  Center(child: net.hasVideo ? _screen() : const Text('Connected (no video)', style: TextStyle(color: Colors.white38))),
                  if (!net.hasVideo && mouse) Trackpad(net: net),
                  if (net.controlWarning != null) Positioned(top: 0, left: 0, right: 0, child: _banner(net.controlWarning!, Colors.red.shade700)),
                  if (net.banner != null) Positioned(bottom: 0, left: 0, right: 0, child: _banner(net.banner!, kPurple)),
                  // hidden field that opens the phone keyboard
                  Positioned(
                    left: 0, top: 0, width: 2, height: 2,
                    child: Opacity(
                      opacity: 0.01,
                      child: TextField(
                        focusNode: _kf, controller: _kc,
                        keyboardType: TextInputType.visiblePassword,
                        enableSuggestions: false, autocorrect: false,
                        textInputAction: TextInputAction.send,
                        decoration: const InputDecoration(border: InputBorder.none, isCollapsed: true),
                        onChanged: _typed,
                        onSubmitted: (_) { net.key('ENTER'); _kf.requestFocus(); },
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -9 * u, left: 0, right: 0,
          child: Center(child: Container(color: const Color(0xFF12104A), padding: const EdgeInsets.symmetric(horizontal: 10),
              child: const Text('TELEVISION', style: TextStyle(color: Colors.white, fontSize: 10, letterSpacing: 3)))),
        ),
      ]);

  Widget _banner(String t, Color c) => Container(color: c, padding: const EdgeInsets.all(6), child: Text(t, style: const TextStyle(color: Colors.white, fontSize: 12)));

  // Normal mode: tap/drag on the picture = tap/swipe on the TV. Mouse mode: screen becomes a trackpad.
  Widget _screen() => AspectRatio(
      aspectRatio: 16 / 9,
      child: LayoutBuilder(builder: (_, c) {
        Offset n(Offset o) => Offset((o.dx / c.maxWidth).clamp(0.0, 1.0).toDouble(), (o.dy / c.maxHeight).clamp(0.0, 1.0).toDouble());
        final video = RTCVideoView(net.video, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain);
        if (mouse) return Stack(fit: StackFit.expand, children: [video, Trackpad(net: net)]);
        return GestureDetector(
          onTapUp: (d) { final p = n(d.localPosition); net.tap(p.dx, p.dy); },
          onPanStart: (d) { _a = n(d.localPosition); _b = _a; },
          onPanUpdate: (d) => _b = n(d.localPosition),
          onPanEnd: (_) { if (_a != null && _b != null) net.swipe(_a!.dx, _a!.dy, _b!.dx, _b!.dy); },
          child: video,
        );
      }));

  void _menu() {
    final items = <List<dynamic>>[
      ['Home', Icons.home, () => net.key('HOME')],
      ['Back', Icons.arrow_back, () => net.key('BACK')],
      ['Recent', Icons.filter_none, () => net.key('RECENTS')],
      ['Menu', Icons.menu, () => net.key('MENU')],
      ['Stop', Icons.stop, () => net.key('STOP')],
      ['Play/Pause', Icons.play_arrow, () => net.key('MEDIA_PLAY_PAUSE')],
      ['Prev', Icons.skip_previous, () => net.key('MEDIA_PREV')],
      ['Next', Icons.skip_next, () => net.key('MEDIA_NEXT')],
      ['Mute', Icons.volume_off, () => net.key('MUTE')],
      ['Power', Icons.power_settings_new, () => net.key('POWER')],
      ['TV Settings', Icons.settings, () => net.open('settings')],
      ['TV Wi-Fi', Icons.wifi, () => net.open('wifi')],
      ['Bluetooth', Icons.bluetooth, () => net.open('bluetooth')],
      ['YouTube', Icons.smart_display, () => net.launch('com.google.android.youtube.tv')],
      ['Netflix', Icons.movie, () => net.launch('com.netflix.ninja')],
      ['Prime', Icons.tv, () => net.launch('com.amazon.amazonvideo.livingroom')],
      ['Exit', Icons.logout, () => net.forget()],
    ];
    showDialog(
        context: context,
        builder: (dc) => Dialog(
              backgroundColor: const Color(0xFF0E1250),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: kEdge, width: 1.5)),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: SingleChildScrollView(
                  child: Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [
                    for (final it in items)
                      NeonBtn(
                        w: 92, h: 64,
                        onTap: () { Navigator.pop(dc); (it[2] as VoidCallback)(); },
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(it[1] as IconData, color: Colors.white, size: 22),
                          const SizedBox(height: 3),
                          Text(it[0] as String, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
                        ]),
                      ),
                  ]),
                ),
              ),
            ));
  }
}

/// Transparent trackpad: one finger moves the cursor, a quick tap clicks, two fingers scroll.
class Trackpad extends StatefulWidget {
  final Net net;
  const Trackpad({super.key, required this.net});
  @override
  State<Trackpad> createState() => _TP();
}

class _TP extends State<Trackpad> {
  Offset cur = const Offset(0.5, 0.5);
  final Map<int, Offset> ptr = {};
  int t0 = 0;
  double moved = 0, scrollAcc = 0;
  bool multi = false;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (_, c) {
        return Listener(
          behavior: HitTestBehavior.opaque,
          onPointerDown: (e) {
            ptr[e.pointer] = e.localPosition;
            if (ptr.length == 1) { t0 = e.timeStamp.inMilliseconds; moved = 0; multi = false; scrollAcc = 0; } else { multi = true; }
          },
          onPointerMove: (e) {
            final prev = ptr[e.pointer];
            ptr[e.pointer] = e.localPosition;
            if (prev == null) return;
            final d = e.localPosition - prev;
            moved += d.distance;
            if (ptr.length >= 2) {
              scrollAcc += d.dy;
              if (scrollAcc.abs() > 60) {
                final dir = scrollAcc > 0 ? 1.0 : -1.0;
                widget.net.swipe(cur.dx, cur.dy, cur.dx, (cur.dy + dir * 0.3).clamp(0.02, 0.98).toDouble());
                scrollAcc = 0;
              }
            } else {
              setState(() => cur = Offset(
                  (cur.dx + d.dx / c.maxWidth * 1.6).clamp(0.0, 1.0).toDouble(),
                  (cur.dy + d.dy / c.maxHeight * 1.6).clamp(0.0, 1.0).toDouble()));
            }
          },
          onPointerUp: (e) {
            ptr.remove(e.pointer);
            if (ptr.isEmpty && !multi && moved < 12 && e.timeStamp.inMilliseconds - t0 < 300) {
              HapticFeedback.lightImpact();
              widget.net.tap(cur.dx, cur.dy);
            }
          },
          onPointerCancel: (e) => ptr.remove(e.pointer),
          child: CustomPaint(size: Size.infinite, painter: _CurP(cur)),
        );
      });
}

class _CurP extends CustomPainter {
  final Offset cur;
  _CurP(this.cur);
  @override
  void paint(Canvas c, Size s) {
    final p = Offset(cur.dx * s.width, cur.dy * s.height);
    final path = Path()
      ..moveTo(p.dx, p.dy)..lineTo(p.dx, p.dy + 20)..lineTo(p.dx + 5, p.dy + 15)..lineTo(p.dx + 9, p.dy + 24)
      ..lineTo(p.dx + 13, p.dy + 22)..lineTo(p.dx + 9, p.dy + 14)..lineTo(p.dx + 16, p.dy + 14)..close();
    c.drawPath(path, Paint()..color = Colors.white);
    c.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = Colors.black);
  }

  @override
  bool shouldRepaint(_CurP o) => o.cur != cur;
}

class ConnectScreen extends StatelessWidget {
  final Net net;
  ConnectScreen({super.key, required this.net});
  late final id = TextEditingController(text: net.savedId), pin = TextEditingController(text: net.savedPin),
      srv = TextEditingController(text: serverUrl.replaceFirst('wss://', ''));
  @override
  Widget build(BuildContext c) => Scaffold(
      body: SafeArea(
          child: Center(
              child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
                  child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 520),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Text('Connect to your TV', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                        TextField(controller: srv, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'TV address (home Wi-Fi) or server (internet)', hintText: '192.168.1.5  or  myserver.workers.dev')),
                        TextField(controller: id, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'TV ID (internet only, skip on home Wi-Fi)')),
                        TextField(controller: pin, maxLength: 6, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '6-digit code')),
                        if (net.error != null) Text(net.error!, style: const TextStyle(color: Colors.red)),
                        if (net.lastTrace != null) Text('Steps before it closed:\n${net.lastTrace}', style: const TextStyle(fontSize: 12)),
                        StatefulBuilder(builder: (c2, set) => SwitchListTile(
                            title: const Text('Show TV video'), value: net.useVideo,
                            onChanged: (v) { net.setVideo(v); set(() {}); })),
                        FilledButton(onPressed: () => net.connect(id.text.replaceAll(RegExp(r"\s"), ""), pin.text.trim(), srv.text), child: const Text('Connect')),
                      ]))))));
}

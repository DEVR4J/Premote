import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

String serverUrl = ''; // set inside the app, saved on the phone

String normalizeServer(String input) {
  var t = input.trim();
  while (t.endsWith('/')) { t = t.substring(0, t.length - 1); }
  if (t.isEmpty) return '';
  if (RegExp(r'^\d{1,3}(\.\d{1,3}){3}(:\d+)?$').hasMatch(t)) return t.contains(':') ? 'ws://$t' : 'ws://$t:8765'; // TV on home Wi-Fi
  if (t.startsWith('wss://') || t.startsWith('ws://')) return t;
  if (t.startsWith('https://')) return 'wss://${t.substring(8)}';
  if (t.startsWith('http://')) return 'ws://${t.substring(7)}';
  return 'wss://$t';
}

class Device {
  String name, address, id, pin;
  Device({required this.name, required this.address, required this.id, required this.pin});
  Map<String, dynamic> toJson() => {'name': name, 'address': address, 'id': id, 'pin': pin};
  factory Device.fromJson(Map<String, dynamic> j) =>
      Device(name: '${j['name'] ?? ''}', address: '${j['address'] ?? ''}', id: '${j['id'] ?? ''}', pin: '${j['pin'] ?? ''}');
  String get shown => address.replaceFirst('wss://', '').replaceFirst('ws://', '');
}

class Quality {
  int height, fps, kbps;
  String codec; // auto | h264 | vp8 | vp9
  Quality({this.height = 720, this.fps = 30, this.kbps = 3000, this.codec = 'auto'});
  Map<String, dynamic> toJson() => {'h': height, 'fps': fps, 'kbps': kbps, 'codec': codec};
}

class Net extends ChangeNotifier {
  WebSocketChannel? _ws;
  RTCPeerConnection? _pc;
  RTCDataChannel? _dc;
  final video = RTCVideoRenderer();
  bool session = false, hasVideo = false, loaded = false;
  String? error;
  String savedId = '', savedPin = '';
  String? lastTrace;      // steps reached before the app last closed
  bool useVideo = true;   // turns off automatically after a crash while showing video
  bool _traceOn = false;
  RTCDataChannel? _fdc;
  Quality q = Quality();
  List<Device> devices = [];
  String? _pendName;
  bool _pendRemember = false;
  bool reconnecting = false;
  bool get inController => session || reconnecting;
  bool _sentQ = false;
  double videoAspect = 16 / 9;
  String? banner;
  Timer? _bt;
  String? controlWarning; // set when the TV says it cannot be controlled
  Future<void> _chain = Future.value();

  File get _tf => File('${Directory.systemTemp.path}/trace.txt');
  void _resetTrace() { _traceOn = true; try { _tf.writeAsStringSync(''); } catch (_) {} }
  void _trace(String s) {
    if (!_traceOn) return;
    try { _tf.writeAsStringSync('$s\n', mode: FileMode.append, flush: true); } catch (_) {}
    if (s == 'done') _traceOn = false;
  }
  Future<void> setVideo(bool v) async {
    useVideo = v;
    (await SharedPreferences.getInstance()).setBool('video', v);
  }

  Future<void> init() async {
    await video.initialize();
    video.onResize = () {
      final w = video.videoWidth, h = video.videoHeight;
      if (w > 0 && h > 0) { videoAspect = w / h; notifyListeners(); }
    };
    final p = await SharedPreferences.getInstance();
    savedId = p.getString('id') ?? ''; savedPin = p.getString('pin') ?? '';
    serverUrl = p.getString('server') ?? '';
    useVideo = p.getBool('video') ?? true;
    q = Quality(height: p.getInt('q_h') ?? 720, fps: p.getInt('q_fps') ?? 30, kbps: p.getInt('q_kbps') ?? 3000, codec: p.getString('q_codec') ?? 'auto');
    try {
      final raw = p.getString('devices');
      if (raw != null) devices = (jsonDecode(raw) as List).map((e) => Device.fromJson(Map<String, dynamic>.from(e))).toList();
    } catch (_) {}
    var crashed = false;
    try {
      if (_tf.existsSync()) {
        final lines = _tf.readAsLinesSync().where((l) => l.trim().isNotEmpty).toList();
        _tf.deleteSync();
        if (lines.isNotEmpty && lines.last != 'done') {
          crashed = true;
          lastTrace = lines.reversed.take(8).toList().reversed.join('\n');
          if (lines.any((l) => l.startsWith('track received'))) { useVideo = false; p.setBool('video', false); }
        }
      }
    } catch (_) {}
    if (crashed) error = 'The app closed during the last connection, so it did not start by itself.';
    loaded = true; notifyListeners();
  }

  Future<void> connect(String id, String pin, [String? server, String? name, bool remember = false]) async {
    await close(); error = null; lastTrace = null; savedId = id; savedPin = pin;
    _pendName = name; _pendRemember = remember;
    _resetTrace(); _trace('connect pressed'); _sentQ = false;
    if (server != null) serverUrl = normalizeServer(server);
    if (serverUrl.isEmpty) { error = 'Enter the server address'; notifyListeners(); return; }
    (await SharedPreferences.getInstance()).setString('server', serverUrl);
    notifyListeners();
    try {
      _ws = WebSocketChannel.connect(Uri.parse(serverUrl));
      _ws!.stream.listen(_on,
          onError: (_) { error = 'Cannot reach server'; session = false; reconnecting = false; notifyListeners(); },
          onDone: () { if (session) { session = false; error = 'Connection lost'; notifyListeners(); } });
      _send({'type': 'connect', 'id': id, 'pin': pin, 'quality': q.toJson()});
    } catch (_) { error = 'Invalid server address'; notifyListeners(); }
  }

  // handle messages strictly one after another (the TV's offer can arrive before our peer is ready)
  void _on(dynamic raw) {
    _chain = _chain.then((_) => _on2(raw)).catchError((e) { error = 'Error: $e'; notifyListeners(); });
  }

  Future<void> _on2(dynamic raw) async {
    final m = jsonDecode(raw);
    if (m['type'] == 'error') { error = m['msg']; session = false; reconnecting = false; }
    if (m['type'] == 'connected') {
      session = true; reconnecting = false; _trace('connected msg');
      if (_pendRemember) { _pendRemember = false; await _remember(); }
      final p = await SharedPreferences.getInstance();
      p.setString('id', savedId); p.setString('pin', savedPin);
      await _peer(m['ice']);
    }
    if (m['type'] == 'sig') await _sig(m['data']);
    notifyListeners();
  }

  Future<void> _peer(List ice) async {
    _pc = await createPeerConnection({'iceServers': ice, 'sdpSemantics': 'unified-plan'});
    _trace('pc created');
    _pc!.onIceConnectionState = (s) {
      _trace('ice $s');
      if (s == RTCIceConnectionState.RTCIceConnectionStateConnected || s == RTCIceConnectionState.RTCIceConnectionStateCompleted) _trace('done');
    };
    _pc!.onIceCandidate = (c) => _send({'type': 'sig', 'data': {'ice': c.toMap()}});
    _pc!.onTrack = (e) {
      _trace('track received');
      if (!useVideo) { _trace('video skipped'); return; }
      if (e.streams.isNotEmpty) { video.srcObject = e.streams[0]; hasVideo = true; _trace('video attached'); notifyListeners(); }
    };
    _pc!.onDataChannel = (ch) {
      if (ch.label == 'file') { _fdc = ch; return; }
      _dc = ch;
      ch.onMessage = (m) {
        try {
          final d = jsonDecode(m.text);
          if (d['t'] == 'status') {
            controlWarning = (d['adb'] == true || d['a11y'] == true)
                ? null
                : 'TV control is OFF. On the TV: turn on Remote Agent in Accessibility settings, or USB debugging.';
            if (!_sentQ) { _sentQ = true; _cmd({'t': 'quality', ...q.toJson()}); }
            notifyListeners();
          }
          if (d['t'] == 'fileok') flash('Saved on TV: ${d['path'] ?? d['name']}');
        } catch (_) {}
      };
    };
  }

  Future<void> _sig(Map d) async {
    if (d['sdp'] != null) {
      _trace('offer received');
      await _pc!.setRemoteDescription(RTCSessionDescription(d['sdp'], d['sdpType']));
      _trace('remote desc set');
      final a = await _pc!.createAnswer();
      _trace('answer created');
      await _pc!.setLocalDescription(a);
      _trace('local desc set');
      _send({'type': 'sig', 'data': {'sdp': a.sdp, 'sdpType': a.type}});
      _trace('answer sent');
    } else if (d['ice'] != null) {
      final c = d['ice'];
      await _pc!.addCandidate(RTCIceCandidate(c['candidate'], c['sdpMid'], c['sdpMLineIndex']));
    }
  }

  void _send(Map o) => _ws?.sink.add(jsonEncode(o));
  void _cmd(Map m) => _dc?.send(RTCDataChannelMessage(jsonEncode(m)));
  void key(String k) => _cmd({'t': 'key', 'k': k});
  void launch(String pkg) => _cmd({'t': 'launch', 'pkg': pkg});
  void tap(double x, double y) => _cmd({'t': 'tap', 'x': x, 'y': y});
  void swipe(double x1, double y1, double x2, double y2) => _cmd({'t': 'swipe', 'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2});

  // ---- saved devices ----
  Future<void> _saveDevices() async {
    (await SharedPreferences.getInstance()).setString('devices', jsonEncode(devices.map((d) => d.toJson()).toList()));
  }

  Future<void> _remember() async {
    final i = devices.indexWhere((d) => d.address == serverUrl && d.id == savedId);
    final given = (_pendName ?? '').trim();
    if (i >= 0) {
      devices[i].pin = savedPin;
      if (given.isNotEmpty) devices[i].name = given;
    } else {
      final tail = savedId.isNotEmpty ? savedId.substring(savedId.length > 3 ? savedId.length - 3 : 0) : serverUrl.replaceFirst('ws://', '').replaceFirst('wss://', '');
      devices.add(Device(name: given.isNotEmpty ? given : 'TV $tail', address: serverUrl, id: savedId, pin: savedPin));
    }
    await _saveDevices();
  }

  Future<void> renameDevice(Device d, String n) async { if (n.trim().isNotEmpty) { d.name = n.trim(); await _saveDevices(); notifyListeners(); } }
  Future<void> deleteDevice(Device d) async { devices.remove(d); await _saveDevices(); notifyListeners(); }
  Future<void> disconnect() async { await close(); reconnecting = false; notifyListeners(); }

  /// Change video quality. Resolution, frame rate and bitrate apply live; a new format reconnects.
  Future<void> setQuality(Quality nq) async {
    final codecChanged = nq.codec != q.codec;
    q = nq;
    final p = await SharedPreferences.getInstance();
    p.setInt('q_h', q.height); p.setInt('q_fps', q.fps); p.setInt('q_kbps', q.kbps); p.setString('q_codec', q.codec);
    if (!session) { notifyListeners(); return; }
    _cmd({'t': 'quality', ...q.toJson()});
    if (codecChanged) {
      reconnecting = true;
      flash('Reconnecting to change the video format...');
      await Future.delayed(const Duration(milliseconds: 500));
      connect(savedId, savedPin);
    } else {
      flash('Video: ${q.height}p, ${q.fps} fps, ${q.kbps ~/ 1000} Mbps');
    }
  }

  void text(String s) => _cmd({'t': 'text', 's': s});
  void open(String what) => _cmd({'t': 'open', 'what': what});

  void flash(String msg) {
    banner = msg; notifyListeners();
    _bt?.cancel();
    _bt = Timer(const Duration(seconds: 3), () { banner = null; notifyListeners(); });
  }

  /// Send a file to the TV over the "file" data channel (16 KB pieces).
  Future<void> sendFile() async {
    final ch = _fdc;
    if (ch == null || ch.state != RTCDataChannelState.RTCDataChannelOpen) { flash('TV is not ready for files yet'); return; }
    final r = await FilePicker.platform.pickFiles(withReadStream: true);
    final f = r?.files.single;
    if (f == null || f.readStream == null) return;
    try {
      ch.send(RTCDataChannelMessage(jsonEncode({'t': 'file', 'name': f.name, 'size': f.size})));
      var sent = 0, lastPct = -1;
      await for (final chunk in f.readStream!) {
        for (var i = 0; i < chunk.length; i += 16000) {
          final end = (i + 16000 < chunk.length) ? i + 16000 : chunk.length;
          ch.send(RTCDataChannelMessage.fromBinary(Uint8List.fromList(chunk.sublist(i, end))));
          sent += end - i;
          final pct = f.size == 0 ? 100 : (sent * 100 ~/ f.size);
          if (pct != lastPct) { lastPct = pct; banner = 'Sending ${f.name}  $pct%'; notifyListeners(); }
          await Future.delayed(const Duration(milliseconds: 8));
        }
      }
      flash('Sent ${f.name}, waiting for TV...');
    } catch (e) { flash('File send failed: $e'); }
  }

  Future<void> close() async {
    await _pc?.close(); _pc = null; _dc = null; _fdc = null; await _ws?.sink.close(); _ws = null;
    session = false; hasVideo = false; video.srcObject = null;
  }

  Future<void> forget() async {
    await close();
    final p = await SharedPreferences.getInstance();
    p.remove('id'); p.remove('pin');
    savedId = ''; savedPin = ''; notifyListeners();
  }
}

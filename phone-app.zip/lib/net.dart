import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

String serverUrl = ''; // set inside the app, saved on the phone

String normalizeServer(String input) {
  var t = input.trim();
  while (t.endsWith('/')) { t = t.substring(0, t.length - 1); }
  if (t.isEmpty()) return '';
  if (RegExp(r'^\d{1,3}(\.\d{1,3}){3}(:\d+)?$').hasMatch(t)) return t.contains(':') ? 'ws://$t' : 'ws://$t:8765'; // TV on home Wi-Fi
  if (t.startsWith('wss://') || t.startsWith('ws://')) return t;
  if (t.startsWith('https://')) return 'wss://${t.substring(8)}';
  if (t.startsWith('http://')) return 'ws://${t.substring(7)}';
  return 'wss://$t';
}

class Net extends ChangeNotifier {
  WebSocketChannel? _ws;
  RTCPeerConnection? _pc;
  RTCDataChannel? _dc;
  final video = RTCVideoRenderer();
  bool session = false, hasVideo = false, loaded = false;
  String? error;
  String savedId = '', savedPin = '';

  Future<void> init() async {
    await video.initialize();
    final p = await SharedPreferences.getInstance();
    savedId = p.getString('id') ?? ''; savedPin = p.getString('pin') ?? '';
    serverUrl = p.getString('server') ?? '';
    loaded = true; notifyListeners();
    if (savedPin.isNotEmpty && serverUrl.isNotEmpty && (savedId.isNotEmpty || serverUrl.startsWith('ws://'))) connect(savedId, savedPin);
  }

  Future<void> connect(String id, String pin, [String? server]) async {
    await close(); error = null; savedId = id; savedPin = pin;
    if (server != null) serverUrl = normalizeServer(server);
    if (serverUrl.isEmpty) { error = 'Enter the server address'; notifyListeners(); return; }
    (await SharedPreferences.getInstance()).setString('server', serverUrl);
    notifyListeners();
    try {
      _ws = WebSocketChannel.connect(Uri.parse(serverUrl));
      _ws!.stream.listen(_on,
          onError: (_) { error = 'Cannot reach server'; session = false; notifyListeners(); },
          onDone: () { if (session) { session = false; error = 'Connection lost'; notifyListeners(); } });
      _send({'type': 'connect', 'id': id, 'pin': pin});
    } catch (_) { error = 'Invalid server address'; notifyListeners(); }
  }

  void _on(dynamic raw) async {
    final m = jsonDecode(raw);
    if (m['type'] == 'error') { error = m['msg']; session = false; }
    if (m['type'] == 'connected') {
      session = true;
      final p = await SharedPreferences.getInstance();
      p.setString('id', savedId); p.setString('pin', savedPin);
      await _peer(m['ice']);
    }
    if (m['type'] == 'sig') await _sig(m['data']);
    notifyListeners();
  }

  Future<void> _peer(List ice) async {
    _pc = await createPeerConnection({'iceServers': ice, 'sdpSemantics': 'unified-plan'});
    _pc!.onIceCandidate = (c) => _send({'type': 'sig', 'data': {'ice': c.toMap()}});
    _pc!.onTrack = (e) { if (e.streams.isNotEmpty) { video.srcObject = e.streams[0]; hasVideo = true; notifyListeners(); } };
    _pc!.onDataChannel = (ch) => _dc = ch;
  }

  Future<void> _sig(Map d) async {
    if (d['sdp'] != null) {
      await _pc!.setRemoteDescription(RTCSessionDescription(d['sdp'], d['sdpType']));
      final a = await _pc!.createAnswer();
      await _pc!.setLocalDescription(a);
      _send({'type': 'sig', 'data': {'sdp': a.sdp, 'sdpType': a.type}});
    } else if (d['ice'] != null) {
      final c = d['ice'];
      await _pc!.addCandidate(RTCIceCandidate(c['candidate'], c['sdpMid'], c['sdpMLineIndex']));
    }
  }

  void _send(Map o) => _ws?.sink.add(jsonEncode(o));
  void _cmd(Map m) => _dc?.send(RTCDataChannelMessage(jsonEncode(m)));
  void key(String k) => _cmd({'t': 'key', 'k': k});
  void launch(String pkg) => _cmd({'t': 'launch', 'pkg': pkg});
  void tap(double x, double y) => _cmd({'t': 'tap', 'x': x, 'y': y});
  void swipe(double x1, double y1, double x2, double y2) => _cmd({'t': 'swipe', 'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2});

  Future<void> close() async {
    await _pc?.close(); _pc = null; _dc = null; await _ws?.sink.close(); _ws = null;
    session = false; hasVideo = false; video.srcObject = null;
  }

  Future<void> forget() async {
    await close();
    final p = await SharedPreferences.getInstance();
    p.remove('id'); p.remove('pin');
    savedId = ''; savedPin = ''; notifyListeners();
  }
}

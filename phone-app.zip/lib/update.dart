import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const int kBuild = 0;               // filled in by the build workflow
const String kRepo = 'OWNER/REPO';  // filled in by the build workflow
const String kApk = 'ATC-Phone.apk';

class UpdateInfo {
  final String tag, url;
  final int build;
  UpdateInfo(this.tag, this.build, this.url);
}

/// Checks GitHub Releases for a newer build, downloads it and installs it through Android's installer.
class Updater extends ChangeNotifier {
  static const _ch = MethodChannel('atc/install');
  String status = '';
  UpdateInfo? info;
  bool busy = false, auto = true;

  Future<void> init() async {
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'installResult') { status = '${call.arguments}'; busy = false; notifyListeners(); }
    });
    final p = await SharedPreferences.getInstance();
    auto = p.getBool('auto_update') ?? true;
    notifyListeners();
    check();
  }

  Future<void> setAuto(bool v) async {
    auto = v;
    (await SharedPreferences.getInstance()).setBool('auto_update', v);
    notifyListeners();
  }

  Future<void> check() async {
    if (kRepo.startsWith('OWNER')) { status = 'Updates are not set up in this build'; notifyListeners(); return; }
    if (busy) return;
    busy = true; status = 'Checking for updates...'; notifyListeners();
    final c = HttpClient();
    try {
      final req = await c.getUrl(Uri.parse('https://api.github.com/repos/$kRepo/releases?per_page=20'));
      req.headers.set('Accept', 'application/vnd.github+json');
      req.headers.set('User-Agent', 'ATC-Updater');
      final res = await req.close();
      final body = await res.transform(utf8.decoder).join();
      if (res.statusCode == 404) {
        status = 'No releases found in $kRepo (is the repo public?)'; info = null;
      } else if (res.statusCode != 200) {
        status = 'Update check failed (${res.statusCode})';
      } else {
        UpdateInfo? best;
        for (final j in (jsonDecode(body) as List)) {
          if (j['draft'] == true || j['prerelease'] == true) continue;
          final tag = '${j['tag_name']}';
          final n = int.tryParse(RegExp(r'(\d+)$').firstMatch(tag)?.group(1) ?? '') ?? 0;
          for (final a in (j['assets'] as List)) {
            if ('${a['name']}' == kApk && (best == null || n > best.build)) best = UpdateInfo(tag, n, '${a['browser_download_url']}');
          }
        }
        if (best == null) { info = null; status = 'No $kApk in the releases of $kRepo'; }
        else if (best.build > kBuild) { info = best; status = 'Update available: ${best.tag}'; }
        else { info = null; status = 'Up to date (build $kBuild)'; }
      }
    } catch (e) {
      status = 'Update check failed: $e';
    } finally { c.close(); }
    busy = false; notifyListeners();
    if (info != null && auto) install();
  }

  Future<void> install() async {
    final i = info;
    if (i == null || busy) return;
    busy = true; status = 'Downloading...'; notifyListeners();
    final c = HttpClient();
    try {
      final file = File('${Directory.systemTemp.path}/update.apk');
      final req = await c.getUrl(Uri.parse(i.url));
      req.headers.set('User-Agent', 'ATC-Updater');
      final res = await req.close();
      if (res.statusCode != 200) {
        status = 'Download failed (${res.statusCode})';
      } else {
        final sink = file.openWrite();
        var got = 0, last = -1;
        await for (final chunk in res) {
          sink.add(chunk);
          got += chunk.length;
          if (res.contentLength > 0) {
            final pct = got * 100 ~/ res.contentLength;
            if (pct != last) { last = pct; status = 'Downloading $pct%'; notifyListeners(); }
          }
        }
        await sink.close();
        status = 'Starting installer...'; notifyListeners();
        final r = await _ch.invokeMethod<String>('install', file.path);
        if (r == 'need_permission') {
          status = 'Allow "Install unknown apps" for this app, then press Update again.';
        } else if (r == 'ok') {
          status = 'Confirm the update in the installer window.';
        } else {
          status = r ?? 'The installer did not start';
        }
      }
    } catch (e) {
      status = 'Update failed: $e';
    } finally { c.close(); }
    busy = false; notifyListeners();
  }
}

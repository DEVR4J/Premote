import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';

const kBlue = Color(0xFF2F7BFF);
const kPurple = Color(0xFF7A35E8);
const kEdge = Color(0xFF7CC4FF);
const kDark = Color(0xFF0A0E3D);

// ---------------------------------------------------------------- themes
enum ThemeKind { normal, glass, light, rgb }

class CTheme {
  final ThemeKind kind;
  const CTheme(this.kind);
  static CTheme byName(String n) => CTheme(ThemeKind.values.firstWhere((k) => k.name == n, orElse: () => ThemeKind.normal));
  bool get rgb => kind == ThemeKind.rgb;
  Color get icon {
    switch (kind) {
      case ThemeKind.light: return const Color(0xFF2B3150);
      case ThemeKind.rgb: return const Color(0xFF59E8FF);
      default: return Colors.white;
    }
  }
  // colours for text and chips inside pop-up windows
  Color get text => kind == ThemeKind.light ? const Color(0xFF232846) : Colors.white;
  Color get dim => kind == ThemeKind.light ? const Color(0xFF5A6188) : Colors.white70;
  Color get faint => kind == ThemeKind.light ? const Color(0xFF8A90B0) : Colors.white38;
  Color get chipBg => kind == ThemeKind.light ? Colors.white : const Color(0x33FFFFFF);
  Color get accent {
    switch (kind) {
      case ThemeKind.glass: return const Color(0xFF7C5CFF);
      case ThemeKind.light: return const Color(0xFF5C6BC0);
      case ThemeKind.rgb: return const Color(0xFFFF2EC4);
      default: return kPurple;
    }
  }
  Color get label => kind == ThemeKind.light ? const Color(0xFF3A4062) : (kind == ThemeKind.rgb ? const Color(0xFF59E8FF) : Colors.white);
  Color get labelBg {
    switch (kind) {
      case ThemeKind.glass: return const Color(0xFF0A0C16);
      case ThemeKind.light: return const Color(0xFFEEF0F8);
      case ThemeKind.rgb: return const Color(0xFF0B0C14);
      default: return const Color(0xFF12104A);
    }
  }
}

/// Gives the controller pieces their theme and the clock that drives the RGB animation.
class ThemeScope extends InheritedWidget {
  final CTheme theme;
  final Animation<double> clock;
  const ThemeScope({super.key, required this.theme, required this.clock, required super.child});
  static ThemeScope? maybeOf(BuildContext c) => c.dependOnInheritedWidgetOfExactType<ThemeScope>();
  @override
  bool updateShouldNotify(ThemeScope o) => o.theme.kind != theme.kind;
}

/// Pop-up window that follows the controller theme (frame, background, text, buttons inside).
class ThemedDialog extends StatelessWidget {
  final CTheme theme;
  final Animation<double> clock;
  final Widget child;
  const ThemedDialog({super.key, required this.theme, required this.clock, required this.child});

  @override
  Widget build(BuildContext c) {
    final r = BorderRadius.circular(20);
    final inner = Material(type: MaterialType.transparency, child: child);
    Widget shell(double t) {
      switch (theme.kind) {
        case ThemeKind.rgb:
          return Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(borderRadius: r, gradient: rainbowSweep(t), boxShadow: [BoxShadow(color: hue(t).withOpacity(0.5), blurRadius: 18)]),
              child: ClipRRect(borderRadius: BorderRadius.circular(17), child: Container(color: const Color(0xFF0B0C14), child: inner)));
        case ThemeKind.glass:
          return Container(
              decoration: BoxDecoration(
                  borderRadius: r, color: const Color(0xF010131E),
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0x22FFFFFF), Color(0x06FFFFFF)]),
                  border: Border.all(color: const Color(0x55FFFFFF), width: 1),
                  boxShadow: const [BoxShadow(color: Color(0x99000000), blurRadius: 24)]),
              child: inner);
        case ThemeKind.light:
          return Container(
              decoration: BoxDecoration(borderRadius: r, color: const Color(0xFFEEF0F8), boxShadow: const [
                BoxShadow(color: Colors.white, offset: Offset(-5, -5), blurRadius: 10),
                BoxShadow(color: Color(0x55606C9B), offset: Offset(6, 7), blurRadius: 14),
              ]),
              child: inner);
        case ThemeKind.normal:
          return Container(decoration: BoxDecoration(borderRadius: r, color: const Color(0xFF0E1250), border: Border.all(color: kEdge, width: 1.5)), child: inner);
      }
    }
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: ThemeScope(theme: theme, clock: clock, child: theme.rgb ? AnimatedBuilder(animation: clock, builder: (_, __) => shell(clock.value)) : shell(0)),
    );
  }
}

const _rainbow = [Color(0xFF00E5FF), Color(0xFF00FF88), Color(0xFFFFE600), Color(0xFFFF8A00), Color(0xFFFF2EC4), Color(0xFF8A4DFF), Color(0xFF00E5FF)];
SweepGradient rainbowSweep(double t) => SweepGradient(colors: _rainbow, transform: GradientRotation(t * 2 * math.pi));
Color hue(double t) => HSVColor.fromAHSV(1, (t * 360) % 360, 0.9, 1).toColor();

// ---------------------------------------------------------------- background
class _BgPainter extends CustomPainter {
  final ThemeKind kind;
  _BgPainter(this.kind);
  void _blob(Canvas c, Offset o, double r, Color col) => c.drawCircle(
      o, r, Paint()..shader = RadialGradient(colors: [col, col.withOpacity(0)]).createShader(Rect.fromCircle(center: o, radius: r)));
  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    switch (kind) {
      case ThemeKind.glass:
        c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFF080A14));
        _blob(c, Offset(w * 0.05, h * 0.35), h * 0.55, const Color(0x663B2A8F));
        _blob(c, Offset(w * 0.98, h * 0.25), h * 0.45, const Color(0x55402C9E));
        _blob(c, Offset(w * 0.04, h * 0.95), h * 0.35, const Color(0x44243C96));
        _blob(c, Offset(w * 0.92, h * 0.95), h * 0.40, const Color(0x44382690));
        break;
      case ThemeKind.light:
        c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFFEEF0F8));
        _blob(c, Offset(w * 0.02, h * 0.30), h * 0.55, const Color(0x99A9C8FF));
        _blob(c, Offset(w * 0.98, h * 0.30), h * 0.50, const Color(0x99C6B8FF));
        _blob(c, Offset(w * 0.10, h * 0.98), h * 0.40, const Color(0x77B3D5FF));
        _blob(c, Offset(w * 0.90, h * 0.95), h * 0.40, const Color(0x77CABFFF));
        break;
      case ThemeKind.rgb:
        c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFF0B0C14));
        final line = Paint()..color = const Color(0x0EFFFFFF)..strokeWidth = 1.2;
        for (double x = -h; x < w; x += 7) { c.drawLine(Offset(x, 0), Offset(x + h, h), line); }
        _blob(c, Offset(0, h * 0.30), h * 0.60, const Color(0x2400E5FF));
        _blob(c, Offset(w, h * 0.30), h * 0.60, const Color(0x24FF2EC4));
        break;
      case ThemeKind.normal:
        break;
    }
  }
  @override
  bool shouldRepaint(_BgPainter o) => o.kind != kind;
}

Widget themedBackground(CTheme th) => CustomPaint(painter: _BgPainter(th.kind), size: Size.infinite);

// ---------------------------------------------------------------- buttons
/// Flat neon gradient style used by the Normal theme.
BoxDecoration neon({bool circle = false, double radius = 18, bool active = false}) => BoxDecoration(
      shape: circle ? BoxShape.circle : BoxShape.rectangle,
      borderRadius: circle ? null : BorderRadius.circular(radius),
      gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: active ? const [Color(0xFFFF4FD8), Color(0xFF8A2BE2)] : const [kBlue, kPurple]),
      border: Border.all(color: active ? const Color(0xFFFFB3F0) : kEdge, width: 1.6),
      boxShadow: const [BoxShadow(color: Color(0x553A8DFF), blurRadius: 10)],
    );

/// One button face in the chosen theme. Size is decided by the caller, only the look changes.
Widget themedFace({
  required CTheme th, required double t, required double w, required double h,
  required bool circle, required double radius, required bool active, required Widget child,
}) {
  final shape = circle ? BoxShape.circle : BoxShape.rectangle;
  final br = circle ? null : BorderRadius.circular(radius);
  switch (th.kind) {
    case ThemeKind.rgb:
      return Container(
        width: w, height: h, padding: const EdgeInsets.all(2.5),
        decoration: BoxDecoration(
            shape: shape, borderRadius: br, gradient: rainbowSweep(t),
            boxShadow: [BoxShadow(color: hue(t).withOpacity(active ? 0.8 : 0.4), blurRadius: active ? 18 : 10)]),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
              shape: shape, borderRadius: circle ? null : BorderRadius.circular(math.max(0.0, radius - 2.5)),
              gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: active ? const [Color(0xFF4A1F5E), Color(0xFF1A0D26)] : const [Color(0xFF242738), Color(0xFF0D0E16)])),
          child: child,
        ),
      );
    case ThemeKind.glass:
      return Container(
        width: w, height: h, alignment: Alignment.center,
        decoration: BoxDecoration(
            shape: shape, borderRadius: br, color: const Color(0xCC10131E),
            gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: active ? const [Color(0x557C5CFF), Color(0x1A7C5CFF)] : const [Color(0x2EFFFFFF), Color(0x08FFFFFF)]),
            border: Border.all(color: active ? const Color(0xAA9F8CFF) : const Color(0x40FFFFFF), width: 1),
            boxShadow: const [BoxShadow(color: Color(0x66000000), blurRadius: 12, offset: Offset(0, 5))]),
        child: child,
      );
    case ThemeKind.light:
      return Container(
        width: w, height: h, alignment: Alignment.center,
        decoration: BoxDecoration(
            shape: shape, borderRadius: br,
            gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: active ? const [Color(0xFFD6DAF3), Color(0xFFC9CEEE)] : const [Color(0xFFF7F8FD), Color(0xFFE6E9F4)]),
            boxShadow: const [
              BoxShadow(color: Colors.white, offset: Offset(-4, -4), blurRadius: 8),
              BoxShadow(color: Color(0x44606C9B), offset: Offset(4, 5), blurRadius: 10),
            ]),
        child: child,
      );
    case ThemeKind.normal:
      return Container(width: w, height: h, alignment: Alignment.center, decoration: neon(circle: circle, radius: radius, active: active), child: child);
  }
}

class NeonBtn extends StatefulWidget {
  final double w, h;
  final Widget child;
  final VoidCallback onTap;
  final bool circle, active;
  const NeonBtn({super.key, required this.w, required this.h, required this.child, required this.onTap, this.circle = false, this.active = false});
  @override
  State<NeonBtn> createState() => _NB();
}

class _NB extends State<NeonBtn> {
  bool down = false;
  @override
  Widget build(BuildContext c) {
    final sc = ThemeScope.maybeOf(c);
    final th = sc?.theme ?? const CTheme(ThemeKind.normal);
    final r = math.min(widget.w, widget.h) * 0.28;
    Widget face(double t) => themedFace(th: th, t: t, w: widget.w, h: widget.h, circle: widget.circle, radius: r, active: widget.active, child: widget.child);
    return GestureDetector(
      onTapDown: (_) => setState(() => down = true),
      onTapUp: (_) { setState(() => down = false); widget.onTap(); },
      onTapCancel: () => setState(() => down = false),
      child: AnimatedScale(
        scale: down ? 0.94 : 1,
        duration: const Duration(milliseconds: 80),
        child: (th.rgb && sc != null) ? AnimatedBuilder(animation: sc.clock, builder: (_, __) => face(sc.clock.value)) : face(0),
      ),
    );
  }
}

class VolumePill extends StatelessWidget {
  final double w, h;
  final VoidCallback onUp, onDown;
  const VolumePill({super.key, required this.w, required this.h, required this.onUp, required this.onDown});
  @override
  Widget build(BuildContext c) {
    final sc = ThemeScope.maybeOf(c);
    final th = sc?.theme ?? const CTheme(ThemeKind.normal);
    Widget face(double t) => themedFace(
          th: th, t: t, w: w, h: h, circle: false, radius: w * 0.45, active: false,
          child: Column(children: [
            Expanded(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: onUp, child: Center(child: Icon(Icons.add, color: th.icon, size: w * 0.5)))),
            Container(height: 1.5, margin: EdgeInsets.symmetric(horizontal: w * 0.12), color: th.icon.withOpacity(0.5)),
            Expanded(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: onDown, child: Center(child: Icon(Icons.remove, color: th.icon, size: w * 0.5)))),
          ]),
        );
    return (th.rgb && sc != null) ? AnimatedBuilder(animation: sc.clock, builder: (_, __) => face(sc.clock.value)) : face(0);
  }
}

// ---------------------------------------------------------------- joystick
/// Round joystick: drag or tap toward UP/DOWN/LEFT/RIGHT; holding repeats the key.
class Joystick extends StatefulWidget {
  final double size;
  final void Function(String dir) onDir;
  const Joystick({super.key, required this.size, required this.onDir});
  @override
  State<Joystick> createState() => _JS();
}

class _JS extends State<Joystick> {
  Offset knob = Offset.zero;
  Timer? rep;
  String? cur;

  void _update(Offset local) {
    final r = widget.size / 2;
    var v = (local - Offset(r, r)) / r;
    if (v.distance > 1) v = v / v.distance;
    String? dir;
    if (v.distance > 0.35) dir = v.dx.abs() > v.dy.abs() ? (v.dx > 0 ? 'RIGHT' : 'LEFT') : (v.dy > 0 ? 'DOWN' : 'UP');
    setState(() => knob = v);
    if (dir != cur) {
      cur = dir;
      rep?.cancel();
      if (dir != null) {
        widget.onDir(dir);
        rep = Timer(const Duration(milliseconds: 380), () {
          rep = Timer.periodic(const Duration(milliseconds: 130), (_) { if (cur != null) widget.onDir(cur!); });
        });
      }
    }
  }

  void _end() { cur = null; rep?.cancel(); setState(() => knob = Offset.zero); }

  @override
  void dispose() { rep?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext c) {
    final sc = ThemeScope.maybeOf(c);
    final th = sc?.theme ?? const CTheme(ThemeKind.normal);
    Widget paint(double t) => CustomPaint(size: Size(widget.size, widget.size), painter: _JP(knob, th.kind, t));
    return Listener(
      onPointerDown: (e) => _update(e.localPosition),
      onPointerMove: (e) => _update(e.localPosition),
      onPointerUp: (_) => _end(),
      onPointerCancel: (_) => _end(),
      child: (th.rgb && sc != null) ? AnimatedBuilder(animation: sc.clock, builder: (_, __) => paint(sc.clock.value)) : paint(0),
    );
  }
}

class _JP extends CustomPainter {
  final Offset knob;
  final ThemeKind kind;
  final double t;
  _JP(this.knob, this.kind, this.t);

  @override
  void paint(Canvas c, Size s) {
    final r = s.width / 2;
    final ctr = Offset(r, r);
    final rect = Rect.fromCircle(center: ctr, radius: r);
    final k = ctr + knob * (r * 0.30);
    Color labelColor = Colors.white, lineColor = Colors.white;
    Paint ringFill, ringEdge, holeFill, holeEdge, nubFill, nubEdge;

    switch (kind) {
      case ThemeKind.normal:
        ringFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [kBlue, kPurple]).createShader(rect);
        ringEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = kEdge;
        holeFill = Paint()..color = kDark;
        holeEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5..color = kEdge;
        nubFill = Paint()..shader = const LinearGradient(colors: [Color(0xFFFF6AE0), kPurple]).createShader(Rect.fromCircle(center: k, radius: r * 0.26));
        nubEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white;
        break;
      case ThemeKind.glass:
        ringFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF2A2E44), Color(0xFF0F1220)]).createShader(rect);
        ringEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0x66FFFFFF);
        holeFill = Paint()..color = const Color(0xFF07080F);
        holeEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0x44FFFFFF);
        nubFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFF2F0FF), Color(0xFF8C84C8)]).createShader(Rect.fromCircle(center: k, radius: r * 0.26));
        nubEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0xB3FFFFFF);
        lineColor = const Color(0x66FFFFFF);
        break;
      case ThemeKind.light:
        c.drawCircle(ctr + const Offset(5, 6), r - 2, Paint()..color = const Color(0x55606C9B)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
        c.drawCircle(ctr - const Offset(5, 5), r - 2, Paint()..color = Colors.white..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
        ringFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFF8F9FE), Color(0xFFE0E3F1)]).createShader(rect);
        ringEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0x55FFFFFF);
        holeFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFDFE2EF), Color(0xFFF6F7FC)]).createShader(Rect.fromCircle(center: ctr, radius: r * 0.40));
        holeEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0x33485078);
        nubFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFD3D8EC)]).createShader(Rect.fromCircle(center: k, radius: r * 0.26));
        nubEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.2..color = const Color(0x33485078);
        labelColor = const Color(0xFF2B3150);
        lineColor = const Color(0x66485078);
        break;
      case ThemeKind.rgb:
        c.drawCircle(ctr, r - 2, Paint()..color = hue(t).withOpacity(0.35)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14));
        ringFill = Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF1E2030), Color(0xFF0A0B12)]).createShader(rect);
        ringEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 4..shader = rainbowSweep(t).createShader(rect);
        holeFill = Paint()..color = const Color(0xFF07080D);
        holeEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 3..shader = rainbowSweep(1 - t).createShader(Rect.fromCircle(center: ctr, radius: r * 0.40));
        nubFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFFF59E0), Color(0xFF59E8FF)]).createShader(Rect.fromCircle(center: k, radius: r * 0.26));
        nubEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white;
        labelColor = const Color(0xFF59E8FF);
        lineColor = const Color(0x6659E8FF);
        break;
    }

    c.drawCircle(ctr, r - 2, ringFill);
    c.drawCircle(ctr, r - 2, ringEdge);
    final line = Paint()..color = lineColor..strokeWidth = 2;
    for (final a in [math.pi / 4, 3 * math.pi / 4, 5 * math.pi / 4, 7 * math.pi / 4]) {
      final d = Offset(math.cos(a), math.sin(a));
      c.drawLine(ctr + d * (r * 0.62), ctr + d * (r * 0.93), line);
    }
    c.drawCircle(ctr, r * 0.40, holeFill);
    c.drawCircle(ctr, r * 0.40, holeEdge);
    _label(c, 'UP', ctr + Offset(0, -r * 0.77), 0, r, labelColor);
    _label(c, 'DOWN', ctr + Offset(0, r * 0.77), 0, r, labelColor);
    _label(c, 'LEFT', ctr + Offset(-r * 0.77, 0), -math.pi / 2, r, labelColor);
    _label(c, 'RIGHT', ctr + Offset(r * 0.77, 0), math.pi / 2, r, labelColor);
    if (kind == ThemeKind.light) {
      c.drawCircle(k + const Offset(3, 4), r * 0.26, Paint()..color = const Color(0x44606C9B)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));
    }
    c.drawCircle(k, r * 0.26, nubFill);
    c.drawCircle(k, r * 0.26, nubEdge);
  }

  void _label(Canvas c, String text, Offset p, double angle, double r, Color color) {
    final tp = TextPainter(
        text: TextSpan(text: text, style: TextStyle(color: color, fontSize: r * 0.17, fontWeight: FontWeight.w800, letterSpacing: 1)),
        textDirection: TextDirection.ltr)
      ..layout();
    c.save();
    c.translate(p.dx, p.dy);
    c.rotate(angle);
    tp.paint(c, Offset(-tp.width / 2, -tp.height / 2));
    c.restore();
  }

  @override
  bool shouldRepaint(_JP o) => o.knob != knob || o.kind != kind || o.t != t;
}

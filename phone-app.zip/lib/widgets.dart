import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';

const kBlue = Color(0xFF2F7BFF);
const kPurple = Color(0xFF7A35E8);
const kEdge = Color(0xFF7CC4FF);
const kDark = Color(0xFF0A0E3D);

// ---------------------------------------------------------------- themes
enum ThemeKind { normal, glass, light, rgb }

class CTheme {
  final ThemeKind kind;
  const CTheme(this.kind);
  static CTheme byName(String n) => CTheme(ThemeKind.values.firstWhere((k) => k.name == n, orElse: () => ThemeKind.normal));
  bool get rgb => kind == ThemeKind.rgb;
  Color get icon {
    switch (kind) {
      case ThemeKind.light: return const Color(0xFF2B3150);
      case ThemeKind.rgb: return const Color(0xFF59E8FF);
      default: return Colors.white;
    }
  }
  // colours for text and chips inside pop-up windows
  Color get text => kind == ThemeKind.light ? const Color(0xFF232846) : Colors.white;
  Color get dim => kind == ThemeKind.light ? const Color(0xFF5A6188) : Colors.white70;
  Color get faint => kind == ThemeKind.light ? const Color(0xFF8A90B0) : Colors.white38;
  Color get chipBg => kind == ThemeKind.light ? Colors.white : const Color(0x33FFFFFF);
  Color get accent {
    switch (kind) {
      case ThemeKind.glass: return const Color(0xFF7C5CFF);
      case ThemeKind.light: return const Color(0xFF5C6BC0);
      case ThemeKind.rgb: return const Color(0xFFFF2EC4);
      default: return kPurple;
    }
  }
  Color get label => kind == ThemeKind.light ? const Color(0xFF3A4062) : (kind == ThemeKind.rgb ? const Color(0xFF59E8FF) : Colors.white);
  Color get labelBg {
    switch (kind) {
      case ThemeKind.glass: return const Color(0xFF0A0C16);
      case ThemeKind.light: return const Color(0xFFEEF0F8);
      case ThemeKind.rgb: return const Color(0xFF0B0C14);
      default: return const Color(0xFF12104A);
    }
  }
}

/// Gives the controller pieces their theme and the clock that drives the RGB animation.
class ThemeScope extends InheritedWidget {
  final CTheme theme;
  final Animation<double> clock;
  const ThemeScope({super.key, required this.theme, required this.clock, required super.child});
  static ThemeScope? maybeOf(BuildContext c) => c.dependOnInheritedWidgetOfExactType<ThemeScope>();
  @override
  bool updateShouldNotify(ThemeScope o) => o.theme.kind != theme.kind;
}

/// Pop-up window that follows the controller theme (frame, background, text, buttons inside).
class ThemedDialog extends StatelessWidget {
  final CTheme theme;
  final Animation<double> clock;
  final Widget child;
  const ThemedDialog({super.key, required this.theme, required this.clock, required this.child});

  @override
  Widget build(BuildContext c) {
    final r = BorderRadius.circular(20);
    final inner = Material(type: MaterialType.transparency, child: child);
    Widget shell(double t) {
      switch (theme.kind) {
        case ThemeKind.rgb:
          return Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(borderRadius: r, gradient: rainbowSweep(t), boxShadow: [BoxShadow(color: hue(t).withOpacity(0.5), blurRadius: 18)]),
              child: ClipRRect(borderRadius: BorderRadius.circular(17), child: Container(color: const Color(0xFF0B0C14), child: inner)));
        case ThemeKind.glass:
          return Container(
              decoration: BoxDecoration(
                  borderRadius: r, color: const Color(0xF010131E),
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0x22FFFFFF), Color(0x06FFFFFF)]),
                  border: Border.all(color: const Color(0x55FFFFFF), width: 1),
                  boxShadow: const [BoxShadow(color: Color(0x99000000), blurRadius: 24)]),
              child: inner);
        case ThemeKind.light:
          return Container(
              decoration: BoxDecoration(borderRadius: r, color: const Color(0xFFEEF0F8), boxShadow: const [
                BoxShadow(color: Colors.white, offset: Offset(-5, -5), blurRadius: 10),
                BoxShadow(color: Color(0x55606C9B), offset: Offset(6, 7), blurRadius: 14),
              ]),
              child: inner);
        case ThemeKind.normal:
          return Container(decoration: BoxDecoration(borderRadius: r, color: const Color(0xFF0E1250), border: Border.all(color: kEdge, width: 1.5)), child: inner);
      }
    }
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: ThemeScope(theme: theme, clock: clock, child: theme.rgb ? AnimatedBuilder(animation: clock, builder: (_, __) => shell(clock.value)) : shell(0)),
    );
  }
}

const _rainbow = [Color(0xFF00E5FF), Color(0xFF00FF88), Color(0xFFFFE600), Color(0xFFFF8A00), Color(0xFFFF2EC4), Color(0xFF8A4DFF), Color(0xFF00E5FF)];
SweepGradient rainbowSweep(double t) => SweepGradient(colors: _rainbow, transform: GradientRotation(t * 2 * math.pi));
Color hue(double t) => HSVColor.fromAHSV(1, (t * 360) % 360, 0.9, 1).toColor();

// ---------------------------------------------------------------- background
class _BgPainter extends CustomPainter {
  final ThemeKind kind;
  _BgPainter(this.kind);
  void _blob(Canvas c, Offset o, double r, Color col) => c.drawCircle(
      o, r, Paint()..shader = RadialGradient(colors: [col, col.withOpacity(0)]).createShader(Rect.fromCircle(center: o, radius: r)));
  /// Carbon-fibre weave, soft dark shapes and glowing circuit traces, like the design picture.
  void _rgbBg(Canvas c, Size s) {
    final w = s.width, h = s.height;
    c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFF06060C));
    _blob(c, Offset(0, h * 0.70), h * 0.55, const Color(0x1A33405E));
    _blob(c, Offset(w, h * 0.85), h * 0.60, const Color(0x1A33405E));
    _blob(c, Offset(w * 0.99, h * 0.38), h * 0.38, const Color(0x2A5A22A0));
    final a = Paint()..color = const Color(0x14FFFFFF)..strokeWidth = 1.2;
    final b = Paint()..color = const Color(0x0AFFFFFF)..strokeWidth = 1.2;
    for (double x = -h; x < w; x += 6) { c.drawLine(Offset(x, 0), Offset(x + h, h), a); }
    for (double x = 0; x < w + h; x += 6) { c.drawLine(Offset(x, 0), Offset(x - h, h), b); }
    void trace(List<List<double>> pts, Color col, [double wd = 1.4]) {
      final p = Path()..moveTo(pts[0][0] * w, pts[0][1] * h);
      for (var i = 1; i < pts.length; i++) { p.lineTo(pts[i][0] * w, pts[i][1] * h); }
      c.drawPath(p, Paint()..color = col.withOpacity(0.35)..style = PaintingStyle.stroke..strokeWidth = wd + 2.5..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
      c.drawPath(p, Paint()..color = col..style = PaintingStyle.stroke..strokeWidth = wd..strokeJoin = StrokeJoin.round);
    }
    const cy = Color(0xFF1DB7FF), pk = Color(0xFFD33BFF), pu = Color(0xFF8A3CFF);
    // top: cyan traces on the left, magenta on the right
    trace([[.23, .045], [.385, .045], [.415, .10]], cy);
    trace([[.26, .07], [.37, .07], [.395, .115]], cy);
    trace([[.385, 0], [.43, .065]], cy);
    trace([[.77, .045], [.615, .045], [.585, .10]], pk);
    trace([[.74, .07], [.63, .07], [.605, .115]], pk);
    trace([[.615, 0], [.57, .065]], pk);
    // data lines beside the screen
    for (final r in const [[.29, .14, .23], [.32, .12, .20], [.35, .16, .235], [.39, .11, .22], [.43, .15, .235], [.47, .18, .23]]) {
      trace([[r[1], r[0]], [r[2], r[0]]], cy.withOpacity(0.75), 2.0);
    }
    trace([[.75, .30], [.80, .30], [.835, .22], [.90, .22]], pu);
    trace([[.75, .34], [.82, .34], [.85, .27]], pu);
    trace([[.78, .52], [.78, .70]], pu, 1.2);
    trace([[.745, .69], [.80, .69]], pu, 2.4);
    trace([[.17, .60], [.17, .88], [.21, .92]], cy.withOpacity(0.7), 1.2);
    trace([[.15, .66], [.20, .62]], cy.withOpacity(0.7), 1.2);
  }

  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    switch (kind) {
      case ThemeKind.glass:
        c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFF080A14));
        _blob(c, Offset(w * 0.05, h * 0.35), h * 0.55, const Color(0x663B2A8F));
        _blob(c, Offset(w * 0.98, h * 0.25), h * 0.45, const Color(0x55402C9E));
        _blob(c, Offset(w * 0.04, h * 0.95), h * 0.35, const Color(0x44243C96));
        _blob(c, Offset(w * 0.92, h * 0.95), h * 0.40, const Color(0x44382690));
        break;
      case ThemeKind.light:
        c.drawRect(Offset.zero & s, Paint()..color = const Color(0xFFEEF0F8));
        _blob(c, Offset(w * 0.02, h * 0.30), h * 0.55, const Color(0x99A9C8FF));
        _blob(c, Offset(w * 0.98, h * 0.30), h * 0.50, const Color(0x99C6B8FF));
        _blob(c, Offset(w * 0.10, h * 0.98), h * 0.40, const Color(0x77B3D5FF));
        _blob(c, Offset(w * 0.90, h * 0.95), h * 0.40, const Color(0x77CABFFF));
        break;
      case ThemeKind.rgb:
        _rgbBg(c, s);
        break;
      case ThemeKind.normal:
        break;
    }
  }
  @override
  bool shouldRepaint(_BgPainter o) => o.kind != kind;
}

Widget themedBackground(CTheme th) => RepaintBoundary(child: CustomPaint(painter: _BgPainter(th.kind), size: Size.infinite));

// ---------------------------------------------------------------- buttons
/// Flat neon gradient style used by the Normal theme.
BoxDecoration neon({bool circle = false, double radius = 18, bool active = false}) => BoxDecoration(
      shape: circle ? BoxShape.circle : BoxShape.rectangle,
      borderRadius: circle ? null : BorderRadius.circular(radius),
      gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: active ? const [Color(0xFFFF4FD8), Color(0xFF8A2BE2)] : const [kBlue, kPurple]),
      border: Border.all(color: active ? const Color(0xFFFFB3F0) : kEdge, width: 1.6),
      boxShadow: const [BoxShadow(color: Color(0x553A8DFF), blurRadius: 10)],
    );

/// One button face in the chosen theme. Size is decided by the caller, only the look changes.
Widget themedFace({
  required CTheme th, required double t, required double w, required double h,
  required bool circle, required double radius, required bool active, required Widget child,
  bool pill = false, String neon = 'cyan',
}) {
  final shape = circle ? BoxShape.circle : BoxShape.rectangle;
  final br = circle ? null : BorderRadius.circular(radius);
  switch (th.kind) {
    case ThemeKind.rgb:
      {
        final p = _neonPalette(neon);
        return CustomPaint(
          size: Size(w, h),
          painter: _NeonPainter(circle ? 0 : (pill ? 1 : 2), p[0], p[1], p[2], pill, active, t),
          child: SizedBox(width: w, height: h, child: Center(child: child)),
        );
      }
    case ThemeKind.glass:
      return Container(
        width: w, height: h, alignment: Alignment.center,
        decoration: BoxDecoration(
            shape: shape, borderRadius: br, color: const Color(0xCC10131E),
            gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: active ? const [Color(0x557C5CFF), Color(0x1A7C5CFF)] : const [Color(0x2EFFFFFF), Color(0x08FFFFFF)]),
            border: Border.all(color: active ? const Color(0xAA9F8CFF) : const Color(0x40FFFFFF), width: 1),
            boxShadow: const [BoxShadow(color: Color(0x66000000), blurRadius: 12, offset: Offset(0, 5))]),
        child: child,
      );
    case ThemeKind.light:
      return Container(
        width: w, height: h, alignment: Alignment.center,
        decoration: BoxDecoration(
            shape: shape, borderRadius: br,
            gradient: LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: active ? const [Color(0xFFD6DAF3), Color(0xFFC9CEEE)] : const [Color(0xFFF7F8FD), Color(0xFFE6E9F4)]),
            boxShadow: const [
              BoxShadow(color: Colors.white, offset: Offset(-4, -4), blurRadius: 8),
              BoxShadow(color: Color(0x44606C9B), offset: Offset(4, 5), blurRadius: 10),
            ]),
        child: child,
      );
    case ThemeKind.normal:
      return Container(width: w, height: h, alignment: Alignment.center, decoration: neon(circle: circle, radius: radius, active: active), child: child);
  }
}

class NeonBtn extends StatefulWidget {
  final double w, h;
  final Widget child;
  final VoidCallback onTap;
  final bool circle, active;
  final String neon; // RGB theme colours: cyan | blue | pink | ok
  const NeonBtn({super.key, required this.w, required this.h, required this.child, required this.onTap, this.circle = false, this.active = false, this.neon = 'cyan'});
  @override
  State<NeonBtn> createState() => _NB();
}

class _NB extends State<NeonBtn> {
  bool down = false;
  @override
  Widget build(BuildContext c) {
    final sc = ThemeScope.maybeOf(c);
    final th = sc?.theme ?? const CTheme(ThemeKind.normal);
    final r = math.min(widget.w, widget.h) * 0.28;
    Widget face(double t) => themedFace(th: th, t: t, w: widget.w, h: widget.h, circle: widget.circle, radius: r, active: widget.active, neon: widget.neon, child: widget.child);
    return GestureDetector(
      onTapDown: (_) => setState(() => down = true),
      onTapUp: (_) { setState(() => down = false); widget.onTap(); },
      onTapCancel: () => setState(() => down = false),
      child: AnimatedScale(
        scale: down ? 0.94 : 1,
        duration: const Duration(milliseconds: 80),
        child: (th.rgb && sc != null) ? AnimatedBuilder(animation: sc.clock, builder: (_, __) => face(sc.clock.value)) : face(0),
      ),
    );
  }
}

class VolumePill extends StatelessWidget {
  final double w, h;
  final VoidCallback onUp, onDown;
  const VolumePill({super.key, required this.w, required this.h, required this.onUp, required this.onDown});
  @override
  Widget build(BuildContext c) {
    final sc = ThemeScope.maybeOf(c);
    final th = sc?.theme ?? const CTheme(ThemeKind.normal);
    Widget face(double t) => themedFace(
          th: th, t: t, w: w, h: h, circle: false, radius: w * 0.45, active: false, pill: true, neon: 'volume',
          child: Column(children: [
            Expanded(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: onUp, child: Center(child: Icon(Icons.add, color: th.icon, size: w * 0.5)))),
            Container(height: 1.5, margin: EdgeInsets.symmetric(horizontal: w * 0.12), color: th.rgb ? const Color(0xFFFF5BFF) : th.icon.withOpacity(0.5)),
            Expanded(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: onDown, child: Center(child: Icon(Icons.remove, color: th.rgb ? const Color(0xFFFF5BFF) : th.icon, size: w * 0.5)))),
          ]),
        );
    return (th.rgb && sc != null) ? AnimatedBuilder(animation: sc.clock, builder: (_, __) => face(sc.clock.value)) : face(0);
  }
}

// ---------------------------------------------------------------- joystick
/// Round joystick: drag or tap toward UP/DOWN/LEFT/RIGHT; holding repeats the key.
class Joystick extends StatefulWidget {
  final double size;
  final void Function(String dir) onDir;
  const Joystick({super.key, required this.size, required this.onDir});
  @override
  State<Joystick> createState() => _JS();
}

class _JS extends State<Joystick> {
  Offset knob = Offset.zero;
  Timer? rep;
  String? cur;

  void _update(Offset local) {
    final r = widget.size / 2;
    var v = (local - Offset(r, r)) / r;
    if (v.distance > 1) v = v / v.distance;
    String? dir;
    if (v.distance > 0.35) dir = v.dx.abs() > v.dy.abs() ? (v.dx > 0 ? 'RIGHT' : 'LEFT') : (v.dy > 0 ? 'DOWN' : 'UP');
    setState(() => knob = v);
    if (dir != cur) {
      cur = dir;
      rep?.cancel();
      if (dir != null) {
        widget.onDir(dir);
        rep = Timer(const Duration(milliseconds: 380), () {
          rep = Timer.periodic(const Duration(milliseconds: 130), (_) { if (cur != null) widget.onDir(cur!); });
        });
      }
    }
  }

  void _end() { cur = null; rep?.cancel(); setState(() => knob = Offset.zero); }

  @override
  void dispose() { rep?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext c) {
    final sc = ThemeScope.maybeOf(c);
    final th = sc?.theme ?? const CTheme(ThemeKind.normal);
    Widget paint(double t) => CustomPaint(size: Size(widget.size, widget.size), painter: _JP(knob, th.kind, t));
    return Listener(
      onPointerDown: (e) => _update(e.localPosition),
      onPointerMove: (e) => _update(e.localPosition),
      onPointerUp: (_) => _end(),
      onPointerCancel: (_) => _end(),
      child: (th.rgb && sc != null) ? AnimatedBuilder(animation: sc.clock, builder: (_, __) => paint(sc.clock.value)) : paint(0),
    );
  }
}

class _JP extends CustomPainter {
  final Offset knob;
  final ThemeKind kind;
  final double t;
  _JP(this.knob, this.kind, this.t);

  @override
  void paint(Canvas c, Size s) {
    final r = s.width / 2;
    final ctr = Offset(r, r);
    final rect = Rect.fromCircle(center: ctr, radius: r);
    final k = ctr + knob * (r * 0.30);
    Color labelColor = Colors.white, lineColor = Colors.white;
    Paint ringFill, ringEdge, holeFill, holeEdge, nubFill, nubEdge;

    switch (kind) {
      case ThemeKind.normal:
        ringFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [kBlue, kPurple]).createShader(rect);
        ringEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = kEdge;
        holeFill = Paint()..color = kDark;
        holeEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5..color = kEdge;
        nubFill = Paint()..shader = const LinearGradient(colors: [Color(0xFFFF6AE0), kPurple]).createShader(Rect.fromCircle(center: k, radius: r * 0.26));
        nubEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white;
        break;
      case ThemeKind.glass:
        ringFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF2A2E44), Color(0xFF0F1220)]).createShader(rect);
        ringEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0x66FFFFFF);
        holeFill = Paint()..color = const Color(0xFF07080F);
        holeEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0x44FFFFFF);
        nubFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFF2F0FF), Color(0xFF8C84C8)]).createShader(Rect.fromCircle(center: k, radius: r * 0.26));
        nubEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0xB3FFFFFF);
        lineColor = const Color(0x66FFFFFF);
        break;
      case ThemeKind.light:
        c.drawCircle(ctr + const Offset(5, 6), r - 2, Paint()..color = const Color(0x55606C9B)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
        c.drawCircle(ctr - const Offset(5, 5), r - 2, Paint()..color = Colors.white..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
        ringFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFF8F9FE), Color(0xFFE0E3F1)]).createShader(rect);
        ringEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0x55FFFFFF);
        holeFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFDFE2EF), Color(0xFFF6F7FC)]).createShader(Rect.fromCircle(center: ctr, radius: r * 0.40));
        holeEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0x33485078);
        nubFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Colors.white, Color(0xFFD3D8EC)]).createShader(Rect.fromCircle(center: k, radius: r * 0.26));
        nubEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.2..color = const Color(0x33485078);
        labelColor = const Color(0xFF2B3150);
        lineColor = const Color(0x66485078);
        break;
      case ThemeKind.rgb:
        c.drawCircle(ctr, r - 2, Paint()..color = const Color(0x5527D7FF)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
        ringFill = Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF1A1C2A), Color(0xFF090A11)]).createShader(rect);
        ringEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5
          ..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF27D7FF), Color(0xFF8A3CFF)]).createShader(rect);
        holeFill = Paint()..color = const Color(0xFF05060A);
        holeEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 5
          ..shader = SweepGradient(colors: const [Color(0xFF27D7FF), Color(0xFFFF2EC4), Color(0xFF8A3CFF), Color(0xFF27D7FF)], transform: GradientRotation(t * 2 * math.pi))
              .createShader(Rect.fromCircle(center: ctr, radius: r * 0.40));
        nubFill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFFF59E0), Color(0xFF59E8FF)]).createShader(Rect.fromCircle(center: k, radius: r * 0.26));
        nubEdge = Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = Colors.white;
        labelColor = const Color(0xFF27D7FF);
        lineColor = const Color(0xFF05060A);
        break;
    }

    c.drawCircle(ctr, r - 2, ringFill);
    c.drawCircle(ctr, r - 2, ringEdge);
    final line = Paint()..color = lineColor..strokeWidth = kind == ThemeKind.rgb ? 5 : 2;
    for (final a in [math.pi / 4, 3 * math.pi / 4, 5 * math.pi / 4, 7 * math.pi / 4]) {
      final d = Offset(math.cos(a), math.sin(a));
      c.drawLine(ctr + d * (r * 0.62), ctr + d * (r * 0.93), line);
    }
    c.drawCircle(ctr, r * 0.40, holeFill);
    c.drawCircle(ctr, r * 0.40, holeEdge);
    _label(c, 'UP', ctr + Offset(0, -r * 0.77), 0, r, labelColor);
    _label(c, 'DOWN', ctr + Offset(0, r * 0.77), 0, r, labelColor);
    _label(c, 'LEFT', ctr + Offset(-r * 0.77, 0), -math.pi / 2, r, labelColor);
    _label(c, 'RIGHT', ctr + Offset(r * 0.77, 0), math.pi / 2, r, labelColor);
    if (kind == ThemeKind.light) {
      c.drawCircle(k + const Offset(3, 4), r * 0.26, Paint()..color = const Color(0x44606C9B)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));
    }
    c.drawCircle(k, r * 0.26, nubFill);
    c.drawCircle(k, r * 0.26, nubEdge);
  }

  void _label(Canvas c, String text, Offset p, double angle, double r, Color color) {
    final tp = TextPainter(
        text: TextSpan(text: text, style: TextStyle(color: color, fontSize: r * 0.17, fontWeight: FontWeight.w800, letterSpacing: 1)),
        textDirection: TextDirection.ltr)
      ..layout();
    c.save();
    c.translate(p.dx, p.dy);
    c.rotate(angle);
    tp.paint(c, Offset(-tp.width / 2, -tp.height / 2));
    c.restore();
  }

  @override
  bool shouldRepaint(_JP o) => o.knob != knob || o.kind != kind || o.t != t;
}


// ---------------------------------------------------------------- RGB theme pieces
List<Color> _neonPalette(String n) {
  switch (n) {
    case 'pink': return const [Color(0xFFFF2EC4), Color(0xFFB445FF), Color(0xFFFF2EC4)];
    case 'blue': return const [Color(0xFF29B6FF), Color(0xFF9B4DFF), Color(0xFF3A7BFF)];
    case 'ok': return const [Color(0xFF1DE9FF), Color(0xFFFF2EC4), Color(0xFFB445FF)];
    case 'volume': return const [Color(0xFF1DE9FF), Color(0xFFFF2EC4), Color(0xFF8A7BFF)];
    default: return const [Color(0xFF1DE9FF), Color(0xFF3A7BFF), Color(0xFF1DE9FF)];
  }
}

/// Beveled / ring / pill button with a glowing neon edge, like the design picture.
class _NeonPainter extends CustomPainter {
  final int shape; // 0 ring, 1 pill, 2 bevel
  final Color c1, c2, glow;
  final bool vertical, active;
  final double t;
  _NeonPainter(this.shape, this.c1, this.c2, this.glow, this.vertical, this.active, this.t);

  Path _path(Size s) {
    final w = s.width, h = s.height;
    if (shape == 0) return Path()..addOval(Rect.fromLTWH(0, 0, w, h));
    if (shape == 1) return Path()..addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, w, h), Radius.circular(w / 2)));
    final k = math.min(h * 0.28, w * 0.12);
    return Path()
      ..moveTo(k, 0)..lineTo(w - k, 0)..lineTo(w, k)..lineTo(w, h - k)
      ..lineTo(w - k, h)..lineTo(k, h)..lineTo(0, h - k)..lineTo(0, k)..close();
  }

  @override
  void paint(Canvas c, Size s) {
    final path = _path(s);
    final rect = Offset.zero & s;
    final pulse = 0.75 + 0.25 * math.sin(t * 2 * math.pi);
    c.drawPath(path, Paint()..color = glow.withOpacity((active ? 0.9 : 0.55) * pulse)..style = PaintingStyle.stroke..strokeWidth = 6..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9));
    c.drawPath(path, Paint()..shader = LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: active ? [c1.withOpacity(0.35), const Color(0xFF0B0C14)] : const [Color(0xFF1D1F2E), Color(0xFF0A0B12)]).createShader(rect));
    c.save();
    c.clipPath(path);
    final top = Rect.fromLTWH(0, 0, s.width, s.height * 0.5);
    c.drawRect(top, Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0x1CFFFFFF), Color(0x04FFFFFF)]).createShader(top));
    c.restore();
    final m = Matrix4.identity()..translate(s.width / 2, s.height / 2)..scale(0.90, 0.86)..translate(-s.width / 2, -s.height / 2);
    c.drawPath(path.transform(m.storage), Paint()..color = c1.withOpacity(0.28)..style = PaintingStyle.stroke..strokeWidth = 1);
    c.drawPath(path, Paint()
      ..style = PaintingStyle.stroke..strokeWidth = 2.6..strokeJoin = StrokeJoin.round
      ..shader = LinearGradient(
          begin: vertical ? Alignment.topCenter : Alignment.centerLeft,
          end: vertical ? Alignment.bottomCenter : Alignment.centerRight,
          colors: [c1, c2]).createShader(rect));
    if (shape == 0) {
      final arc = Paint()..style = PaintingStyle.stroke..strokeWidth = 5..strokeCap = StrokeCap.round..color = c1;
      final rr = rect.deflate(2.5);
      c.drawArc(rr, -2.2, 0.7, false, arc);
      c.drawArc(rr, 0.9, 0.7, false, arc);
    }
  }

  @override
  bool shouldRepaint(_NeonPainter o) => o.t != t || o.active != active || o.c1 != c1 || o.shape != shape;
}

/// Double line used on both sides of the TELEVISION label.
class _LinesPainter extends CustomPainter {
  final bool mirror;
  _LinesPainter(this.mirror);
  @override
  void paint(Canvas c, Size s) {
    const col = Color(0xFF27D7FF);
    final glow = Paint()..color = col.withOpacity(0.5)..strokeWidth = 4..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);
    final thick = Paint()..color = col..strokeWidth = 2.4;
    final thin = Paint()..color = col..strokeWidth = 1.1;
    final w = s.width, h = s.height;
    // thick line next to the text, thin longer line outside it
    final a1 = mirror ? 0.0 : w * 0.45, b1 = mirror ? w * 0.55 : w;
    final a2 = mirror ? 0.0 : 0.0, b2 = w;
    c.drawLine(Offset(a1, h * 0.3), Offset(b1, h * 0.3), glow);
    c.drawLine(Offset(a1, h * 0.3), Offset(b1, h * 0.3), thick);
    c.drawLine(Offset(a2, h * 0.75), Offset(b2, h * 0.75), thin);
  }
  @override
  bool shouldRepaint(_LinesPainter o) => false;
}

/// TELEVISION in the neon style of the design picture: cyan glowing text between two double lines.
Widget rgbLabel() => Container(
      color: const Color(0xFF06060C),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        CustomPaint(size: const Size(70, 10), painter: _LinesPainter(false)),
        const SizedBox(width: 8),
        const Text('TELEVISION',
            style: TextStyle(color: Color(0xFF27D7FF), fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1.5,
                shadows: [Shadow(color: Color(0xFF27D7FF), blurRadius: 10)])),
        const SizedBox(width: 8),
        CustomPaint(size: const Size(70, 10), painter: _LinesPainter(true)),
      ]),
    );

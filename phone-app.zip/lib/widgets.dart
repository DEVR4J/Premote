import 'package:flutter/material.dart';
const btnColor = Color(0xFFC9D2DC);
class Pill extends StatelessWidget {
  final IconData? icon;
  final String? label;
  final VoidCallback onTap;
  final bool circle, tall;
  const Pill({super.key, this.icon, this.label, required this.onTap, this.circle = false, this.tall = false});
  @override
  Widget build(BuildContext c) => GestureDetector(
      onTap: onTap,
      child: Container(
        width: circle ? 80 : 68,
        height: circle ? 80 : (tall ? 96 : 84),
        decoration: BoxDecoration(
            color: btnColor,
            shape: circle ? BoxShape.circle : BoxShape.rectangle,
            borderRadius: circle ? null : BorderRadius.circular(22)),
        child: icon != null
            ? Icon(icon, color: Colors.white, size: 38)
            : Center(child: Text(label!, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold))),
      ));
}

class Tri extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const Tri(this.label, this.onTap, {super.key});
  @override
  Widget build(BuildContext c) {
    final turns = {'UP': 0, 'RIGHT': 1, 'DOWN': 2, 'LEFT': 3}[label]!;
    return GestureDetector(
      onTap: onTap,
      child: RotatedBox(
          quarterTurns: turns,
          child: ClipPath(
              clipper: _T(),
              child: Container(
                  width: 64,
                  height: 64,
                  color: btnColor,
                  alignment: const Alignment(0, .5),
                  child: RotatedBox(
                      quarterTurns: (4 - turns) % 4,
                      child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)))))),
    );
  }
}

class _T extends CustomClipper<Path> {
  @override
  Path getClip(Size s) => Path()..moveTo(s.width / 2, 0)..lineTo(s.width, s.height)..lineTo(0, s.height)..close();
  @override
  bool shouldReclip(CustomClipper<Path> o) => false;
}


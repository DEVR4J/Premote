import 'package:flutter/material.dart';

const btnColor = Color(0xFFC9D2DC);

class Pill extends StatelessWidget {
  final IconData? icon;
  final String? label;
  final VoidCallback onTap;
  final bool circle, tall;
  final double size;
  const Pill({super.key, this.icon, this.label, required this.onTap, this.circle = false, this.tall = false, this.size = 64});
  @override
  Widget build(BuildContext c) {
    final w = circle ? size * 1.15 : size;
    final h = circle ? size * 1.15 : (tall ? size * 1.3 : size * 1.1);
    return GestureDetector(
        onTap: onTap,
        child: Container(
          width: w, height: h,
          decoration: BoxDecoration(
              color: btnColor,
              shape: circle ? BoxShape.circle : BoxShape.rectangle,
              borderRadius: circle ? null : BorderRadius.circular(size * 0.3)),
          child: icon != null
              ? Icon(icon, color: Colors.white, size: size * 0.55)
              : Center(child: Text(label!, style: TextStyle(color: Colors.white, fontSize: size * 0.32, fontWeight: FontWeight.bold))),
        ));
  }
}

class Tri extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final double size;
  const Tri(this.label, this.onTap, {super.key, this.size = 64});
  @override
  Widget build(BuildContext c) {
    final turns = {'UP': 0, 'RIGHT': 1, 'DOWN': 2, 'LEFT': 3}[label]!;
    return GestureDetector(
      onTap: onTap,
      child: RotatedBox(
          quarterTurns: turns,
          child: ClipPath(
              clipper: _T(),
              child: Container(
                  width: size, height: size, color: btnColor,
                  alignment: const Alignment(0, .5),
                  child: RotatedBox(
                      quarterTurns: (4 - turns) % 4,
                      child: Text(label, style: TextStyle(color: Colors.white, fontSize: size * 0.17, fontWeight: FontWeight.bold)))))),
    );
  }
}

class _T extends CustomClipper<Path> {
  @override
  Path getClip(Size s) => Path()..moveTo(s.width / 2, 0)..lineTo(s.width, s.height)..lineTo(0, s.height)..close();
  @override
  bool shouldReclip(CustomClipper<Path> o) => false;
}

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';

const kBlue = Color(0xFF2F7BFF);
const kPurple = Color(0xFF7A35E8);
const kEdge = Color(0xFF7CC4FF);
const kDark = Color(0xFF0A0E3D);

/// Flat neon gradient button style (solid colours, no frosted glass).
BoxDecoration neon({bool circle = false, double radius = 18, bool active = false}) => BoxDecoration(
      shape: circle ? BoxShape.circle : BoxShape.rectangle,
      borderRadius: circle ? null : BorderRadius.circular(radius),
      gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: active ? const [Color(0xFFFF4FD8), Color(0xFF8A2BE2)] : const [kBlue, kPurple]),
      border: Border.all(color: active ? const Color(0xFFFFB3F0) : kEdge, width: 1.6),
      boxShadow: const [BoxShadow(color: Color(0x553A8DFF), blurRadius: 10)],
    );

class NeonBtn extends StatefulWidget {
  final double w, h;
  final Widget child;
  final VoidCallback onTap;
  final bool circle, active;
  const NeonBtn({super.key, required this.w, required this.h, required this.child, required this.onTap, this.circle = false, this.active = false});
  @override
  State<NeonBtn> createState() => _NB();
}

class _NB extends State<NeonBtn> {
  bool down = false;
  @override
  Widget build(BuildContext c) => GestureDetector(
        onTapDown: (_) => setState(() => down = true),
        onTapUp: (_) { setState(() => down = false); widget.onTap(); },
        onTapCancel: () => setState(() => down = false),
        child: AnimatedScale(
          scale: down ? 0.94 : 1,
          duration: const Duration(milliseconds: 80),
          child: Container(
            width: widget.w, height: widget.h, alignment: Alignment.center,
            decoration: neon(circle: widget.circle, radius: math.min(widget.w, widget.h) * 0.28, active: widget.active),
            child: widget.child,
          ),
        ),
      );
}

class VolumePill extends StatelessWidget {
  final double w, h;
  final VoidCallback onUp, onDown;
  const VolumePill({super.key, required this.w, required this.h, required this.onUp, required this.onDown});
  @override
  Widget build(BuildContext c) => Container(
        width: w, height: h,
        decoration: neon(radius: w * 0.45),
        child: Column(children: [
          Expanded(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: onUp, child: Center(child: Icon(Icons.add, color: Colors.white, size: w * 0.5)))),
          Container(height: 1.5, margin: EdgeInsets.symmetric(horizontal: w * 0.12), color: Colors.white54),
          Expanded(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: onDown, child: Center(child: Icon(Icons.remove, color: Colors.white, size: w * 0.5)))),
        ]),
      );
}

/// Round joystick: drag or tap toward UP/DOWN/LEFT/RIGHT; holding repeats the key.
class Joystick extends StatefulWidget {
  final double size;
  final void Function(String dir) onDir;
  const Joystick({super.key, required this.size, required this.onDir});
  @override
  State<Joystick> createState() => _JS();
}

class _JS extends State<Joystick> {
  Offset knob = Offset.zero;
  Timer? rep;
  String? cur;

  void _update(Offset local) {
    final r = widget.size / 2;
    var v = (local - Offset(r, r)) / r;
    if (v.distance > 1) v = v / v.distance;
    String? dir;
    if (v.distance > 0.35) dir = v.dx.abs() > v.dy.abs() ? (v.dx > 0 ? 'RIGHT' : 'LEFT') : (v.dy > 0 ? 'DOWN' : 'UP');
    setState(() => knob = v);
    if (dir != cur) {
      cur = dir;
      rep?.cancel();
      if (dir != null) {
        widget.onDir(dir);
        rep = Timer(const Duration(milliseconds: 380), () {
          rep = Timer.periodic(const Duration(milliseconds: 130), (_) { if (cur != null) widget.onDir(cur!); });
        });
      }
    }
  }

  void _end() { cur = null; rep?.cancel(); setState(() => knob = Offset.zero); }

  @override
  void dispose() { rep?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext c) => Listener(
        onPointerDown: (e) => _update(e.localPosition),
        onPointerMove: (e) => _update(e.localPosition),
        onPointerUp: (_) => _end(),
        onPointerCancel: (_) => _end(),
        child: CustomPaint(size: Size(widget.size, widget.size), painter: _JP(knob)),
      );
}

class _JP extends CustomPainter {
  final Offset knob;
  _JP(this.knob);
  @override
  void paint(Canvas c, Size s) {
    final r = s.width / 2;
    final ctr = Offset(r, r);
    c.drawCircle(ctr, r - 2, Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [kBlue, kPurple]).createShader(Rect.fromCircle(center: ctr, radius: r)));
    c.drawCircle(ctr, r - 2, Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = kEdge);
    final line = Paint()..color = Colors.white..strokeWidth = 2;
    for (final a in [math.pi / 4, 3 * math.pi / 4, 5 * math.pi / 4, 7 * math.pi / 4]) {
      final d = Offset(math.cos(a), math.sin(a));
      c.drawLine(ctr + d * (r * 0.62), ctr + d * (r * 0.93), line);
    }
    c.drawCircle(ctr, r * 0.40, Paint()..color = kDark);
    c.drawCircle(ctr, r * 0.40, Paint()..style = PaintingStyle.stroke..strokeWidth = 2.5..color = kEdge);
    _label(c, 'UP', ctr + Offset(0, -r * 0.77), 0, r);
    _label(c, 'DOWN', ctr + Offset(0, r * 0.77), 0, r);
    _label(c, 'LEFT', ctr + Offset(-r * 0.77, 0), -math.pi / 2, r);
    _label(c, 'RIGHT', ctr + Offset(r * 0.77, 0), math.pi / 2, r);
    final k = ctr + knob * (r * 0.30);
    c.drawCircle(k, r * 0.26, Paint()..shader = const LinearGradient(colors: [Color(0xFFFF6AE0), kPurple]).createShader(Rect.fromCircle(center: k, radius: r * 0.26)));
    c.drawCircle(k, r * 0.26, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white);
  }

  void _label(Canvas c, String t, Offset p, double angle, double r) {
    final tp = TextPainter(
        text: TextSpan(text: t, style: TextStyle(color: Colors.white, fontSize: r * 0.17, fontWeight: FontWeight.w800, letterSpacing: 1)),
        textDirection: TextDirection.ltr)
      ..layout();
    c.save();
    c.translate(p.dx, p.dy);
    c.rotate(angle);
    tp.paint(c, Offset(-tp.width / 2, -tp.height / 2));
    c.restore();
  }

  @override
  bool shouldRepaint(_JP o) => o.knob != knob;
}

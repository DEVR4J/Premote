package com.example.tv_remote

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.flutter.plugin.common.MethodChannel
import java.io.File

/** Installs a downloaded APK through Android's PackageInstaller and reports what happened to Dart. */
object Installer {
    var channel: MethodChannel? = null
    fun report(msg: String) { channel?.invokeMethod("installResult", msg) }

    /** Says why Android would refuse this file as an update, or null when it looks fine. */
    private fun problem(ctx: Context, apk: File): String? {
        return try {
            val pm = ctx.packageManager
            val flag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else 0
            val arch = pm.getPackageArchiveInfo(apk.path, flag) ?: return "The downloaded file is not a valid app"
            val cur = pm.getPackageInfo(ctx.packageName, flag)
            @Suppress("DEPRECATION")
            if (arch.versionCode < cur.versionCode) return "The downloaded version (${arch.versionCode}) is older than the installed one (${cur.versionCode}). Uninstall this app once and install the newest release."
            if (Build.VERSION.SDK_INT >= 28) {
                val a = arch.signingInfo?.apkContentsSigners?.map { it.toCharsString() }?.toSet()
                val c = cur.signingInfo?.apkContentsSigners?.map { it.toCharsString() }?.toSet()
                if (a != null && c != null && a != c)
                    return "The new version has a different signing key, so Android cannot update over this one. Uninstall ATC Phone once, then install the newest release (scan the QR code on the TV)."
            }
            null
        } catch (e: Throwable) { null }
    }

    fun install(ctx: Context, path: String): String {
        val apk = File(path)
        if (!apk.exists()) return "Update file is missing"
        val bad = problem(ctx, apk)
        if (bad != null) return bad
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "need_permission"
        }
        val pi = ctx.packageManager.packageInstaller
        val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(id).use { s ->
            apk.inputStream().use { inp -> s.openWrite("app.apk", 0, apk.length()).use { o -> inp.copyTo(o); s.fsync(o) } }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(ctx, id, Intent(ctx, InstallResultReceiver::class.java), flags)
            s.commit(pending.intentSender)
        }
        return "ok"
    }
}

class InstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(confirm) }
                Installer.report("Confirm the update in the installer window")
            }
            PackageInstaller.STATUS_SUCCESS -> Installer.report("Updated. Open the app again.")
            else -> Installer.report("Install failed: " + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE))
        }
    }
}

# Phone app
Unzip, upload everything (incl. hidden .github) to GitHub on main. APK: Actions > run > Artifacts.
Home Wi-Fi: type the TV IP + code. Internet: type server address + TV ID + code.

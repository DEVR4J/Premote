import React, { useState } from 'react';
import { CaseDetails, ECOURTS_URL, EcCase, parseCaseDetails, parsePasted, splitNewAndKnown } from './ecourts';

export type SyncedCase = { cnr: string; caseNumber: string; title: string; court: string; status: string; initialDate?: string; nextHearing?: string };
type Props = { defaultName: string; defaultBarId: string; existing: { cnr?: string; caseNumber?: string; court: string }[]; onImport: (cases: SyncedCase[]) => void };

export default function ECourtsSync({ defaultName, defaultBarId, existing, onImport }: Props) {
  const [text, setText] = useState('');
  const [status, setStatus] = useState('Pending');
  const [found, setFound] = useState<EcCase[] | null>(null);
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [one, setOne] = useState<CaseDetails | null>(null); const [oneMsg, setOneMsg] = useState('');
  const [oneText, setOneText] = useState('');
  const readOne = (t: string) => { setOneText(t); if (!t.trim()) { setOne(null); setOneMsg(''); return; } const d = parseCaseDetails(t); setOne(d); setOneMsg(d ? '' : 'This does not look like an eCourts case details page. Open one case on the website, Select all, Copy, then paste again.'); };
  const addFromClipboard = async () => { try { readOne(await navigator.clipboard.readText()); } catch { setOneMsg('This phone does not allow the app to read the clipboard directly. Press and hold in the box below and choose Paste.'); } };
  const addOne = () => { if (!one) return; onImport([{ ...one }]); setOne(null); setOneText(''); };
  const name = /^your name$/i.test(defaultName) ? '' : defaultName;
  const bar = /^bar council enrolment no\.?$/i.test(defaultBarId) ? '' : defaultBarId;

  const readPasted = () => { const res = parsePasted(text, status); setFound(res); setPicked(new Set(splitNewAndKnown(res, existing).fresh.map(c => c.key))); };
  const pasteFromClipboard = async () => { try { setText(await navigator.clipboard.readText()); } catch { /* clipboard blocked: user pastes into the box */ } };
  const { fresh, known } = found ? splitNewAndKnown(found, existing) : { fresh: [], known: [] };
  const importPicked = () => { const chosen = fresh.filter(c => picked.has(c.key)); onImport(chosen.map(c => ({ cnr: c.cnr, caseNumber: c.caseNumber, title: c.title, court: c.court, status: c.status }))); setFound(null); setText(''); };

  return <div className="ecourts-sync">
    <div className="notice-card">The eCourts website blocks apps from searching for you, so you search on the official site and bring the list here. It takes about a minute.</div>
    <h2>Add one case with its dates</h2>
    <p className="body-copy">Open the case on the eCourts website (tap <b>View</b> next to it), Select all, Copy, then come back and tap below.</p>
    <textarea className="notes-area" style={{ height: 110 }} aria-label="Pasted case page" placeholder="Press and hold here, then Paste the copied case page" value={oneText} onChange={e => readOne(e.target.value)} />
    <button className="wide-button" onClick={addFromClipboard}>Try paste from clipboard</button>
    {oneMsg && <div className="notice-card" role="alert">{oneMsg}</div>}
    {one && <div className="notice-card" style={{ background: '#e6f4ea', color: '#1d5b34' }}><b>{one.title}</b><br />{one.caseNumber}{one.court ? ` · ${one.court}` : ''}<br />Next hearing: {one.nextHearing || 'not found'} · Status: {one.status}{one.cnr ? ` · CNR ${one.cnr}` : ''}<button className="wide-button" onClick={addOne}>Save this case</button></div>}
    <h2>Or import a whole list</h2>
    <h3>1. Search on eCourts</h3>
    <p className="body-copy">Open the site, choose <b>Advocate</b>, enter {name ? <>your name (<b>{name}</b>)</> : 'your name'}{bar ? <> or Bar ID (<b>{bar}</b>)</> : ' or Bar ID'}, pick your state, district and court complex, type the captcha and search.</p>
    <a className="wide-button" href={ECOURTS_URL} target="_blank" rel="noopener noreferrer">Open eCourts website</a>
    <h3>2. Copy the result list</h3>
    <p className="body-copy">On the results page, press and hold on the list, choose <b>Select all</b>, then <b>Copy</b>. Come back to this screen.</p>
    <h3>3. Paste here</h3>
    <div className="settings-row"><span>Cases are</span><select aria-label="Case status" value={status} onChange={e => setStatus(e.target.value)}><option value="Pending">Pending</option><option value="Disposed">Disposed</option></select></div>
    <textarea className="notes-area" style={{ height: 180 }} aria-label="Pasted eCourts results" placeholder="Paste the copied results here" value={text} onChange={e => setText(e.target.value)} />
    <button className="wide-button" onClick={pasteFromClipboard}>Paste from clipboard</button>
    <button className="wide-button" onClick={readPasted} disabled={!text.trim()}>Read my cases</button>
    {found && <section aria-label="Cases found">
      {!found.length && <div className="notice-card" role="alert">No cases were recognised. Make sure you copied the results list (with case numbers like CC/123/2021) and try again.</div>}
      {fresh.length > 0 && <><h2>New cases ({fresh.length})</h2>{fresh.map(c => <label key={c.key} className="settings-row"><input type="checkbox" checked={picked.has(c.key)} onChange={e => setPicked(prev => { const n = new Set(prev); if (e.target.checked) n.add(c.key); else n.delete(c.key); return n; })} /><span style={{ flex: 1 }}>{c.title || 'Untitled case'}<small style={{ display: 'block', opacity: .7 }}>{c.caseNumber}{c.court ? ` · ${c.court}` : ''}</small></span></label>)}<button className="wide-button" onClick={importPicked} disabled={!picked.size}>Add {picked.size} selected to my cases</button></>}
      {known.length > 0 && <p className="body-copy">{known.length} case{known.length > 1 ? 's' : ''} already in your app.</p>}
    </section>}
    <p className="body-copy">Imported cases have no next hearing date; set it in each case so it shows in the Diary. Check important dates on the official site.</p>
  </div>;
}

export const CNR_URL = 'https://services.ecourts.gov.in/ecourtindia_v6/?p=cnr_status/index';
type CaseProps = { title: string; cnr?: string; caseNumber?: string; onApply: (d: CaseDetails) => void };

/** Refresh ONE saved case: copy its CNR, look it up on eCourts (captcha there), copy the page, apply here. */
export function EcourtsCaseUpdate({ title, cnr, caseNumber, onApply }: CaseProps) {
  const [msg, setMsg] = useState(''); const [d, setD] = useState<CaseDetails | null>(null); const [pasted, setPasted] = useState('');
  const openSite = async () => { if (cnr) { try { await navigator.clipboard.writeText(cnr); setMsg('CNR copied. Paste it into the CNR box on the website.'); } catch { setMsg(`Type this CNR on the website: ${cnr}`); } } window.open(CNR_URL, '_blank', 'noopener'); };
  const readText = (t: string) => {
    setPasted(t); if (!t.trim()) { setD(null); setMsg(''); return; }
    const r = parseCaseDetails(t);
    if (!r) { setD(null); setMsg('This does not look like an eCourts case page. On the website, Select all, Copy, then paste again.'); return; }
    if (cnr && r.cnr && r.cnr !== cnr) { setD(null); setMsg(`That page is for a different case (${r.cnr}). Open ${cnr} and try again.`); return; }
    setD(r); setMsg('');
  };
  const readPage = async () => { try { readText(await navigator.clipboard.readText()); } catch { setMsg('This phone does not allow the app to read the clipboard directly. Press and hold in the box and choose Paste.'); } };
  return <div className="ecourts-sync">
    <div className="notice-card"><b>{title}</b><br />{cnr ? `CNR ${cnr}` : caseNumber || ''}</div>
    {!cnr && <div className="notice-card">This case has no CNR saved. On the website you can search by case number instead; the details will still be read and the CNR saved.</div>}
    <h3>1. Look it up on eCourts</h3>
    <p className="body-copy">{cnr ? 'Tap below: the CNR is copied and the CNR status page opens. Paste the CNR, type the captcha and search.' : 'Open the website and search for this case.'}</p>
    <button className="wide-button" onClick={openSite}>{cnr ? 'Copy CNR & open eCourts' : 'Open eCourts'}</button>
    <h3>2. Copy the case page</h3>
    <p className="body-copy">When the case details show, press and hold, choose Select all, then Copy. Come back here and paste into the box below; the details appear by themselves.</p>
    <textarea className="notes-area" style={{ height: 110 }} aria-label="Pasted case page" placeholder="Press and hold here, then Paste the copied case page" value={pasted} onChange={e => readText(e.target.value)} />
    <button className="wide-button" onClick={readPage}>Try paste from clipboard</button>
    {msg && <div className="notice-card" role="alert">{msg}</div>}
    {d && <div className="notice-card" style={{ background: '#e6f4ea', color: '#1d5b34' }}>Next hearing: <b>{d.nextHearing || 'not found'}</b><br />Status: {d.status}{d.stage ? ` · Stage: ${d.stage}` : ''}{d.court ? <><br />{d.court}</> : null}<button className="wide-button" onClick={() => { onApply(d); setD(null); setPasted(''); }}>Update this case</button></div>}
  </div>;
}

// @vitest-environment jsdom
import { describe, expect, it } from 'vitest';
import { parseCases, parseOptions, parseReply, validateSearch } from './ecourts';
import { splitNewAndKnown } from './ECourtsSync';

// NOTE: this HTML is a hand-written approximation of the court site's result table, not a capture of
// the live site. Re-check against a real response when testing on a device.
const html = `<table><tr><td colspan="4">District and Sessions Judge, Pune</td></tr>
<tr><th>Sr</th><th>Case Number</th><th>Parties</th><th>View</th></tr>
<tr><td>1</td><td>CC/123/2021</td><td>Ram Kumar Vs State of MH</td><td><a onclick="viewHistory(123,'MHPU010012342021',1,'',0,1,25,'1010101',0)">View</a></td></tr>
<tr><td colspan="4">Civil Court JD, Pune</td></tr>
<tr><td>2</td><td>RCS/45/2019</td><td>Sunita Devi Vs Ranjan Katiyar</td><td><a onclick="viewHistory(45,'MHPU010004562019',2,'',0,1,25,'1010102',0)">View</a></td></tr></table>`;

describe('ecourts parsing', () => {
  it('parses cases with court headings and CNR', () => {
    const r = parseCases(html, 'Pending');
    expect(r).toHaveLength(2);
    expect(r[0]).toMatchObject({ cnr: 'MHPU010012342021', caseNumber: 'CC/123/2021', court: 'District and Sessions Judge, Pune', title: 'Ram Kumar vs State of MH' });
    expect(r[1]?.court).toBe('Civil Court JD, Pune');
  });
  it('parses select options and skips placeholders', () => {
    expect(parseOptions('<option value="0">Select District</option><option value="25">Pune</option>')).toEqual([{ value: '25', label: 'Pune' }]);
  });
  it('validates input', () => {
    expect(validateSearch('name', 'ab')).not.toBe('');
    expect(validateSearch('name', 'Sharma')).toBe('');
    expect(validateSearch('bar', 'MAH/1234/1982')).toBe('');
    expect(validateSearch('bar', '1234')).not.toBe('');
  });
  it('parses non-JSON replies safely', () => { expect(parseReply('<table></table>')).toHaveProperty('html'); expect(parseReply('{"a":1}')).toEqual({ a: 1 }); });
  it('does not duplicate known cases', () => {
    const r = parseCases(html, 'Pending');
    const { fresh, known } = splitNewAndKnown(r, [{ cnr: 'MHPU010012342021', court: 'x' }]);
    expect(fresh).toHaveLength(1); expect(known).toHaveLength(1);
  });
});

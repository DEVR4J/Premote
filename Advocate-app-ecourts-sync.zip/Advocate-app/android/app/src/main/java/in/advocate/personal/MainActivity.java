package in.advocate.personal;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
}
